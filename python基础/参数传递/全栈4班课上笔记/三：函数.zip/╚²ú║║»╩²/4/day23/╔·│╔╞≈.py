#生成器与return有何区别？
    #return只能返回一次函数就彻底结束了，而yield能返回多次值
#yield到底干了什么事情：
    #1.yield把函数变成生成器-->迭代器
    #用return返回值能返回一次，而yield返回多次
    #函数在暂停以及继续下一次运行时的状态是由yield保存
from collections import Iterator
#生成器就是一个函数，这个函数内包含有yield这个关键字
def test():
    print('one')
    yield 1 #return 1
    print('two')
    yield 2 #return 2
    print('three')
    yield 3 #return 2
    print('four')
    yield 4 #return 2
    print('five')
    yield 5 #return 2

g=test()
# print(g)
# print(isinstance(g,Iterator))
# g.__iter__()
# g.__next__()
# res=next(g)
# print(res)
#
# res=next(g)
# print(res)
#
# res=next(g)
# print(res)
#
# res=next(g)
# print(res)
#
# res=next(g)
# print(res)

#
# for i in g:
#     print(i)

def countdown(n):
    print('start coutdown')
    while n > 0:
        yield n #1
        n-=1
    print('done')

g=countdown(5)
# print(g)

# print(next(g))
# print(next(g))
# print(next(g))
# print(next(g))
# print(next(g))
# print(next(g))

# for i in g: #iter(g)
#     print(i)

# while True:
#     try:
#         print(next(g))
#     except StopIteration:
#         break

#
# def func():
#     n=0
#     while True:
#         yield n
#         n+=1
#
# f=func()
# print(next(f))






import time
def tail(file_path):
    with open(file_path,'r') as f:
        f.seek(0,2)
        while True:
            line=f.readline()
            if not line:
                time.sleep(0.3)
                continue
            else:
                # print(line)
                yield line
tail('/tmp/a.txt')






