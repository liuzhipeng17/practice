# l=['a','b','c','d','e']

# i=0
# while i < len(l):
#     print(l[i])
#     i+=1
#
# for i in range(len(l)):
#     print(l[i])


#迭代器


#可迭代的：只要对象本身有__iter__方法，那它就是可迭代的
# d={'a':1,'b':2,'c':3}
# d.__iter__ #iter(d)
#
#
#执行对象下的__iter__方法，得到的结果就是迭代器
# i=d.__iter__()
#
# print(i.__next__())
# print(i.__next__())
# print(i.__next__())
# print(i.__next__())



# d={'a':1,'b':2,'c':3}
# i=iter(d)
# # while True:
# #     try:
# #         print(next(i))
# #     except StopIteration:
# #         break
#
#
#
# l=['a','b','c','d','e']
# i=l.__iter__()
# while True:
#     try:
#         print(next(i))
#     except StopIteration:
#         break



# d={'a':1,'b':2,'c':3}
# d.__iter__
#
#
# for k in d: #d.__iter__()
#     print(k)
#
#
# s={1,2,3,4}
# for i in s:
#     print(i)

# with open('a.txt','r') as f:
#     for line in f:
#         print(line)


# f=open('a.txt','r')
# f.__next__
# f.__iter__
# print(f)
# print(f.__iter__())
#
# for line in f: #f.__iter__()
#     print(line)

# i=f.__iter__()

# while True:
#     try:
#         print(next(i))
#     except StopIteration:
#         break


#为什么要用迭代器：
    #优点
    # 1：迭代器提供了一种不依赖于索引的取值方式，这样就可以遍历那些没有索引的可迭代对象了（字典，集合，文件）
    # 2：迭代器与列表比较，迭代器是惰性计算的，更节省内存

    #缺点：
    # 1：无法获取迭代器的长度，使用不如列表索引取值灵活
    # 2：一次性的，只能往后取值，不能倒着取值


# l=[1,2,3]
# # print(len(l))
# i=iter(l)
#
# print(next(i))
# print(next(i))
# print(next(i))
# # print(next(i))
#
#
# for x in i:
#     print(x)
#
# for x in i:
#     print(x)
#
# for x in i:
#     print(x)
# for x in i:
#     print(x)



#查看可迭代对象与迭代器对象

from collections import Iterable,Iterator

s='hello'
l=[1,2,3]
t=(1,2,3)
d={'a':1}
set1={1,2,3,4}
f=open('a.txt')

#都是可迭代的
# s.__iter__()
# l.__iter__()
# t.__iter__()
# d.__iter__()
# set1.__iter__()
# f.__iter__()
# print(isinstance(s,Iterable))
# print(isinstance(l,Iterable))
# print(isinstance(t,Iterable))
# print(isinstance(d,Iterable))
# print(isinstance(set1,Iterable))
# print(isinstance(f,Iterable))

#查看是否是迭代器
print(isinstance(s,Iterator))
print(isinstance(l,Iterator))
print(isinstance(t,Iterator))
print(isinstance(d,Iterator))
print(isinstance(set1,Iterator))
print(isinstance(f,Iterator))

















