#/usr/bin/env python
import time
#定义阶段：定义俩生成器函数
def tail(file_path):
    with open(file_path,'r') as f:
        f.seek(0,2)
        while True:
            line=f.readline()
            if not line:
                time.sleep(0.3)
#                print('====>')
                continue
            else:
                #print(line,end='')
                yield line

def grep(pattern,lines):
    for line in lines:
        if pattern in line:
            yield line

#调用阶段：得到俩生成器对象
g1=tail('/tmp/a.txt')
g2=grep('error',g1)

#next触发执行g2生成器函数
for i in g2:
    print(i)
