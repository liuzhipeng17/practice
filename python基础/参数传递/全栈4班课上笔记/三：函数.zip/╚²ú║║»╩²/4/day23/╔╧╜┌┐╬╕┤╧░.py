# def aaa(func):
#     def bbb(*args,**kwargs):
#         res=func(*args,**kwargs)
#         return res
#     return bbb
# def auth2(x,y,z):
#     def auth(func):
#         def wrapper(*args,**kwargs):
#             #认证功能
#             res=func(*args,**kwargs)
#             return res
#         return wrapper
#     return auth
#
#
#
# @auth(1,2,3)
# def index():
#     print('from index')
#
# index()



import time
from functools import wraps
def timmer(func):
    @wraps(func)
    def wrapper(*args,**kwargs):
        'sssssssssssss'
        start_time=time.time()
        func(*args,**kwargs) #home(name)
        stop_time=time.time()
        print('run time is %s' %(stop_time-start_time))
    return wrapper


@timmer
def func(x):
    'func test'
    print(x)

func(1)
print(func.__doc__)
# print(help(func))