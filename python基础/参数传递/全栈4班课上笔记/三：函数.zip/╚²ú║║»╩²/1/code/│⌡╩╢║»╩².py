#内置函数sum max len
# print(print)

#自定义函数
'''
*************
*************
alex SB SB
*************
*************
'''

def print_line():
    print('*'*13)

def print_msg():
    print('alex SB SB')


# print_line()
# print_line()
# print_msg()
# print_line()
# print_line()


'''
def 函数名(arg1,arg2,arg3):
    '描述信息'
    函数体
    return 1

'''
#先定义，后使用



#定义无参函数
# def tell_cmd():
#     msg='''
#     1 查看
#     2 购买
#     '''
#     print(msg)

def foo():
    'foo function'
    print('from the foo')
# print(foo.__doc__)


#定义有参函数

def bar(x,y):
    print(x)
    print(y)





#定义空函数
def auth():
    pass




def auth():
    '认证'
    pass

def list_goods():
    '商品列表'
    pass

def buy(money,goods):
    '购买'
    pass

def interactive():
    '与用户交互'
    list_goods()
    money=input(">> ")
    goods=input(">> ")
    buy(money,goods)





#函数的调用
foo() #定义时无参，调用也无参
bar(1,2) #定义时有参，调用时需要传参