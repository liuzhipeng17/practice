#函数的参数介绍
#
# def foo(x,y):
#     print(x)
#     print(y)


#在实参的角度

#第一种：按照位置传值
# foo(1,2)
# foo(2,1)


#第二种：按照关键字传值
# foo(x=1,y=2)
# foo(y=2,x=1)

#第三种：混着用
# foo(1,y=2)
#问题一：按位置传值必须在按关键字传值的前面
# foo(y=2,1) #报错
#问题一：对于一个形参只能赋值一次
# foo(1,y=2)


#从形参的角度来分析

#位置参数：必须传值的参数
# def foo(x,y):
#     print(x)
#     print(y)
#
# foo(1,2,3)
# # foo(y=2,x=1)


#默认参数
def foo(x,y=1):
    print(x)
    print(y)

# # foo(1)
# foo(1,2)
# foo(y=2,x=2)


# def open(file,mode='r'):
#     pass
#
# open('a.txt')



# def register(name,sex='male'):
#     print(name)
#     print(sex)
#
# register('qinzhen')


#默认参数必须注意的问题是：默认参数必须放到位置参数的后面
# def register(sex='male'): #报错
#     print(name)
#     print(sex)
# register()
# # register('qinzhen')

# x='male'
# def register(sex=x): #    register-------------[sex='male'  ...]
#     print(sex)
# #------------------------------------------------
# x=None
# register()


#不推荐下述方式
# x=[]
# def register(name,name_list=x): #
#     name_list.append(name)
# #------------------------------------------------
# register('ASB')
# register('YSB')
# register('WSB')
# print(x)
#



#*args
# def foo(x,*args): #args=(2, 3, 4, 5, 6, 6, 'a', 'b')
#     print(x)
#     print(args)
#
# foo(1,2,3,4,5,6,6,'a','b')


# #*args与位置参数和默认参数混用:*args要放到位置参数后面
# def foo(x,*args,y=1):
#     print(x)
#     print(y)
#     print(args)
#
# foo(1,2,3,4,5,6,7,8,9,10,y=10000000)


#从形参的角度
def foo(*args):  #foo(x,y,z)
    print(args)

# foo(1,2,3)

#*args=*(1,2,3）
#从实参的角度
def bar(x,y,z):
    print(x)
    print(y)
    print(z)
# bar(*(1,2,3,4)) #bar(1,2,3,4)





# def my_sum(*nums): #nums=(1,2,3,4,5,6,7)
#     res=0
#     for i in nums:
#         res+=i
#     return res
#
# # print(my_sum((1,2,3,4,5)))
# print(my_sum(1,2,3,4,5,6,7))






#**kwargs
# def foo(x,**kwargs):
#     print(x)
#     print(kwargs)
#
# foo(1,y=1,z=2)

#混着用的位置问题
# def foo(x,*args,**kwargs):
#     print(x)
#     print(args)
#     print(kwargs)
#
# foo(1,y=1,z=2)


# def foo(*args,**kwargs):
#     print(args)
#     print(kwargs)
#
# foo(1,1,1,1,1,1,a=1,b=2)


#从形参的角度
def foo(**kwargs): #x=1,y=2
    print(kwargs)

#
# foo(x=1,y=2,z=3)

#从实参的角度
# def foo(x,y,z=1):
#     print(x)
#     print(y)
#     print(z)


# foo(**{'x':1,'y':2,'z':3})  #foo(x=1,y=2,z=2)
# foo(**{'x':1,'y':2})  #foo(x=1,y=2)
# foo(**{'a':1,'y':2})  #foo(a=1,y=2)


def auth(name,password,sex='male'):
    print(name)
    print(password)
    print(sex)

def foo(*args,**kwargs): #args=('egon','123') kwargs={}
    print('from foo')
    auth(*args,**kwargs)
    # auth(*'egon','123'),**{})--->auth('egon','123')

# foo('egon','123')
# foo('ASB','123',sex='female')
foo(name='ASB',password='123',sex='female')



