#函数的返回值可以是任意类型
#没有return--->None
#return 1--->1
#return 1,2,3--->(1,2,3)

def foo():
    print('from the foo')
#
# res=foo()
# print(res)



def my_max(x,y):
    res=x if x > y else y
    return res

# res1=my_max(1,2)
# print(res1)


def bar(x,y):
    # return (1,2,3,4,5,6,[1,2],{'a':2},{1,2,3})
    return 1,2,3

# res2=bar(1,2)
# print(res2)

# a,b,c=bar(1,2)
# print(a)
# print(b)
# print(c)


def test():
    return 1
    print('--------------')
    print('--------------')
    print('--------------')
    print('--------------')
    print('--------------')
    print('--------------')
    print('--------------')
    print('--------------')
    return 2
    return 3

res=test()
print(res)