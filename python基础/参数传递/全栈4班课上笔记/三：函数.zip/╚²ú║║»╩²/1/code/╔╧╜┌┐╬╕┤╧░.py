f=open('a.txt','w')
f.write('1111111111111111\n')
f.write('1111111111111111\n')
f.write('1111111111111111\n')
f.write('1111111111111111\n')
f.write('1111111111111111\n')
f.write('1111111111111111\n')
# f.writelines(['111111\n','1111111\n'])
f.seek(0)
# f.truncate(3)
f.close()

with open('a.txt') as f,open('b.txt') as f2:
    pass
