# def auth():
#     name = input('username: ')
#     pwd = input('password: ')
#     if name == 'egon' and pwd == '123':
#         print('login successful')
#     else:
#         print('login error')
#
# auth()
# auth()
#
#
# def my_max(x,y):
#     """x->int,y->int,res=int,cal max value"""
#     res=x if x > y else y
#     return res
#
# print(my_max(1,2))
# print(my_max('a','b'))
# print(my_max('a',1))




# def my_min(x:int,y:int)->int:
#     print(x if x < y else y)
#
# my_min(1,2)
# my_min('a','b')
# print(my_min.__annotations__)




#函数的参数介绍


#形参和实参的概念

x=100000000

def foo(x,y): #在函数定义阶段，括号内定义的参数-》形式参数----》本质就是变量名
    print(x)

    print(y)

# foo(1,2) ##在函数调用阶段，括号内定义的参数-》实际参数-->实参必须要有一个明确的值，可被当成变量值，

# a=100
# b=200
# foo(a,b)




def bar(x): #x=[1,2,3]
    # print(x)
    # x=3
    x.append(4)


# x=1
# bar(x)
# print(x)


x=[1,2,3]
#
# bar(x)


