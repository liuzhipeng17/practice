'''
def 函数名(arg1,arg2,arg3):
    '描述信息'
    函数体
    return 1

'''

def foo():
    print('from the foo')


def bar(x,y):
    print('from bar')
    res=x+y
    return res


# foo() #函数调用的语句形式
# res=bar(1,2) #函数调用的表达式形式
# res1=bar(1,2)*10 #函数调用的表达式形式
# print(res1)


res2=bar(bar(1,2),3) #函数的调用作为另外一个函数的参数

print(res2)