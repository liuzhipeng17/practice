name=input('username: ')
pwd=input('password: ')
if name == 'egon' and pwd == '123':
    print('login successful')
else:
    print('login error')

print('====')
print('====')
print('====')
print('====')
print('====')
name = input('username: ')
pwd = input('password: ')
if name == 'egon' and pwd == '123':
    print('login successful')
else:
    print('login error')
