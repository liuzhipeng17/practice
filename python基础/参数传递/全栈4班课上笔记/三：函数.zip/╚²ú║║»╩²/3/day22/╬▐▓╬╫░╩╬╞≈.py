#为什么要用装饰器及开放封闭原则

#什么是装饰器
# import time
# def timmer(func):
#     def wrapper(*args,**kwargs):
#         start=time.time()
#         res=func(*args,**kwargs)
#         stop=time.time()
#         print('run time is %s ' %(stop-start))
#     return wrapper
#
#
# @timmer
# def index():
#     time.sleep(3)
#     print('welcome to oldboy')
#
# index()





#装饰器
# import time
#
# @名字     #home=名字(home)
# def home():
#     time.sleep(3)
#     print('welcome to oldboy')
#
# index()


# def get(url):
#     def index():
#         return urlopen(url).read()
#     return index


import time
def timmer(func): #func=home
    def wrapper():
        # print(func)
        start_time=time.time()
        func()
        stop_time=time.time()
        print('run time is %s' %(stop_time-start_time))
    return wrapper


# index=timmer(index)
@timmer
def index():
    time.sleep(3)
    print('welcome to oldboy')

@timmer
def home(name):
    time.sleep(2)
    print('welcome to %s home page' %name)

# def my_max(x,y):
#     print('from my_max func')
#     return x+y

# index()  #--=--->wrapper()
home('dragon')
