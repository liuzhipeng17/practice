def auth2(auth_type):
    def auth(func):
        # print(auth_type)
        def wrapper(*args,**kwargs):
            if auth_type == 'file':
                name=input('username: ')
                password=input('password: ')
                if name == 'zhejiangF4' and password == 'sb945':
                    print('auth successfull')
                    res=func(*args,**kwargs)
                    return res
                else:
                    print('auth error')
            elif auth_type == 'sql':
                print('还他妈不会玩')
        return wrapper
    return auth

@auth2(auth_type='sql') #@auth  #index=auth(index)
def index():
    print('welcome to inex page')

# @auth
# def home():
#     print('welcome to home page')
index()