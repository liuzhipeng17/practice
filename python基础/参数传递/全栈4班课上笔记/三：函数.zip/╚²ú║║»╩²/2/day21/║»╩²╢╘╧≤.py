# def foo():
#     print('foo')


# print(foo)

#函数可以被赋值
# f=foo
# print(f)
# f()


#把函数当成参数传递
# def bar(func):
#     print(func)
#     func()
#
# bar(foo)

#把函数当成返回值
# def bar(func):
#     print(func)
#     return func
#
# f=bar(foo)
# print(f)
# f()



#把函数当做容器类型的元素去用
def add():
    print('=============>function add')
def search():
    print('=============>function search')
def delete():
    print('=============>function delete')
def change():
    print('=============>function change')
def tell_msg():
    msg='''
    search：查询
    add：添加
    delete：删除
    change：修改
    create：新建
    '''
    print(msg)
def create():
    print('function ---->create')

cmd_dic={
    'search':search,
    'add':add,
    'delete':delete,
    'change':change,
    'create':create
}


while True:
    tell_msg()
    choice=input('please input your choice: ').strip()
    # print(cmd_dic[choice])
    cmd_dic[choice]()


