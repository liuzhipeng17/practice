
x=1
def func():
    print('from func')
    x=2
    a=1
    b=2
    print(globals())
    print(locals())

# a=globals()
func()
# b=locals()

# print(a == b)