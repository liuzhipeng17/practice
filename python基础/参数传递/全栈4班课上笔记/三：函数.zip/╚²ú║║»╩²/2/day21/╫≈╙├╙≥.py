
#
# x=1
# def foo():
#     x=1000
#     print(x)
#
# foo()
# print(x)


#！！！先定义后使用


def foo():
    print('from foo')
    bar()

foo()
def bar():
    print('from bar')

