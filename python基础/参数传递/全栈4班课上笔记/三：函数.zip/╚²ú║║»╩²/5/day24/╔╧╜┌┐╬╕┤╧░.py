# def func():
#     n = 0
#     while n < 5:
#         yield n
#         n += 1
#
#
# g = func()
#
# res = next(g)
# res = next(g)
#
# for i in g:
#     print(i)


def eater(name):
    print('%s start to eat' % name)
    food_list=[]
    while True:
        food = yield food_list
        print('%s eat %s' % (name, food))
        food_list.append(food)

e = eater('zhejiangF4')
# print(e)
next(e) #e.send(None)

print(e.send('123'))


