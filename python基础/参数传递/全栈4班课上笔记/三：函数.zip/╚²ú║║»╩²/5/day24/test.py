import os

g=os.walk('C:\\egon')

for i in g:
    # print(i)
    for j in i[-1]:
        file_path='%s\\%s' %(i[0],j)
        print(file_path)