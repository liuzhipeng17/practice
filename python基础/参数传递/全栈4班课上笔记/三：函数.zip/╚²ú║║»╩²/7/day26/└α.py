
class Garen:
    camp='Demacia'
    def attack(self):
        print('attack')


#如何使用类
#一：实例化
# x=int(10)
# print(x)

# obj=Garen() #实例化
# print(obj)

#二：引用类的特征（类的变量）和技能（类的函数）
# print(Garen.camp)
# print(Garen.attack)
# Garen.attack(1231231)



#如何使用实例
# class Garen:
#     camp='Demacia'
#
#     def __init__(self,nickname):
#         self.nick=nickname  #g1.nick='草丛伦'
#     def attack(self,enemy):
#         # print('---------->',self.nick) #g1.nick
#         print('%s attack %s' %(self.nick,enemy))
#
#
# g1=Garen('草丛伦') #Garen.__init___(g1,'草丛伦')
# g2=Garen('猥琐轮')
# print(g1.nick)
# g1.attack('alex')


# print(g1.nick)
# print(g1.camp)
# print(g1.attack)
# print(Garen.attack)


# Garen.attack() #调用的是函数
# g1.attack() #self=g1
# Garen.attack(g1)



#
# print(g2.nick)
# print(g2.camp)







#总结：
#类：一：实例化，二：引用名字（类名.变量名，类名.函数名）
#实例：引用名字（实例名.类的变量，实例名.绑定方法，实例名.实例自己的变量名）

class Garen:
    camp='Demacia'

    def __init__(self,nickname):
        self.nick=nickname  #g1.nick='草丛伦'
    def attack(self,enemy):
        # print('---------->',self.nick) #g1.nick
        print('%s attack %s' %(self.nick,enemy))

# print(Garen.camp) #查
# Garen.camp='aaaaaa' #改
# print(Garen.camp)
#
# # del Garen.camp #删除
# # print(Garen.camp)
#
# Garen.x=1
# print(Garen.x)


g1=Garen('alex')
# print(g1.nick)
# g1.nick='asb'
# print(g1.nick)
# del g1.nick
# print(g1.nick)

# g1.sex='female'
# print(g1.sex)

