#round:四舍六入五留双
print(round(3.4))
print(round(11.3))
print(round(11.5))
print(round(12.5))
print(round(12.6))
