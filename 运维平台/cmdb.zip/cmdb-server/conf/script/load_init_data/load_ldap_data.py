from ldap3 import Server, Connection, SUBTREE
from conf import settings
import requests
from tornado.log import app_log
import traceback
import json
configs = settings['ldap']

dict_map = {

    'mobile': 'phone',
    'cn': 'username',
    'displayName': 'fullname',
    'mail': 'email'

}

# api = 'http://10.10.50.30/api'
api = 'http://127.0.0.1:8010/api'
# api = 'http://cmdb.ops.yunnex.com/api'


class ldap(object):
    def __init__(self, ldap_server, port, baseDN, user, password):
        self.ldap_server = ldap_server
        self.port = port
        self.baseDN = baseDN
        self.user = user
        self.password = password
        self.ldap_error = None
        try:
            self.server = Server(self.ldap_server, port=int(self.port))
            self.conn = Connection(self.server, user=self.user, password=self.password, auto_bind=True, authentication='SIMPLE')
        except Exception as e:
            self.ldap_error = e
    def search_user(self):
        if self.ldap_error is None:
            self.result = self.conn.search(search_base=self.baseDN,
                                           search_filter='(objectClass=inetOrgPerson)',
                                           # search_filter='(cn=' + username + ')',
                                           search_scope=SUBTREE,
                                           attributes=['cn', 'mobile', 'displayName', 'mail'],
                                           paged_size=10000)
            list_info = []
            for entry in self.conn.entries:
                self.res = entry.entry_to_json()
                self.res = json.loads(self.res)
                dep_list = []
                self.info = {}
                for attr in self.res['attributes']:
                    if self.res['attributes'][attr]:
                        self.info.update({dict_map[attr]: self.res['attributes'][attr][0]})
                    self.group = [i for i in self.res['dn'].split(',') if i.startswith('ou=') and i.endswith('部')]
                    if self.group:
                        self.group = self.group[0].split('=')[1]
                if self.group:
                    dep_list.append(self.group)
                self.info.update({'department_name': dep_list})
                list_info.append(self.info)
            # self.conn.unbind()
            return list_info


def get_token():
    url = api + '/token'
    data = {
        'username': 'devops',
        'password': 'GRjPXl1bm5'
    }
    res = requests.post(url, json=data)
    if res.status_code == 200:
        return [True, res.json()['res']]
    else:
        return [False, res.text]


def get_user_info(**kwargs):
    flag, headers = get_token()
    if flag:
        try:
            server = api
            get_path = '/user?username=' + str(kwargs['username'])
            result = requests.get(server + str(get_path), headers=headers).json()['res']
            path = '/user'
            if not result:
                data = kwargs
                res = requests.post(server + path, json=data, headers=headers)
                if res.status_code == 200:
                    app_log.info("user add data: " + str(kwargs))
                    return res.json()['res']['id']
                else:
                    print(res.text)
                    return
            else:
                kwargs.update({"id": result[0]['id']})
                data = kwargs
                res = requests.put(server + path, json=data, headers=headers)
                if res.status_code == 200:
                    app_log.info("user update data: " + str(kwargs))
                    return res.json()['res']['id']
                else:
                    print(res.text)

        except Exception as e:
            print(e)
            print(traceback.format_exc())
            return
    else:
        print([flag, headers])

def get_department(**kwargs):
    flag, headers = get_token()
    if flag:
        try:
            server = api
            get_path = '/department?name=' + str(kwargs['name'])
            result = requests.get(server + str(get_path), headers=headers).json()['res']
            path = '/department'
            if not result:
                data = kwargs
                res = requests.post(server + path, json=data, headers=headers)
                if res.status_code == 200:
                    app_log.info("department add data: " + str(kwargs))
                    return res.json()['res']['id']
                else:
                    print(res.text)
                    return
            else:
                kwargs.update({"id": result[0]['id']})
                data = kwargs
                res = requests.put(server + path, json=data, headers=headers)
                if res.status_code == 200:
                    app_log.info("department update data: " + str(kwargs))
                    return res.json()['res']['id']
                else:
                    print(res.text)

        except Exception as e:
            print(e)
            print(traceback.format_exc())
            return
    else:
        print([flag, headers])


def get_user_department(**kwargs):
    flag, headers = get_token()
    if flag:
        try:
            server = api
            get_path = '/user_department?user_id=' + str(kwargs['user_id']) + '&department_id=' + str(kwargs['department_id'])
            result = requests.get(server + str(get_path), headers=headers).json()['res']
            path = '/user_department'
            if not result:
                data = kwargs
                res = requests.post(server + path, json=data, headers=headers)
                if res.status_code == 200:
                    app_log.info("user_department add data: " + str(kwargs))
                    return res.json()['res']['id']
                else:
                    print(res.text)
                    return
            else:
                kwargs.update({"id": result[0]['id']})
                data = kwargs
                res = requests.put(server + path, json=data, headers=headers)
                if res.status_code == 200:
                    app_log.info("user_department update data: " + str(kwargs))
                    return res.json()['res']['id']
                else:
                    print(res.text)

        except Exception as e:
            return
    else:
        print([flag, headers])



if __name__ == '__main__':

    ldap = ldap(configs['ldap_server'], configs['port'], configs['baseDN'], configs['user'], configs['password'])
    info = ldap.search_user()
    for i in info:
        print(i)
        department = i.pop('department_name')
        user = i
        get_user_id = get_user_info(**user)
        if department:
            for i in department:
                get_department_id = get_department(**{'name': i})
                if get_user_id and get_department_id:
                    get_user_department(user_id=get_user_id, department_id=get_department_id)







