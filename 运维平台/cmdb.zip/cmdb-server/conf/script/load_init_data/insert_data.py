import requests
import json
import time

with open('conf/script/load_init_data/data/data.json', 'r', encoding='utf-8') as json_file:
    data = json.load(json_file)

with open('conf/script/load_init_data/data/Uhost.json', 'r', encoding='utf-8') as json_file:
    UHOST = json.load(json_file)
with open('conf/script/load_init_data/data/host_excel.json', 'r', encoding='utf-8') as json_file:
    HOST_APP_BUS = json.load(json_file)["res"]
with open('conf/script/load_init_data/data/applications_wiki.json', 'r', encoding='utf-8') as json_file:
    APPLICATIONS = json.load(json_file)['res']

with open('conf/script/load_init_data/data/application_business.json', 'r', encoding='utf-8') as json_file:
    APPLICATIONS_BUSINESS = json.load(json_file)['res']

DEPARTMENT_LIST = data['department_list']
GROUP_LIST = data["group_dict"]

BASE_URL = 'http://cmdb.ops.yunnex.com'

'''
todo :
1. applications  not build relationship with business_group
'''


def insert_department():
    '''
    department
    1. insert department
    2. if not exist ,insert department else pass
    :return:
    '''
    for department in DEPARTMENT_LIST:
        url = BASE_URL + '/api/department?name=%s' % department

        response = requests.get(url)
        effect_row = 0
        if not len(response.json()['res']) > 0:
            requests.post(url=BASE_URL + '/api/department', json={'name': department})
            effect_row += 1
    print("insert_department effect_row：", effect_row)


def insert_business():
    '''
    business_group
    1. database not exists the record
    2. get department_id by department name
    3. if not exist ,insert department else pass
    :return:
    '''

    for group, department in GROUP_LIST.items():
        group_url = BASE_URL + '/api/business_group?name=%s' % group
        response = requests.get(group_url)
        effect_row = 0
        if not len(response.json()['res']) > 0:  # 数据库中不存在该条记录
            url = BASE_URL + '/api/department?name=%s' % department
            de_res = requests.get(url)
            department_id = de_res.json()['res'][0]['id']
            print(department_id)
            response = requests.post(url=BASE_URL + '/api/business_group',
                                     json={'name': group, 'department_id': department_id})
            print(response)
            effect_row += 1

    print("insert_business effect_row：", effect_row)


def insert_application():
    '''
    application
    1. get department_id  by department name
    2. get business_group_id by business_group name
    3. if exist , update else add
    :return:
    '''
    depart_res = requests.get(BASE_URL + '/api/department?page=1&page_size=10000')
    business_res = requests.get(BASE_URL + '/api/business_group?page=1&page_size=10000')

    depart_dict = {}
    for depart in depart_res.json()['res']:  # department name id make a dict
        depart_dict[depart['name']] = depart['id']

    business_dict = {}
    for ii in business_res.json()['res']:  # business name id make a dict
        business_dict[ii['name']] = ii['id']

    # application_business = {}
    # for ii in APPLICATIONS_BUSINESS:  # application 与 business_group 之间的关系表
    #     print (ii)
    #     business_group_id = business_dict[ii['business_group'].upper()]
    #     application_business[ii['name']] = {
    #         'business_group_id': business_group_id,
    #         'port': int(ii['port']) if len(ii['port'].replace(' ', '')) > 0 else 0
    #     }

    add_num = 0
    update_num = 0
    for ii in APPLICATIONS:
        department_name = ii['department_name'].replace('\xa0' or ' ', '')
        department_id = depart_dict[department_name]
        application_name = ii['name']
        response = requests.get(BASE_URL + '/api/application?name=%s' % application_name)
        info = {
            # 'name': ii['name'],
            'note': ii['note'],
            # 'application_type': ii['application_type'],
            'department_id': department_id,
            # 'business_group_id': application_business[ii['name']]['business_group_id'] if ii[
            #                                                                                   'name'] in application_business.keys() else 0,
            # 'port_number': application_business[ii['name']]['port'] if ii['name'] in application_business.keys() else 0

        }

        if not len(response.json()['res']) > 0:  # 根据名称查找，不存在，add
            # requests.post(url=BASE_URL + '/api/application',
            #               json=info)
            print(info)
            add_num += 1
        else:  # 根据名称查找，存在，update
            _id = response.json()['res'][0]['id']
            info.update({'id': _id})
            requests.put(url=BASE_URL + '/api/application',
                         json=info)
            update_num += 1
            print(response.json()['res'], info)
            # break
        print("add_num : %d ,update_num :%d" % (add_num, update_num))


def host_disk(host_id, disk_list):
    '''
    1. get from database
    2. if exist update
    3. else  add
    :param host_id:
    :param disk_list:
    :return:  add_num,update_num
    '''
    add_num = 0
    update_num = 0
    total_size = 0

    for disk in disk_list:

        tag = disk['tag']
        size = disk['size']
        total_size += size
        disk_res = requests.get(BASE_URL + "/api/host_disk?host_id=%d&tag=%s" % (host_id, tag))
        disk.update({"host_id": host_id})

        if len(disk_res.json()['res']) > 0:  # update
            disk_id = disk_res.json()['res'][0]['id']
            disk.update({"id": disk_id})
            disk_update_res = requests.put(BASE_URL + "/api/host_disk", json=disk)
            # print("disk_update_res:", disk_update_res.json())
            update_num += 1
        else:  # add
            disk_add_red = requests.post(BASE_URL + "/api/host_disk", json=disk)
            # print("disk_add_red:", disk_add_red.json())
            add_num += 1
    return [add_num, update_num, total_size]


def host_ip(network_interface_id, ip):
    '''
     1. get from database
    2. if exist update
    3. else  add
    :param network_interface_id:
    :param ip:
    :return:
    '''
    add_num = 0
    update_num = 0
    ip.update({"host_network_interface_id": network_interface_id})
    ip_addr = ip['ip_addr']
    ip_res = requests.get(
        BASE_URL + "/api/ip?ip_addr=%s&host_network_interface_id=%s" % (ip_addr, network_interface_id))
    if len(ip_res.json()["res"]) > 0:  # update
        ip_id = ip_res.json()["res"][0]['id']
        ip.update({"id": ip_id})
        ip_res = requests.put(BASE_URL + "/api/ip", json=ip)
        # print("ip_update_res:", ip_res.json())
        update_num += 1
    else:  # add
        ip_res = requests.post(BASE_URL + "/api/ip", json=ip)
        # print("ip_add_res:", ip_res.json())
        add_num += 1
    return [add_num, update_num]


def insert_host():
    ''''
    add or update
    host/ip/host_disk/host_network_interface

    '''
    start = time.time()
    add_num = 0
    update_num = 0
    disk_add_num = 0
    disk_update_num = 0
    ip_add_num = 0
    ip_update_num = 0
    network_interface_add_num = 0
    network_interface_update_num = 0
    j = 0
    for ii in UHOST:
        host_set = ii["HostSet"]
        print(ii["ProjectId"], ii["ProjectName"], ii["TotalCount"])
        for info in host_set:
            # print("info:", info)
            hostname = info["hostname"]
            response = requests.get(BASE_URL + '/api/host?hostname=%s' % hostname)
            if not len(response.json()['res']) > 0:  # 数据库不存在记录 ，插入记录
                requests.post(url=BASE_URL + '/api/host', json=info)
                add_num += 1
            else:
                res = response.json()['res'][0]
                host_id = res['id']
                info.update({"id": host_id})
                disk_list = info.pop("disk", [])
                network_interface_list = info.pop("network_interface", [])

                # host_disk
                a_num, u_num, disk_total_size = host_disk(host_id, disk_list)
                disk_add_num += a_num
                disk_update_num += u_num

                # update  host
                info.update({"disk_total": disk_total_size})
                requests.put(BASE_URL + '/api/host', json=info)

                for network_interface in network_interface_list:
                    ip = network_interface.pop("ip")

                    network_interface.update({"host_id": host_id})
                    name = network_interface['name']
                    mac_addr = network_interface['mac_addr']
                    network_interface_res = requests.get(
                        BASE_URL + "/api/host_network_interface?host_id=%d&name=%s&mac_addr=%s" % (
                            host_id, name, mac_addr))
                    if len(network_interface_res.json()["res"]) > 0:  # udpate
                        network_interface_id = network_interface_res.json()["res"][0]["id"]
                        network_interface.update({"id": network_interface_id})
                        net_res = requests.put(BASE_URL + "/api/host_network_interface", json=network_interface)
                        # print("net update:", net_res.json())
                        network_interface_update_num += 1
                    else:  # add
                        net_res = requests.post(BASE_URL + "/api/host_network_interface", json=network_interface)
                        # print("net add:", net_res.json())
                        network_interface_id = net_res.json()["res"]["id"]
                        network_interface_add_num += 1

                    # ip
                    a_num, u_num = host_ip(network_interface_id, ip)
                    ip_add_num += a_num
                    ip_update_num += u_num

                update_num += 1

            # print("-------")
            if j > 600:
                break
            j += 1;

    print("add_num :%d , udpate_num : %d" % (add_num, update_num))
    print("disk_add_num :%d,disk_update_num : %d" % (disk_add_num, disk_update_num))
    print("ip_add_num :%d,ip_update_num : %d" % (ip_add_num, ip_update_num))
    print("network_interface_add_num :%d ,network_interface_update_num :%d" % (
        network_interface_add_num, network_interface_update_num))
    print("spend time in %d s" % (time.time() - start))


def host_application():
    success_num = 0
    update_num = 0
    unknown_num = 0
    not_found_num = 0
    start = time.time()
    for info in APPLICATIONS_BUSINESS:
        hostname = info["hostname"]
        name = info['name']

        host_url = BASE_URL + '/api/host?hostname=%s' % hostname
        host_res = requests.get(host_url)

        if len(host_res.json()["res"]) > 0:
            host_id = host_res.json()["res"][0]["id"]
        else:
            print("not found host_id,the application is %s " % hostname)
            print("host_name : %s,applciation_name: %s" % (hostname, name))
            not_found_num += 1
            continue

        app_res = requests.get(BASE_URL + "/api/application?name=%s" % name)
        if len(app_res.json()["res"]) > 0:
            application_id = app_res.json()["res"][0]["id"]
        else:
            print("not found application_id,the application is %s " % name)
            print("host_name : %s, application_name: %s" % (hostname, name))
            not_found_num += 1
            continue

        argus = {"host_id": host_id, "application_id": application_id}
        host_application_res = requests.post(BASE_URL + "/api/host_application", json=argus)
        if host_application_res.json()['code'] == 200:
            success_num += 1
        elif host_application_res.json()['code'] == 400:
            update_num += 1
        else:
            unknown_num += 1

            # print(host_application_res.json())
    print("success_num: %d, error_num :%d, unknown_num: %d ,not_found_num :%d" % (
        success_num, update_num, unknown_num, not_found_num))
    print("spend time in %d s" % (time.time() - start))


if __name__ == '__main__':
    import re

    # NUM_PATTERN = re.compile(r'[0-9]')
    # insert_department()
    # insert_business()
    insert_application()
    # insert_host()
    # host_application()
