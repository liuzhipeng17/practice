# -*-coding:utf-8 -*-
import pymysql

from conf import settings


def ConnectToMysqlDb():
    mysql_conf = settings['mysql']
    print(mysql_conf)
    conn = pymysql.connect(
        host=mysql_conf['host'],
        port=mysql_conf['port'],
        user=mysql_conf['username'],
        passwd=mysql_conf['password'],
        db=mysql_conf['database'],
        charset=mysql_conf['config']['encoding']
    )
    cur = conn.cursor()
    return conn, cur


def main():
    sql = """show tables;"""
    conn, cur = ConnectToMysqlDb()
    cur.execute(sql)
    tables = [t[0] for t in cur.fetchall()]
    for table in tables:
        if table != 'cmdb_ids':
            alter_sql = '''ALTER TABLE `cmdb`.`%s` CHANGE COLUMN `id` `id` BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'id' ;''' % table
            print(alter_sql)
            cur.execute(alter_sql)
    conn.commit()


if __name__ == '__main__':
    main()
