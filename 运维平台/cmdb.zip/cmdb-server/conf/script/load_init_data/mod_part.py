import json
import requests

from db import mysql, sqlalchemy_util
from conf.script.load_init_data import excel_data
from db.tables import Tables

with open('conf/script/load_init_data/data/data.json', 'r', encoding='utf-8') as json_file:
    data = json.load(json_file)
DEPARTMENT_LIST = data['department_list']
GROUP_LIST = data["group_dict"]


def print_mod():
    mod_dict = {}
    for mod_str in MOD_STR_LIST:
        params_list = mod_str.split('\t')
        mod_dict[params_list[0]] = {
            'type': params_list[1],
            'department': params_list[2]
        }
        print('%s' % params_list[2])


def get_hostid_by_hostname(hostname):
    try:
        response = requests.get('http://127.0.0.1:9999/host?hostname=%s' % hostname)
        return response.json()['res'][0]['id']
    except:
        return -1


def get_appid_by_appname(appname):
    try:
        response = requests.get('http://127.0.0.1:9999/application?name=%s' % appname)
        return response.json()['res'][0]['id']
    except:
        return -1


def get_groupid_by_appname(group):
    try:
        response = requests.get('http://127.0.0.1:9999/business_group?name=%s' % group)
        return response.json()['res'][0]['id']
    except:
        return -1


def insert_host_app():
    host_list = excel_data.read_host_list()
    sessionmaker = mysql.connect()
    session = sessionmaker()
    for host in host_list:
        appstr = host['application']

        for app in appstr.split('\n'):

            appname = app
            appport = 0
            if ':' in app:
                appname = app.split(':')[1]
                appport = app.split(':')[0]

            hostname = host['hostname']
            business_group = host['business_group']

            host_id = get_hostid_by_hostname(hostname)
            app_id = get_appid_by_appname(appname)
            group_id = get_groupid_by_appname(business_group)

            print('hostname: %s, hostid: %s, business_group: %s, group_id: %s,appname: %s, appid: %s, port: %s' % (
                hostname, host_id, business_group, group_id, appname, app_id, appport))
            if host_id != -1 and app_id != -1:
                host_application_instance = Tables.host_application(**{
                    'host_id': host_id,
                    'application_id': app_id
                })
                session.add(host_application_instance)


def update_application():
    host_list = excel_data.read_host_list()
    sessionmaker = mysql.connect()
    session = sessionmaker()
    for host in host_list:
        appstr = host['application']

        for app in appstr.split('\n'):

            appname = app
            appport = 0
            if ':' in app:
                appname = app.split(':')[1]
                appport = app.split(':')[0]

            hostname = host['hostname']
            business_group = host['business_group']

            host_id = get_hostid_by_hostname(hostname)
            app_id = get_appid_by_appname(appname)
            group_id = get_groupid_by_appname(business_group)

            print('hostname: %s, hostid: %s, business_group: %s, group_id: %s,appname: %s, appid: %s, port: %s' % (
                hostname, host_id, business_group, group_id, appname, app_id, appport))
            if host_id != -1 and app_id != -1:
                sqlalchemy_util.update(session, Tables.application, filters={'id': app_id},
                                       up_argus={'business_group_id': group_id})


if __name__ == '__main__':
    print_mod()
