import json
import re


def dump_file(out_path, data_obj):
    with open(out_path, "w", encoding="UTF-8") as f_dump:
        json.dump(data_obj, f_dump, ensure_ascii=False)


def deal_application_name(app_name):
    '''
    from excel ,deal application_name
    :param app_name:
    :return:
    '''
    res = []
    apps = app_name.split(' \n')
    if len(apps) == 1:
        apps = app_name.split('\n')
    for ii in apps:
        second = ii.split(' ')
        for iii in second:
            if re.search(':', iii):
                port, name = iii.split(':')
            else:
                port = ''
                name = iii
            res.append({"port": port, "name": name})
    return res
