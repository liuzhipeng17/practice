import traceback

import requests

from conf.script.load_init_data.excel_data import get_database_from_excel
from conf.script.load_init_data.load_ldap_data import get_token

# api = 'http://10.10.50.30/api'
api = 'http://127.0.0.1:8010/api'
# api = 'http://cmdb.ops.yunnex.com/api'

res = get_database_from_excel(filename='conf/script/load_init_data/data/架构.xlsx')

_, token = get_token()


def load_database_type_data(**kwargs):
    try:
        headers = token
        get_path = '/database_type?name=' + str(kwargs['name'])
        result = requests.get(api + str(get_path), headers=headers).json()['res']
        path = '/database_type'
        if not result:
            data = kwargs
            res = requests.post(api + path, json=data, headers=headers)
            if res.status_code == 200:
                return res.json()['res']['id']
            else:
                return
        else:
            kwargs.update({"id": result[0]['id']})
            data = kwargs
            res = requests.put(api + path, json=data, headers=headers)
            if res.status_code == 200:
                return res.json()['res']['id']
            else:
                return
    except Exception as e:
        print(e)
        print(traceback.format_exc())
        return


def load_host_type_data(**kwargs):
    try:
        headers = token
        get_path = '/host_type?name=' + str(kwargs['name'])
        result = requests.get(api + str(get_path), headers=headers).json()['res']
        path = '/host_type'
        if not result:
            data = kwargs
            res = requests.post(api + path, json=data, headers=headers)
            if res.status_code == 200:
                return res.json()['res']['id']
            else:
                print(res.text)
                return
        else:
            kwargs.update({"id": result[0]['id']})
            data = kwargs
            res = requests.put(api + path, json=data, headers=headers)
            if res.status_code == 200:
                return res.json()['res']['id']
            else:
                print(res.text)
                return
    except Exception as e:
        print(e)
        print(traceback.format_exc())
        return


def load_database_data(**kwargs):
    try:
        headers = token
        get_path = '/database?hostname=' + str(kwargs['hostname'])
        result = requests.get(api + str(get_path), headers=headers).json()['res']
        path = '/database'
        if not result:
            data = kwargs
            res = requests.post(api + path, json=data, headers=headers)
            if res.status_code == 200:
                return res.json()['res']['id']
            else:
                print(res.text)
                return
        else:
            kwargs.update({"id": result[0]['id']})
            data = kwargs
            import json
            res = requests.put(api + path, json=data, headers=headers)
            if res.status_code == 200:
                return res.json()['res']['id']
            else:
                print(res.text)
                return
    except Exception as e:
        print(e)
        print(traceback.format_exc())
        return


def load_database_name_data(**kwargs):
    try:
        headers = token
        get_path = '/database_name?name=' + str(kwargs['name'])
        result = requests.get(api + str(get_path), headers=headers).json()['res']
        path = '/database_name'
        if not result:
            data = kwargs
            res = requests.post(api + path, json=data, headers=headers)
            if res.status_code == 200:
                return res.json()['res']['id']
            else:
                print(res.text)
                return
        else:
            kwargs.update({"id": result[0]['id']})
            data = kwargs
            res = requests.put(api + path, json=data, headers=headers)
            if res.status_code == 200:
                return res.json()['res']['id']
            else:
                print(res.text)
                return
    except Exception as e:
        print(e)
        print(traceback.format_exc())
        return


def load_database_database_name_data(**kwargs):
    try:
        headers = token
        get_path = '/database_database_name?database_id=' + str(kwargs['database_id']) + '&database_name_id=' + str(
            kwargs['database_name_id'])
        result = requests.get(api + str(get_path), headers=headers).json()['res']
        path = '/database_database_name'
        if not result:
            data = kwargs
            res = requests.post(api + path, json=data, headers=headers)
            if res.status_code == 200:
                return res.json()['res']['id']
            else:
                print(res.text)
                return
        else:
            kwargs.update({"id": result[0]['id']})
            data = kwargs
            res = requests.put(api + path, json=data, headers=headers)
            if res.status_code == 200:
                return res.json()['res']['id']
            else:
                print(res.text)
                return
    except Exception as e:
        print(e)
        print(traceback.format_exc())
        return


def main():
    for i in res['database']:
        host_type = i.pop('host_type_id')
        if host_type:
            get_host_type_id = load_host_type_data(name=host_type)
            i.update({'host_type_id': get_host_type_id})
        database_type = i.pop('database_type_id')
        if database_type:
            get_database_type_id = load_database_type_data(name=database_type)
            i.update({'database_type_id': get_database_type_id})
        database_name = i.pop('database_name')
        database_id = load_database_data(**i)
        if database_name:
            for name in database_name:
                database_name_info = {'name': name}
                database_name_id = load_database_name_data(**database_name_info)
                database_database_name_info = {'database_name_id': database_name_id, 'database_id': database_id}
                load_database_database_name_data(**database_database_name_info)


if __name__ == '__main__':
    main()
