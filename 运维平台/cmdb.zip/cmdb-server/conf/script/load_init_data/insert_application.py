import json

import requests

with open('init_data/data/applications_wiki.json', 'r', encoding='utf-8') as json_file:
    APPLICATIONS = json.load(json_file)['res']

BASE_URL = 'http://cmdb.ops.yunnex.com'

'''
todo :
1. applications  not build relationship with business_group
'''


def insert_application():
    '''
    application
    1. get department_id  by department name
    2. get business_group_id by business_group name
    3. if exist , update else add
    :return:
    '''
    depart_res = requests.get(BASE_URL + '/api/department?page=1&page_size=10000')
    business_res = requests.get(BASE_URL + '/api/business_group?page=1&page_size=10000')

    depart_dict = {}
    for depart in depart_res.json()['res']:  # department name id make a dict
        depart_dict[depart['name']] = depart['id']

    business_dict = {}
    for ii in business_res.json()['res']:  # business name id make a dict
        business_dict[ii['name']] = ii['id']

    # application_business = {}
    # for ii in APPLICATIONS_BUSINESS:  # application 与 business_group 之间的关系表
    #     print (ii)
    #     business_group_id = business_dict[ii['business_group'].upper()]
    #     application_business[ii['name']] = {
    #         'business_group_id': business_group_id,
    #         'port': int(ii['port']) if len(ii['port'].replace(' ', '')) > 0 else 0
    #     }

    add_num = 0
    update_num = 0
    for ii in APPLICATIONS:
        department_name = ii['department_name'].replace('\xa0' or ' ', '')
        department_id = depart_dict[department_name]
        application_name = ii['name']
        response = requests.get(BASE_URL + '/api/application?name=%s' % application_name)
        info = {
            # 'name': ii['name'],
            'note': ii['note'],
            # 'application_type': ii['application_type'],
            'department_id': department_id,
            # 'business_group_id': application_business[ii['name']]['business_group_id'] if ii[
            #                                                                                   'name'] in application_business.keys() else 0,
            # 'port_number': application_business[ii['name']]['port'] if ii['name'] in application_business.keys() else 0

        }

        if not len(response.json()['res']) > 0:  # 根据名称查找，不存在，add
            # requests.post(url=BASE_URL + '/api/application',
            #               json=info)
            print(info)
            add_num += 1
        else:  # 根据名称查找，存在，update
            _id = response.json()['res'][0]['id']
            info.update({'id': _id})
            requests.put(url=BASE_URL + '/api/application',
                         json=info)
            update_num += 1
            print(response.json()['res'], info)

        print("add_num : %d ,update_num :%d" % (add_num, update_num))
        # break


if __name__ == '__main__':
    insert_application()
