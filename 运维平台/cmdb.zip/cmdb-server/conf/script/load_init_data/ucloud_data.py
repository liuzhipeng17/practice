from conf import settings
from conf.script.load_init_data.ucloud_sdk import UcloudApiClient
from conf.script.load_init_data.common import dump_file

import os
import sys
import json

sys.path.insert(0, os.path.abspath('.'))
CONFIGS = settings['ucloud']


class GetInfoFromUCloud(object):
    def __init__(self, base_url=CONFIGS['base_url'], public_key=CONFIGS['public_key'],
                 private_key=CONFIGS['private_key'], ):

        self.client = UcloudApiClient(base_url=base_url, public_key=public_key,
                                      private_key=private_key)

    def get_project_ids(self):
        '''
        获取项目信息
        :return:
        '''
        Parameters = {
            'Action': 'GetProjectList',
            'ResourceCount': 'Yes',
            'MemberCount': 'Yes'
        }
        response = self.client.get('/', params=Parameters)

        if response.get('RetCode') == 0 and response.get('TotalCount') != 0:
            return response.get('ProjectSet')

    def get_uhosts_yunnex(self, params):
        """获取云主机信息"""
        Parameters = {
            'Action': 'DescribeUHostInstance',
            'Region': 'cn-gd',
            'Zone': 'cn-gd-02',
            'Limit': 1000000
        }
        Parameters.update(params)
        response = self.client.get('/', params=Parameters)

        if response.get('RetCode') == 0 and response.get('TotalCount') != 0:
            print("TotalCount:", response.get('TotalCount'))
            return [response.get('TotalCount'), response.get('UHostSet')]
        else:
            print("error:", response)
            return {}

    def get_uhost_tag_yunnex(self, params):
        '''
        获取 云主机 tag 信息
        :param params:
        :return:
        '''
        Parameters = {
            'Action': 'DescribeUHostTags',
            'Region': 'cn-gd',
            'Zone': 'cn-gd-02',
            'Limit': 10000000
        }
        Parameters.update(params)
        response = self.client.get('/', params=Parameters)

        if response.get('RetCode') == 0 and response.get('TotalCount') != 0:
            print(response.get('TotalCount'))
            return response.get('TagSet')
        else:
            print(response)
            return {}

    def get_phosts_yunnex(self):
        '''
        获取物理机信息
        :return:
        '''
        Parameters = {
            'Action': 'DescribePHost',
            'Limit': 10000000,
            'Region': 'cn-gd',
            'Zone': 'cn-gd-02',
            'PHostId': 'upm-lsite1',
        }
        response = self.client.get('/', params=Parameters)

        if response.get('RetCode') == 0 and response.get('TotalCount') != 0:
            print(response.get('TotalCount'))
            for ii in response.get('PHostSet'):
                print(ii)
            return response.get('PHostSet')

    def get_ulb_yunnex(self):
        '''
        获取负载均衡主机信息
        ulb (ucloud load balance) '''
        Parameters = {
            'Action': 'DescribeULB',
            'Region': 'cn-gd',
            'Zone': 'cn-gd-02',
            'Limit': 10000000
        }
        response = self.client.get('/', params=Parameters)

        if response.get('RetCode') == 0 and response.get('TotalCount') != 0:
            print(response.get('TotalCount'))
            for ii in response.get('DataSet'):
                print(ii)
            return response.get('DataSet')

    def get_udb_yunnex(self, params):
        '''
        获取云数据库信息
        '''
        Parameters = {
            'Action': 'DescribeUDBInstance',
            'Region': 'cn-gd',
            'Zone': 'cn-gd-02',
            'Offset': 0,
            'ClassType': 'SQL',
            'Limit': 10000000
        }
        Parameters.update(params)
        response = self.client.get('/', params=Parameters)

        if response.get('RetCode') == 0 and response.get('TotalCount') != 0:
            print(response.get('TotalCount'))
            for ii in response.get('DataSet'):
                print(ii)
            return [response.get('TotalCount'), response.get('DataSet')]
        else:
            print(response)

    def get_host_by_projectid(self, out_path='conf/script/load_init_data/data/Uhost.json'):
        '''
        根据项目ID 返回云主机信息
        :return:
        '''
        project_set = self.get_project_ids()
        res = []
        for project in project_set:
            print('%s:%s' % (project['ProjectId'], project['ProjectName']))
            total_count, uhost_set = self.get_uhosts_yunnex({'ProjectId': project['ProjectId']})
            host_list = self.uhost_to_host(uhost_set)

            res.append({'ProjectId': project['ProjectId'], 'ProjectName': project['ProjectName'],
                        "TotalCount": total_count, "HostSet": host_list})
        dump_file(out_path, res)
        return res

    def get_uhost_tag_by_projectid(self):
        '''
        根据项目ID 返回 云主机tag 信息
        :return:
        '''
        tag_set = self.get_uhost_tag_yunnex({'ProjectId': 'org-yw1iri'})

        print(json.dumps(tag_set, indent=4))

    def get_udb_by_projectid(self):
        '''
        根据项目ID 返回 云数据库信息
        :return:
        '''
        project_set = self.get_project_ids()
        res = []
        for project in project_set:
            print('%s:%s' % (project['ProjectId'], project['ProjectName']))
            total_count, tag_set = self.get_udb_yunnex({'ProjectId': project['ProjectId']}) if self.get_udb_yunnex(
                {'ProjectId': project['ProjectId']}) else (None, None)
            res.append({"prejsct_id": project['ProjectId'], "preject_name": project['ProjectName'],
                        "total_count": total_count, "res": tag_set})
        return res
        # dump_file('E://udb.json', res)

    def get_os_type(self, ii):
        if ii["OsType"] == "Linux":
            os_type = 1
        elif ii["OsType"] == "Windows":
            os_type = 2
        else:
            os_type = 0
        return os_type

    def get_disk_soft_type(self, ii):
        if ii["Type"] == "Boot":
            _type = 1
        elif ii["Type"] == "Data":
            _type = 2
        elif ii["Type"] == "Udisk":
            _type = 3
        else:
            _type = 0
        return _type

    def get_ip_type(self, ii):
        if ii["Type"] == "Private":
            _type = 1
        else:
            _type = 0
        return _type

    def uhost_to_host(self, uhost_list):
        '''
        ucloud host 信息字段 与CMDB 字段对照，转换
        :param uhost_list: list
        :return:
        '''

        host_list = []
        for ii in uhost_list:

            os_type = self.get_os_type(ii)

            disks = []
            for j in ii["DiskSet"]:
                _type = self.get_disk_soft_type(j)
                disk = {
                    "tag": j["Drive"],
                    "size": j["Size"],
                    "disk_type": 1,
                    "type": _type
                }
                disks.append(disk)

            network_interfaces = []
            for k in ii["IPSet"]:
                ip_type = self.get_ip_type(k)
                ip_addr = k['IP']
                network_interface = {
                    "mac_addr": ip_addr,
                    "name": "",
                    "ip": {
                        "ip_type": ip_type,
                        "ip_addr": ip_addr
                    }
                }
                network_interfaces.append(network_interface)

            host = {
                "memory_total": ii['Memory'],
                "cpu_core_num": ii["CPU"],
                "os_info": ii["OsName"],
                "hostname": ii["Name"],
                # "os_type_name": ii["OsType"],
                "os_type": os_type,
                "disk": disks,
                "network_interface": network_interfaces

            }
            host_list.append(host)
        return host_list


# InsGetInfoFromUCloud = GetInfoFromUCloud()
# InsGetInfoFromUCloud.get_host_by_projectid()
if __name__ == '__main__':
    InsGetInfoFromUCloud = GetInfoFromUCloud()
    res = InsGetInfoFromUCloud.get_ulb_yunnex()
    out_path = "E://ulb.json"
    dump_file(out_path, res)
