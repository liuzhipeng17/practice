from test.ucloud import excel_data

host_list = excel_data.read_host_list()

ip_dict = {}

hostname_dict = {}
for host in host_list:
    ip_dict[host['ip']] = host
    hostname_dict[host['hostname']] = host


def get_host_by_ip(ip):
    return ip_dict[ip]


def get_ip_by_hostname(hostname):
    return hostname_dict[hostname]
