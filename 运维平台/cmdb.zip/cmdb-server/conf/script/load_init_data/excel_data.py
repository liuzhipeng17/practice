from openpyxl import load_workbook
from conf.script.load_init_data.common import dump_file
from conf.script.load_init_data.common import deal_application_name


class Excel(object):
    def __init__(self, file_name=""):
        self.workbook = load_workbook(file_name, read_only=True)
        self.current_work_sheet = ''

    def set_work_sheet_by_index(self, index=0):
        sheet_names = self.workbook.get_sheet_names()  # 获取读文件中所有的sheet，通过名字的方式
        ws = self.workbook.get_sheet_by_name(sheet_names[index])  # 获取第一个sheet内容
        self.current_work_sheet = ws
        return ws

    def set_work_sheet_by_sheet_name(self, sheet_name):
        ws = self.workbook.get_sheet_by_name(sheet_name)  # 获取第一个sheet内容
        self.current_work_sheet = ws

    def get_value(self, row, column, ):
        value = self.current_work_sheet.cell(row=row, column=column).value
        return value

    def get_max_row(self):
        max_row = self.current_work_sheet.max_row  # 获取读取的excel的文件的行数
        return max_row


def get_host_app_bus_from_excel(filename='conf/script/load_init_data/data/架构.xlsx'):
    '''
    从excel 中导导入app/mod 主机信息
    :param filename:
    :return:
    '''

    excel = Excel(file_name=filename)
    host_list = []
    applications_list = []

    for sheet_name in ["APP", "MOD"]:  # 循环两个sheet
        excel.set_work_sheet_by_sheet_name(sheet_name)
        max_row = excel.get_max_row()

        for row in range(1, max_row + 1):
            if not excel.get_value(row, 1) or excel.get_value(row, 1) == '名称':  # 过滤第一行和最后一行
                continue
            application_name = excel.get_value(row, 8)
            application_name = deal_application_name(application_name)
            for ii in application_name:
                name = ii['name']
                port = ii['port']
                app_info = {
                    'name': name,
                    'port': port,
                    'business_group': excel.get_value(row, 3).lower(),
                    'hostname': excel.get_value(row, 1)
                }
                applications_list.append(app_info)

            info = {
                'hostname': excel.get_value(row, 1),
                'business_group': excel.get_value(row, 3).lower(),
                'ip': excel.get_value(row, 4),
                'application_type': sheet_name.lower(),
                'application': application_name
            }
            host_list.append(info)
    res = {"total_count": len(host_list), "res": host_list}
    dump_file("conf/script/load_init_data/data/host_excel.json", res)
    res = {"total_count": len(applications_list), "res": applications_list}
    dump_file("conf/script/load_init_data/data/application_business.json", res)
    return res


def get_applications(filename='conf/script/load_init_data/data/department-application.xlsx'):
    '''
    get application info
    original data is from wiki
    :param filename:
    :return:
    '''
    excel = Excel(file_name=filename)
    excel.set_work_sheet_by_index(index=0)
    max_row = excel.get_max_row()
    applications = []
    for row in range(1, max_row + 1):
        if not excel.get_value(row, 1) or excel.get_value(row, 1) == '应用名称':  # 过滤第一行和最后一行
            continue
        _type = excel.get_value(row, 2)
        if _type == "web":
            type_int = 1
        elif _type == "mod":
            type_int = 2
        elif _type == "api":
            type_int = 3
        elif _type == "nginx":
            type_int = 4
        elif _type == "db":
            type_int = 5
        elif _type == "midlle":
            type_int = 6
        else:
            type_int = 0

        info = {
            "name": excel.get_value(row, 1),
            "type_name": excel.get_value(row, 2),
            "application_type": type_int,
            "department_name": excel.get_value(row, 3),
            "note": excel.get_value(row, 4)
        }
        applications.append(info)
    total_count = len(applications)
    res = {"total_count": total_count, "res": applications}
    dump_file("conf/script/load_init_data/data/applications_wiki.json", res)
    return applications


def get_database_from_excel(filename='conf/script/load_init_data/data/架构.xlsx'):
    '''
    从excel 中导导入数据库信息
    :param filename:
    :return:
    '''

    excel = Excel(file_name=filename)
    database_type = []
    host_type = []
    database = []
    for sheet_name in ["数据库信息"]:  # 循环两个sheet
        excel.set_work_sheet_by_sheet_name(sheet_name)
        max_row = excel.get_max_row()
        for row in range(1, max_row + 1):
            # print(excel.get_value(row, 1))
            if not excel.get_value(row, 1) or excel.get_value(row, 1) == '数据库：' or excel.get_value(row, 1) == '序号' or excel.get_value(row, 1) == '其它：' or excel.get_value(row, 1) == 'mycat：' or excel.get_value(row, 1) == 'redis：':  # 过滤第一行和最后一行
                continue
            # print(excel.get_value(row, 1), excel.get_value(row, 3))
            host_type.append(excel.get_value(row, 3))
            if excel.get_value(row, 6).split('-')[0].split(' ')[0] != '无':
                database_type.append(excel.get_value(row, 6).split('-')[0].split(' ')[0])
            database_name = excel.get_value(row, 7).split() if excel.get_value(row, 7) and excel.get_value(row, 7) !='无' else ''
            # print(database_name)
            is_main = 2 if excel.get_value(row, 8) == 'slave' else 1
            deploy_config = '''datadir = /home/mysql/data/\r\nbasedir = /usr/local/mysql/\r\ndefault-file = /etc/my.cnf''' if excel.get_value(row, 6).split('-')[0].split(' ')[0] == 'mysql' else ''
            version = '' if excel.get_value(row, 6) == '无' else excel.get_value(row, 6)
            database_info = {
                'hostname': excel.get_value(row, 2),
                'ip_addr': excel.get_value(row, 4),
                'hardward': excel.get_value(row, 5),
                'version': version,
                'note': excel.get_value(row, 8),
                'vip': excel.get_value(row, 10) if excel.get_value(row, 10) else '',
                'host_type_id': excel.get_value(row, 3),
                'database_type_id': excel.get_value(row, 6).split('-')[0].split(' ')[0] if excel.get_value(row, 6).split('-')[0].split(' ')[0] != '无' or None else '',
                'database_name': database_name,
                'startup': 1,
                'port': 3306,
                'is_main': is_main,
                'deploy_config': deploy_config
            }
            database.append(database_info)
            host_type.append(excel.get_value(row, 3))
    res = {'database': database}
    return res



if __name__ == '__main__':
    pass
    # get_database_from_excel(filename='conf/script/load_init_data/data/架构.xlsx')
