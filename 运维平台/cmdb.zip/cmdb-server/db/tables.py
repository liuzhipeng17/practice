import copy

from sqlalchemy.ext import declarative
from tornado.log import app_log

from db.mysql import Base


class Tables(object):
    def __init__(self, base):
        app_log.info('init Tables')
        self.host = base.classes.cmdb_host
        self.host_disk = base.classes.cmdb_host_disk
        self.host_network_interface = base.classes.cmdb_host_network_interface
        self.ip = base.classes.cmdb_ip
        self.env = base.classes.cmdb_env
        self.host_type = base.classes.cmdb_host_type
        self.zone_info = base.classes.cmdb_zone_info
        self.department = base.classes.cmdb_department
        self.business_group = base.classes.cmdb_business_group
        self.ids = base.classes.cmdb_ids
        self.application = base.classes.cmdb_application
        self.host_application = base.classes.cmdb_host_application
        self.zone_info = base.classes.cmdb_zone_info
        self.rack_info = base.classes.cmdb_rack_info
        self.env = base.classes.cmdb_env
        self.backend_group = base.classes.cmdb_backend_group
        self.location = base.classes.cmdb_location
        self.domain = base.classes.cmdb_domain
        self.domain_location = base.classes.cmdb_domain_location
        self.dns_record = base.classes.cmdb_dns_record
        self.ulb_upstream = base.classes.cmdb_ulb_upstream
        self.ulb = base.classes.cmdb_ulb
        self.ulb_upstream_domain = base.classes.cmdb_ulb_upstream_domain
        self.user = base.classes.cmdb_user
        self.user_department = base.classes.cmdb_user_department
        self.user_application = base.classes.cmdb_user_application
        self.database = base.classes.cmdb_database
        self.database_name = base.classes.cmdb_database_name
        self.database_type = base.classes.cmdb_database_type
        self.database_database_name = base.classes.cmdb_database_database_name
        self.application_database = base.classes.cmdb_application_database

        def to_dict(_self):
            ret = copy.deepcopy(_self.__dict__)
            ret.pop('_sa_instance_state')
            return ret

        for str_attr in dir(self):
            if isinstance(getattr(self, str_attr), declarative.api.DeclarativeMeta):
                getattr(self, str_attr).to_dict = to_dict


Tables = Tables(Base)
