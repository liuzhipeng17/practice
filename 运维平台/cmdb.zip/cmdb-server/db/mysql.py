import re
from contextlib import contextmanager

from sqlalchemy import create_engine
from sqlalchemy import exc
from sqlalchemy import orm
from sqlalchemy.ext.automap import automap_base
from tornado.log import app_log

from common.error import CMDBError
from conf import settings

db_config = settings['mysql']

conn = '{dialect}+{driver}://{username}:{password}@{host}:{port}/{database}?charset=utf8'
DB_URL = conn.format(dialect=db_config['dialect'], driver=db_config['driver'], username=db_config['username'],
                     password=db_config['password'], host=db_config['host'], port=db_config['port'],
                     database=db_config['database'])
db_kwargs = db_config['config']
ENGINE = create_engine(DB_URL, **db_kwargs)

Base = automap_base()


def init():
    app_log.info('init mysql')

    Base.prepare(ENGINE, reflect=True)


SESSION_MAKER = None
Filed = re.compile(r'(has no property) (.*)')


def connect(engine=ENGINE):
    '''
        uri: dialect+driver://user:password@host:port/dbname[?key=value...]
        kwargs: reference sqlalchemy.create_engine
    '''
    global SESSION_MAKER
    if not SESSION_MAKER:
        # engine = create_engine(uri, **kwargs)
        SESSION_MAKER = orm.sessionmaker(bind=engine)
    return SESSION_MAKER


@contextmanager
def session_scope(session):
    '''
        caller create new session & close created session
        caller control session scope:
            request scope
            application scope
    '''
    try:
        yield session
        session.commit()
    except exc.IntegrityError:
        session.rollback()
        raise CMDBError(status_code=400, reason="Duplicate  error")
    except orm.exc.NoResultFound as e:
        session.rollback()
        raise CMDBError(status_code=404, reason=str(e))
    except exc.InvalidRequestError as e:

        error_info = e.args[0]
        value = Filed.search(error_info)
        if value:
            value = value.group(2)
            reason = "InvalidRequestError, arguments %s is not allowed" % value
        else:
            reason = "InvalidRequestError, please check your request arguments"
        session.rollback()
        raise CMDBError(status_code=400, reason=reason)
    except Exception as e:
        session.rollback()
        raise CMDBError(status_code=400, reason=str(e))
