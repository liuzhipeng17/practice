# CMDB后端接口文档

### API设计约定

> 后端API 设计采用Restful风格
>
> API Define
>
> - URI : <scheme://domain/resources?parameters>
> - scheme : http[s]
> - resources : 服务定义的资源，可以是物理实体也可以是抽象的
>
> method 含义：
>
> -  GET : 查询获取
> -  POST ：新增
> -  PUT ：修改
> -  DELETE ：删除
>
> parameters : 接口参数
>
> - 对于GET方法，参数强制要求全部放在url里面
> - 对于方法（POST|PUT|DELETE），参数强制要求放在json格式的body里面
> - Content-Type 为 application/json，且采用utf-8 编码
> - 请求参数若无特殊说明，只支持application/json 类型。
>
> Response（多人开发后端API时建议采用统一的返回内容风格） :
>
> - 返回数据类型默认为application/json
> - 传入 callback参数，返回jsonp；传入_format参数，返回格式化的json 
> - 返回结果字段：
>   - code : 状态码, 必选
>   - msg : 返回结果提示信息，必选
>   - res : 操作返回结果，非必选
> - 对于POST和POST方法，必返回对应id和更新后的数据
> - 对于GET方法，必返回资源列表，且有total_count字段。默认使用分页。
>
> 分页
>
> - GET 方法必须分页返回
> - page & page_size 参数缺省时，默认值page =1 ,page_size =15,返回值total_count: 查询总数

### HTTP 响应码

> 200 请求成功
>
> 400 客户端错误
>
> 401 未授权
>
> 404 资源不存在，not found
>
> 500 服务器端错误

## 1. host 服务器信息

服务器新增、查看、修改、注销 (demo 时暂不考虑鉴权问题)

| method | path           | request          | response                           | note                    |
| ------ | -------------- | ---------------- | ---------------------------------- | ----------------------- |
| GET    | /api/host/     | {}               | {code:200, msg:"OK“，res=[HOST,]}  | 根据筛选条件获取服务器信息 |
| POST   | /api/host/     | {host(不可带id)}  | {code:200, msg:"OK“}               | 新增服务器     |
| PUT    | /api/host/     | {host(必须带id)}  | {code:200, msg:"OK“}               | 修改服务器信息  |
| DELETE | /api/host/     | {host(仅需要id)}  | {code:200, msg:"OK“}               | 删除主机信息    |

### GET

`返回服务器信息`

path ：/api/host/?IP=xxx&name=xxx (query string)

请求参数：（多个参数条件时，为and 查询，如hostname 和 ip  参数均提供时，为两者查询的and 结果）

| Parameter name      | Type   | Description                              | Required |
| ------------------- | ------ | ---------------------------------------- | -------- |
| ip                  | string | 内网IP,可多个，用英文字符逗号“,”隔开                    | NO       |
| hostname            | string | 主机名称，可多个，用英文字符逗号“,”隔开                    | NO       |
| agent_status        | int    | agent状态 -1:全部 1:正常 2:异常 3:下架 4:未安装 可参见[附录 host表agent_status数字含义]() | NO       |
| status              | int    | 服务器运行状态：-1:全部  0: 库存  1:上架    2: 初始化   3:故障  4:下线  可参见 [附录 host 表status数字含义]()， | NO       |
| sn                  | string | 服务器的sn号，可多个，用英文字符逗号“,”隔开                 | NO       |
| application_name    | string | 应用名称，可多个，用英文字符逗号“,”隔开                    | NO       |
| env_name            | string | 主机所在环境，可多个，用英文字符逗号“,”隔开                  | NO       |
| zone_name           | string | 机房所在zone  名称，可多个，用英文字符逗号“,”隔开            | NO       |
| business_group_name | string | 业务组名称，可多个，用英文字符逗号“,”隔开                   | NO       |
| department_name     | string | 部门名称，可多个，用英文字符逗号“,”隔开                    | NO       |

请求示例：

```
http://10.10.50.30/api/host?status=1&ip=10.10.50.49&page=2&page_size=1
http://10.10.50.30/api/host?sn=qw_defrfg_343
http://10.10.50.30/api/host?zone_name=广东2区
http://10.10.50.30/api/host?business_group_name=shop

同一个参数 多个值查询示例（用逗号隔开）：
http://10.10.50.30/api/host?application_name=saofu-mod-card,canyin 
```

返回值示例：

```json
{
  "code": 200,
  "msg": "OK",
  "res": [
    {
      "os_info": "CentOS 6.5 64位",
      "id": 1001,
      "update_time": "2017-09-29 15:44:16",
      "status": 1,
      "hostname": "UGZB-CANYIN-A3-002",
      "note": "",
      "agent_status": 2,
      "cpu_core_num": 2,
      "env_id": 1001,
      "parent_host_id": 0,
      "memory_total": 4096,
      "host_type_id": 0,
      "stock_date": null,
      "disk_total": 80,
      "physical_host_id": 0,
      "u_num": null,
      "sn": null,
      "rack_info_id": null,
      "server_no": null,
      "create_time": "2017-09-29 10:17:46",
      "os_type": 1,
      "disk": [
        {
          "tag": "/dev/vda",
          "disk_type": 1,
          "create_time": "2017-10-19 10:10:17",
          "host_id": 1001,
          "size": 20,
          "id": 1001,
          "update_time": "2017-10-19 11:07:30",
          "type": 1
        },
        {
          "tag": "/dev/vdb",
          "disk_type": 1,
          "create_time": "2017-10-19 10:10:17",
          "host_id": 1001,
          "size": 60,
          "id": 1002,
          "update_time": "2017-10-19 11:07:30",
          "type": 3
        }
      ],
      "network_interface": [
        {
          "update_time": "2017-10-19 10:09:13",
          "host_id": 1001,
          "mac_addr": "10.13.156.140",
          "create_time": "2017-10-19 10:09:13",
          "name": "",
          "id": 1001,
          "ip": [
            {
              "update_time": "2017-10-19 11:14:44",
              "host_network_interface_id": 1001,
              "ip_type": 1,
              "id": 1001,
              "create_time": "2017-10-19 10:04:13",
              "ip_addr": "10.13.156.140"
            }
          ]
        },
        {
          "update_time": "2017-10-19 10:09:13",
          "host_id": 1001,
          "mac_addr": "testing",
          "create_time": "2017-10-19 10:09:13",
          "name": " network_interface_name",
          "id": 1181,
          "ip": []
        }
      ],
      "zone": {},
      "application_list": [
        {
          "id": 1009,
          "name": "advertise-web-admin",
          "version": "1.2",
          "deploy_path": "/data/web/cmdb-server",
          "business_group": {
            "id": 1012,
            "name": "advertise"
          },
          "department": {
            "id": 1002,
            "name": "营销平台部"
          }
        },
        {
          "id": 1010,
          "name": "advertise-web-oem",
          "version": "1.1",
          "deploy_path": "/data/web/cmdb-server",
          "business_group": {
            "id": 1012,
            "name": "advertise"
          },
          "department": {
            "id": 1002,
            "name": "营销平台部"
          }
        }
      ]
    }
  ],
  "total_count": 309
}
```

### POST

`更新或者添加 host 信息，包括host_disk/host_network_interface/ip三附表`

 示例一 （不含disk /network_interface  信息）

```json
{
  "hostname": "tenging_gz-pay_4",
  "cpu_core_num": 3,
  "memory_total": 600,
  "disk_total": 788,
  "os_type": 1,
  "os_info": "i3 -7100",
  "host_type_id": 1002,
  "status": 1,
  "agent_status": 1,
  "parent_host_id": 0
}
```

示例二 （含disk /network_interface  信息）

```json
{  
   "hostname":"tenging_gz-pay_4",
    "cpu_core_num":3,
    "memory_total":600, 
    "disk_total" :788,
    "os_type":1,
    "os_info":"i3 -7100",
    "host_type_id":1002, 
    "status":1,
    "agent_status":1,
    "parent_host_id": 0,
	"disk":[{
		"disk_type":1, 
		"size":200,
		"tag":"wefs"
		},
		{	
		"disk_type":1, 
		"size":240,
		"tag":"w2fs"}
	],
	"network_interface":[
		{
		"mac_addr":"3e:12:12:a2:2d:1f",
		"name":"gz_mac_shop_o1",
	     "ip":{
			"ip_type":1,
			"ip_addr":"10.10.50.49"
	     	}
		},
		{
			"mac_addr":"3e:12:12:a2:2d:1f",
			"name":"gz_mac_shop_02",
	        "ip":{
				"ip_type":1,
				"ip_addr":"10.10.50.49"
	        	
	          }
		}
	]
	
}

```

### PUT

`修改主机信息,包括host_disk/host_network_interface/ip三附表`

path ：/api/host/

- 请求参数同 post,但比post 多了个 id ，且各个参数非必须，除了id 外均为可选参数，
- 当disk /network_interface 没有修改值时，可以没有该参数，也即当这两个参数不存在时，其中的id  也就不必传递

请求示例：

```json
{
  "id": 1004,
  "hostname": "gz-pay_20",
  "ops_leader": "爱丽丝",
  "dev_leader": "周杰伦",
  "cpu_core_num": 3,
  "memory_total": 600,
  "disk_total": 908,
  "os_type": 1,
  "os_info": "i3 -7100",
  "host_type": 2,
  "status": 1,
  "agent_status": 1,
  "parent_host_id": 0,
  "disk": [
    {
      "id": 1003,
      "disk_type": 1,
      "size": 220,
      "tag": "wefs"
    },
    {
      "id": 1004,
      "disk_type": 1,
      "size": 260,
      "tag": "w2fs"
    }
  ],
  "network_interface": [
    {
      "id": 1001,
      "mac_addr": "3e:12:12:a2:2d:1f",
      "name": "gz_mac_shop_o4",
      "ip": {
        "id": 1001,
        "ip_type": 1,
        "ip_addr": "10.10.50.49"
      }
    },
    {
      "id": 1002,
      "mac_addr": "3e:12:12:a2:2d:1f",
      "name": "gz_mac_shop_02",
      "ip": {
        "id": 1002,
        "ip_type": 1,
        "ip_addr": "10.10.50.49"
      }
    }
  ]
}
```

## 2.host_disk（硬盘）

| method | path            | request           | response           | note         |
| ------ | --------------- | ----------------- | ------------------ | ------------ |
| GET    | /api/host_disk? |                   |                    | 获取磁盘信息       |
| POST   | /api/host_disk  |                   |                    | 添加磁盘记录       |
| PUT    | /api/host_disk  |                   |                    | 修改磁盘记录       |
| DELETE | /api/host_disk  | {"disk_id": 1233} | code=200, msg="OK" | 删除磁盘记录，只支持单个 |

### MODEL

| Parameter name | Type   | Description              |
| -------------- | ------ | ------------------------ |
| id             | int    | ID                       |
| host_id        | int    | 主机ID                     |
| tag            | string | 盘符                       |
| size           | int    | 大小（G）                    |
| type           | int    | 硬盘类型： 1:系统盘 2:数据盘 3: 网络盘 |
| disk_type      | int    | 磁盘硬件类型 1:机械 2:ssd        |

### GET

请求参数

| Parameter name | Required |
| -------------- | -------- |
| id             | NO       |
| size           | NO       |
| tag            | NO       |
| host_id        | NO       |
| disk_type      | NO       |
| type           | NO       |

请求示例

```
http://127.0.0.1:8010/api/host_disk?host_id=1001&tag=/dev/vda
```

返回值示例

```json
{
    "total_count": 1,
    "msg": "OK",
    "code": 200,
    "res": [
        {
            "size": 20,
            "id": 1001,
            "host_id": 1001,
            "type": null,
            "disk_type": 1,
            "tag": "/dev/vda"
        }
    ]
}
```



### POST

请求示例

```json
{
  "disk_type": 1,
  "host_id": 999,
  "type": 1,
  "id": 1001,
  "tag": "/dev/vda",
  "size": 20
 }
```

返回值示例

```json
{
    "res": {
        "disk_type": 1,
        "size": 20,
        "type": 1,
        "host_id": 999,
        "tag": "/dev/vda",
        "id": 1290
    },
    "id": 1290,
    "code": 200,
    "msg": "OK"
}
```



### PUT

请求参数(各参数含义详见model)

| Parameter name | Type | Description | Required |
| -------------- | ---- | ----------- | -------- |
| id             | int  | ID          | YES      |
| host_id        | int  |             | NO       |
| tag            |      |             | NO       |
| size           |      |             | NO       |
| type           |      |             | NO       |
| disk_type      |      |             | NO       |

请求示例

```json
{
  "disk_type": 1,
  "host_id": 1001,
  "type": null,
  "id": 1001,
  "tag": "/dev/vda",
  "size": 20
 }
```

### DELETE

请求参数

| Parameter name | Required |
| -------------- | -------- |
| id             | YES      |

请求示例

```json
{
  "id":1177
}
```

返回值示例

```json
{
  "code": 200,
  "msg": "OK"
}
```



## 3. host_network_interface（网卡）

| method | path                        | request | response | note |
| ------ | --------------------------- | ------- | -------- | ---- |
| GET    | /api/host_network_interface |         |          | 获取   |
| POST   | /api/host_network_interface | {}      |          | 单个新增 |
| PUT    | /api/host_network_interface |         |          | 单个修改 |
| DELETE | /api/host_network_interface | {}      | list     | 单个删除 |

### GET

请求参数

| Parameter name | Type   | Description                     | Required |
| -------------- | ------ | ------------------------------- | -------- |
| name           | string | 网卡名称                            | NO       |
| mac-addr       | string | 网卡mac 地址                        | NO       |
| host_id        | string | 主机ID                            | NO       |
| hostname       | string | 主机名（当host_id 存在时，hostname 自动忽略） | NO       |

请求示例

```
http://127.0.0.1:8010/api/host_network_interface?hostname=UGZB-CANYIN-A1-003
```

返回值示例

```json
{
    "res": [
        {
            "name": "",
            "id": 1002,
            "mac_addr": "10.13.78.159",
            "host_id": 1002
        }
    ],
    "msg": "OK",
    "total_count": 1,
    "code": 200
}
```

### POST

`添加记录`

请求示例

```json
{
	"mac_addr":"testing",
	"name":" network_interface_name",
	"host_id":1001
}
```

返回示例

```json
{
    "res": {
        "mac_addr": "testing",
        "id": 1181,
        "host_id": 1001,
        "name": " network_interface_name"
    },
    "code": 200,
    "id": 1181,
    "msg": "OK"
}
```

### PUT

`修改记录`

除ID外，其他参数可选

请求示例

```json
{
	"id":1175,
	"mac_addr":"testing update",
	"name":" network_interface_name",
	"host_id":1001
}

```

返回值示例

```json
{
    "code": 200,
    "msg": "OK",
    "effect_row": 1,
    "res": {
        "mac_addr": "testing update",
        "id": 1175,
        "name": " network_interface_name",
        "host_id": 1001
    }
}
```



### DELETE

请求示例

```json
{
   "id":1177
}
```

返回示例

```json
{
    "msg": "OK",
    "code": 200
}
```

## 4. IP

| method | path    | request | response | note  |
| ------ | ------- | ------- | -------- | ----- |
| GET    | /api/ip |         |          |       |
| POST   | /api/ip |         |          | 新增，单个 |
| PUT    | /api/ip |         |          | 修改，单个 |
| DELETE | /api/ip |         |          | 删除，单个 |

### MODEL

| Parameter name            | Type   | Description                 |      |      |
| ------------------------- | ------ | --------------------------- | ---- | ---- |
| id                        | int    | ID                          |      |      |
| ip_type                   | int    | ip类型 1:内网ip 2:外网ip 3:虚拟ip   |      |      |
| ip_addr                   | string | ip地址                        |      |      |
| host_network_interface_id | int    | 关联host_network_interface表id |      |      |

### GET

`获取记录`

[modle](MODEL)中的参数均为可选

请求示例

```
http://127.0.0.1:8010/api/ip?disk_type=1
```

返回值示例

```json
{
  "msg": "OK",
  "code": 200,
  "total_count": 1,
  "res": [
    {
      "id": 1002,
      "type": null,
      "size": 60,
      "host_id": 1001,
      "disk_type": 1,
      "tag": "/dev/vdb"
    }
  ]
}
```


### POST

`新增记录`

请求示例

```json
{
	"ip_type":1,
	"ip_addr":"10.10.50.30",
	"host_network_interface_id": 1172
}
```

返回值示例

```json
{
    "msg": "OK",
    "res": {
        "ip_type": 1,
        "host_network_interface_id": 9999,
        "id": 1181,
        "ip_addr": "10.10.50.31"
    },
    "id": 1181,
    "code": 200
}
```

### PUT

`修改参数`

请求参数： 除id 外其他为可选参数

请求示例

```json
{
  "ip_type":2,
  "ip_addr":"10.10.50.31",
  "host_network_interface_id": 9999,
  "id":1181
}
```
返回值示例

```json
{
    "res": {
        "ip_type": 2,
        "id": 1181,
        "ip_addr": "10.10.50.31",
        "host_network_interface_id": 9999
    },
    "msg": "OK",
    "effect_row": 1,
    "code": 200
}
```



### DELETE

请求示例

```json
{
	"id":1177
}
```

返回示例

```json
{
    "msg": "OK",
    "code": 200
}
```



## 5. host_type（主机类型）

查询，增加，修改主机类型。主要有：ucloud云主机，ucloud物理机，混合云，机房物理机等

path: **/api/host_type**

### GET

查询主机类型信息，返回列表。

| 参数   | 类型   | 是否必填 | 说明                          |
| ---- | ---- | ---- | --------------------------- |
| id   | int  | NO   | 如果指明id，则至多只能返回一个host_type   |
| name | str  | NO   | 如果指明name，则至多只能返回一个host_type |

example_request

http://10.10.50.30/api/host_type

example_response

```json
{
    "code": 200,
    "msg": "OK",
    "res": [
        {
            "create_time": "2017-09-29 11:50:50",
            "id": 1001,
            "update_time": "2017-09-29 14:05:44",
            "name": "UCloud云主机"
        },
        {
            "create_time": "2017-09-29 11:51:04",
            "id": 1002,
            "update_time": "2017-09-29 14:06:14",
            "name": "UCloud物理机"
        },
        {
            "create_time": "2017-09-29 11:51:18",
            "id": 1003,
            "update_time": "2017-09-29 11:51:18",
            "name": "ucloud混合云主机"
        },
        {
            "create_time": "2017-09-29 11:51:43",
            "id": 1004,
            "update_time": "2017-09-29 11:51:43",
            "name": "物理机"
        }
    ],
    "total_count": 4
}
```

### PUT

| 字段   | 类型   | 是否必填    | 说明                |
| ---- | ---- | ------- | ----------------- |
| id   | int  | **YES** | 需要更新的host_type的id |
| name | str  | NO      | 新的名字。不能与已有的名字重复   |

example_body

```json
{
    "id": 1002,
    "name": "ucloud物理机"
}
```

example_response

```json
{
    "code": 200,
    "msg": "OK",
    "effect_row": 1
}
```



### POST

example_body

```json
{
    "name": "ucloud云主机"
}
```

example_response

```json
{
    "code": 200,
    "msg": "OK",
    "effect_row": null
}
```



## 6. env信息（环境变量）

查询，增加，修改环境变量：test，dev，灰度，预发布，生产

path: /api/env

****

### GET

查询环境变量信息，返回列表。

| 参数   | 类型   | 是否必填 | 说明                    |
| ---- | ---- | ---- | --------------------- |
| id   | int  | NO   | 如果指明id，则至多只能返回一个env   |
| name | str  | NO   | 如果指明name，则至多只能返回一个env |

example_request

[http://10.10.50.30/api/env](http://10.10.50.30/env)

example_response

```json
{
  "code": 200,
  "msg": "OK",
  "res": [
    {
      "create_time": "2017-09-29 10:17:26",
      "update_time": "2017-09-29 10:17:26",
      "name": "dev-1",
      "id": 1001
    },
    {
      "create_time": "2017-09-29 11:38:23",
      "update_time": "2017-09-29 11:38:23",
      "name": "dev-a",
      "id": 1002
    },
    {
      "create_time": "2017-09-29 11:38:41",
      "update_time": "2017-09-29 11:38:41",
      "name": "dev-b",
      "id": 1003
    },
    {
      "create_time": "2017-09-29 11:38:52",
      "update_time": "2017-09-29 11:38:52",
      "name": "test-a",
      "id": 1004
    },
    {
      "create_time": "2017-09-29 11:38:58",
      "update_time": "2017-09-29 11:38:58",
      "name": "test-b",
      "id": 1005
    },
    {
      "create_time": "2017-09-29 11:39:08",
      "update_time": "2017-09-29 11:39:08",
      "name": "预发布",
      "id": 1006
    },
    {
      "create_time": "2017-09-29 11:39:13",
      "update_time": "2017-09-29 11:39:13",
      "name": "灰度",
      "id": 1007
    },
    {
      "create_time": "2017-09-29 11:39:20",
      "update_time": "2017-09-29 11:39:20",
      "name": "生产",
      "id": 1008
    }
  ],
  "total_count": 8
}
```

### PUT

| 字段   | 类型   | 是否必填    | 说明              |
| ---- | ---- | ------- | --------------- |
| id   | int  | **YES** | 需要更新的env的id     |
| name | str  | NO      | 新的名字。不能与已有的名字重复 |

example_body

```json
{
    "id": 1002,
    "name": "dev-c"
}
```

example_response

```json
{
    "code": 200,
    "msg": "OK",
    "effect_row": 1
}
```



### POST

example_body

```json
{
    "name": "dev-d"
}
```

example_response

```json
{
    "code": 200,
    "msg": "OK",
    "effect_row": null
}
```



## 7. zone_info信息（机房，IDC）



查询，增加，修改机房信息。主要有：ucloud广州B区，深圳机房，ucloud物理机

path:

 **/api/zone_info**

### GET

查询主机信息，返回列表。

| 参数   | 类型   | 是否必填 | 说明                          |
| ---- | ---- | ---- | --------------------------- |
| id   | int  | NO   | 如果指明id，则至多只能返回一个zone_info   |
| name | str  | NO   | 如果指明name，则至多只能返回一个zone_info |

example_request

http://10.10.50.30/api/zone_info

example_response

```json
{
  "code": 200,
  "msg": "OK",
  "res": [
    {
      "victoria_company": "",
      "address": "",
      "status": 0,
      "name": "广东2区",
      "create_time": "2017-09-29 13:59:01",
      "note": null,
      "stock_width": 2.6,
      "isp": "",
      "path": "",
      "id": 1002,
      "update_time": "2017-09-29 14:11:25",
      "type": 0
    }
  ],
  "total_count": 1
}
```

### PUT

`修改 zone_info信息`

| 字段   | 类型   | 是否必填    | 说明                |
| ---- | ---- | ------- | ----------------- |
| id   | int  | **YES** | 需要更新的zone_info的id |
| name | str  | NO      | 新的名字。不能与已有的名字重复   |

example_body

```json
{
    "id": 1002,
    "name": "广东3区"
}
```

example_response

```json
{
    "code": 200,
    "msg": "OK",
    "effect_row": 1
}
```



### POST

`新增`

example_body

```json
{
    "name": "广东4区"
}
```

example_response

```json
{
    "code": 200,
    "msg": "OK",
    "effect_row": null
}
```




## 8. department信息（部门）


查询，增加，修改部门信息

path:**/api/department**

### GET

`获取部门信息`

查询部门信息，返回列表。

| 参数   | 类型   | 是否必填 | 说明                           |
| ---- | ---- | ---- | ---------------------------- |
| id   | int  | NO   | 如果指明id，则至多只能返回一个department   |
| name | str  | NO   | 如果指明name，则至多只能返回一个department |

example_request

http://10.10.50.30/api/department

example_response

```json
{
  "code": 200,
  "msg": "OK",
  "res": [
    {
      "name": "商城平台部",
      "update_time": "2017-09-29 15:41:52",
      "create_time": "2017-09-29 15:41:52",
      "id": 1001
    },
    {
      "name": "营销平台部",
      "update_time": "2017-09-29 15:41:52",
      "create_time": "2017-09-29 15:41:52",
      "id": 1002
    },
    {
      "name": "用户管理部",
      "update_time": "2017-09-29 15:41:52",
      "create_time": "2017-09-29 15:41:52",
      "id": 1003
    },
    {
      "name": "开放平台部",
      "update_time": "2017-09-29 15:41:52",
      "create_time": "2017-09-29 15:41:52",
      "id": 1004
    },
    {
      "name": "支付平台部",
      "update_time": "2017-09-29 15:41:52",
      "create_time": "2017-09-29 15:41:52",
      "id": 1005
    },
    {
      "name": "智慧餐厅部",
      "update_time": "2017-09-29 15:41:52",
      "create_time": "2017-09-29 15:41:52",
      "id": 1006
    },
    {
      "name": "终端研发部",
      "update_time": "2017-09-29 15:41:53",
      "create_time": "2017-09-29 15:41:53",
      "id": 1007
    },
    {
      "name": "商户平台部",
      "update_time": "2017-09-29 15:41:53",
      "create_time": "2017-09-29 15:41:53",
      "id": 1008
    },
    {
      "name": "平台架构部",
      "update_time": "2017-09-30 16:27:03",
      "create_time": "2017-09-30 16:27:03",
      "id": 1009
    },
    {
      "name": "公共",
      "update_time": "2017-09-30 16:27:04",
      "create_time": "2017-09-30 16:27:04",
      "id": 1010
    },
    {
      "name": "智慧零售部",
      "update_time": "2017-09-30 16:32:47",
      "create_time": "2017-09-30 16:32:47",
      "id": 1011
    }
  ],
  "total_count": 11
}
```

### PUT

`修改部门信息`

| 字段   | 类型   | 是否必填    | 说明              |
| ---- | ---- | ------- | --------------- |
| id   | int  | **YES** | 需要更新的部门的id      |
| name | str  | NO      | 新的名字。不能与已有的名字重复 |

example_body

```json
{
    "id": 1002,
    "name": "智慧零售部2"
}
```

example_response

```json
{
    "code": 200,
    "msg": "OK",
    "effect_row": 1
}
```



### POST

`新增部门记录`

example_body

```json
{
    "name": "智慧零售部3"
}
```

example_response

```json
{
    "code": 200,
    "msg": "OK",
    "effect_row": null
}
```



## 9. business_group信息（业务）



查询，增加，修改业务信息

path: **/api/business_group**

### GET

`获取业务组信息`

查询主机信息，返回列表。

| 参数   | 类型   | 是否必填 | 说明                          |
| ---- | ---- | ---- | --------------------------- |
| id   | int  | NO   | 如果指明id，则至多只能返回一个host_type   |
| name | str  | NO   | 如果指明name，则至多只能返回一个host_type |

example_request

http://10.10.50.30/api/business_group

example_response

```json
{
    "code": 200,
    "msg": "OK",
    "res": [
        {
            "create_time": "2017-09-29 11:50:50",
            "id": 1001,
            "update_time": "2017-09-29 14:05:44",
            "name": "UCloud云主机"
        },
        {
            "create_time": "2017-09-29 11:51:04",
            "id": 1002,
            "update_time": "2017-09-29 14:06:14",
            "name": "UCloud物理机"
        },
        {
            "create_time": "2017-09-29 11:51:18",
            "id": 1003,
            "update_time": "2017-09-29 11:51:18",
            "name": "ucloud混合云主机"
        },
        {
            "create_time": "2017-09-29 11:51:43",
            "id": 1004,
            "update_time": "2017-09-29 11:51:43",
            "name": "物理机"
        }
    ],
    "total_count": 4
}
```

### PUT

`修改业务组信息`

| 字段   | 类型   | 是否必填    | 说明                |
| ---- | ---- | ------- | ----------------- |
| id   | int  | **YES** | 需要更新的host_type的id |
| name | str  | NO      | 新的名字。不能与已有的名字重复   |

example_body

```json
{
    "id": 1002,
    "name": "ucloud物理机"
}
```

example_response

```json
{
    "code": 200,
    "msg": "OK",
    "effect_row": 1
}
```



### POST

`新增业务组`

example_body

```json
{
    "name": "ucloud云主机"
}
```

example_response

```json
{
    "code": 200,
    "msg": "OK",
    "effect_row": null
}
```


## 10. application信息（应用）

查询，增加，修改应用信息

path: **/api/application**

### GET

查询主机信息，返回列表。

| 参数                  | 类型     | 是否必填 | 说明                            |
| ------------------- | ------ | ---- | ----------------------------- |
| id                  | int    | NO   | 如果指明id，则至多只能返回一个appclaition   |
| name                | string | NO   | 如果指明name，则至多只能返回一个application |
| department_name     | string | NO   | 部门名称                          |
| business_group_name | string | NO   | 业务名称                          |

example_request

http://10.10.50.30/api/application?department_name=商户平台部

example_response

```json
{
    "msg": "OK",
    "code": 200,
    "total_count": 95,
    "res": [
        {
            "startup": "",
            "business_group": {
                "id": 1012,
                "name": "营销平台部"
            },
            "related": "",
            "type": "",
            "port_number": 0,
            "create_time": "2017-09-29 20:02:20",
            "name": "advertise-mod-cart",
            "update_time": "2017-10-17 11:51:37",
            "id": 1004,
            "department": {
                "id": 1002,
                "name": "营销平台部"
            },
            "user_id": "",
            "host_application": [
                {
                    "host_id": 1078,
                    "version": "",
                    "deploy_path": ""
                },
                {
                    "host_id": 1077,
                    "version": "",
                    "deploy_path": ""
                }
            ],
            "note": "聚引客平台后端服务接口实现（对外接口）",
            "application_type": "mod"
        }
    ]
}
```

### PUT

`修改application 信息`

| 字段   | 类型   | 是否必填    | 说明                |
| ---- | ---- | ------- | ----------------- |
| id   | int  | **YES** | 需要更新的host_type的id |
| name | str  | NO      | 新的名字。不能与已有的名字重复   |

example_body

```json
{
    "id": 1002,
    "name": "ucloud物理机"
}
```

example_response

```json
{
    "code": 200,
    "msg": "OK",
    "effect_row": 1
}
```



### POST

`新增application信息`

example_body

```json
{
    "name": "ucloud云主机"
}
```

example_response

```json
{
    "code": 200,
    "msg": "OK",
    "effect_row": null
}
```

## 11.host_application

### GET

`获取host_application信息`

path: /api/host_application

请求参数

| 字段             | 类型   | 是否必填 | 说明   |
| -------------- | ---- | ---- | ---- |
| host_id        | int  | 否    |      |
| application_id | int  | fou  |      |

请求示例

```
http://127.0.0.1:8010/api/host_application?page=1&page_size=1
```

返回值示例

```json
{
    "code": 200,
    "msg": "OK",
    "res": [
        {
            "deploy_path": "",
            "application_id": 1010,
            "version": "",
            "id": 890,
            "host_id": 1001
        }
    ],
    "total_count": 214
}
```

### POST

`新增`

path: /api/host_application

请求参数

| 字段             | 类型     | 是否必填 | 说明   |
| -------------- | ------ | ---- | ---- |
| host_id        | int    | 是    |      |
| application_id | int    | 是    |      |
| version        | string | 否    | 版本号  |
| deploy_path    | string | 否    | 部署路径 |

请求示例

```json
{
"deploy_path": "/data/web/cmdb",
"application_id": 1010,
"version": "1.0.1",
"host_id": 1001
}
```

返回值示例

```json
{
    "code": 200,
    "id": 1234,
    "msg": "OK",
    "res": {
        "deploy_path": "/data/web/cmdb",
        "application_id": 1010,
        "version": "1.0.1",
        "id": 1234,
        "host_id": 1001
    }
}
```

### PUT

`修改`

请求参数

| 字段             | 类型     | 是否必填 | 说明   |
| -------------- | ------ | ---- | ---- |
| id             | int    | 是    |      |
| host_id        | int    | 否    |      |
| application_id | int    | 否    |      |
| version        | string | 否    | 版本号  |
| deploy_path    | string | 否    | 部署路径 |

请求示例

```json
{
     "deploy_path": "/data/web/cmdb-server",
        "application_id": 1010,
        "version": "1.0.1",
        "id": 1234,
        "host_id": 1001
}
```

返回值示例：

```json
{
    "code": 200,
    "effect_row": 1,
    "msg": "OK",
    "res": {
        "deploy_path": "/data/web/cmdb-server",
        "application_id": 1010,
        "version": "1.0.1",
        "id": 1234,
        "host_id": 1001
    }
}
```

### DElETE

path: /api/host_application

`删除 记录,目前只支持单个删除`

请求参数

| 字段   | 类型   | 是否必填 | 说明   |
| ---- | ---- | ---- | ---- |
| id   | int  | 是    | ID   |

请求示例

```json
{   
   "id": 1234
        
}
```

返回值示例：

```json
{
    "msg": "OK",
    "code": 200
}
```

## 11.token & 认证说明

### post

`用户登录,返回token`

path: /api/token

请求参数

| 字段       | 类型     | 是否必填 | 说明   |
| -------- | ------ | ---- | ---- |
| username | string | 是    | 用户名  |
| password | string | 是    | 密码   |

请求示例

```json
{
  "username": "ldapusername",
  "password": "ldappassword"
}
```

返回值示例：

```json
{
  "res": {
    "token": "xxxxx"
  },
  "code": 200,
  "msg": "OK"
}
```

### 说明

- cmdb 后端所有接口认证采用的是 token的方式.

- token 使用jwt格式，都带有base64编码的payload。

- 每次请求API均需要带上token,token 的携带方式支持两种：

  - url 携带
  - headers 携带

- 参数

| 参数名   | 类型     | 是否必须 | 说明     |
| ----- | ------ | ---- | ------ |
| token | string | 是    | token值 |


- 请求示例：

```
http://127.0.0.1:8010/api/application?token=xxxxx
```

- payload示例

```json
{
  "phone": "13535095927",
  "fullname": "吕祥钊",
  "username": "lvxiangzhao",
  "email": "lvxiangzhao@yunnex.com",
  "department_name": [
    "运维工程部"
  ]
}
```

## 附录

### host 表status数字含义

```
host表 status 字段
服务器运行状态：
-1: 全部  0: 库存  1:上架  2: 初始化  3:上线  4.故障 5:下线
```

### host 表 agent_status 数字含义

```
agent状态 -1 全部  1:正常 2:异常 3:下架 4:未安装
```

