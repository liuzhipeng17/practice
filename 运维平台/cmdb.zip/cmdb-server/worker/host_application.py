from db.tables import Tables


def get_host_application_by_id(session, _id):
    '''
    get get_host_application_by_id info by id
    :param session:
    :param _id:
    :return:
    '''

    host_application = Tables.host_application
    host_application_res = session.query(host_application).filter(host_application.id == _id).first().to_dict()
    return host_application_res
