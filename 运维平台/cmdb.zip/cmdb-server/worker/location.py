from db.tables import Tables


def get_location_by_id(session, _id):
    '''
    get location info by id
    :param session:
    :param _id:
    :return:
    '''

    location = Tables.location
    backend_group = Tables.backend_group
    application = Tables.application

    location_res = session.query(location).filter(location.id == _id).first()
    backend_group_id = session.query(location.backend_group_id).filter(location.id == _id).first()

    location_res.__dict__.pop("_sa_instance_state")
    all_res = location_res.__dict__
    backend_group_res = session.query(backend_group, application).filter(
        backend_group.application_id == application.id).filter(backend_group.id == backend_group_id[0]).all()
    for backend_group, application in backend_group_res:
        backend_group.__dict__.pop("_sa_instance_state")
        application.__dict__.pop("_sa_instance_state")
        backend_group_data = backend_group.__dict__
        backend_group_data.update({"application_id": application.__dict__})
        all_res.update({"backend_group_id": backend_group_data})
    return all_res
