from db.tables import Tables


def get_backend_group_by_id(session, _id):
    '''
    get backend_group info by id
    :param session:
    :param _id:
    :return:
    '''

    backend_group = Tables.backend_group
    application = Tables.application
    backend_group_res = session.query(backend_group).filter(backend_group.id == _id).first()
    application_id = session.query(backend_group.application_id).filter(backend_group.id == _id).first()
    backend_group_res.__dict__.pop("_sa_instance_state")
    all_res = backend_group_res.__dict__
    backend_group_name = session.query(application).filter(application.id == application_id[0]).all()
    backend_group_name[0].__dict__.pop("_sa_instance_state")
    all_res.update({"application_id": backend_group_name[0].__dict__})
    return all_res
