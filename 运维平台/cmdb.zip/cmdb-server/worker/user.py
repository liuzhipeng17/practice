from sqlalchemy import or_

from db.tables import Tables


def get_user_by_id(session, user_id):
    """
         get user info include user department
    :param session:
    :param user_id:
    :return:
    """
    user_info = session.query(Tables.user).filter_by(id=user_id).one().__dict__
    user_info.pop("_sa_instance_state")
    user_info.pop("password")
    user_departments = session.query(
        Tables.department.name).join(Tables.user_department,
                                     Tables.user_department.department_id == Tables.department.id).filter(
        Tables.user_department.user_id == user_id).all()
    _user_departments = []
    for _ in user_departments:
        _user_departments.append(_[0])
    user_info.update({"department": _user_departments})
    return user_info


def get_specified_users(session, **kwargs):
    department_id = kwargs.get('department_id', None)
    username = kwargs.get('username', None)
    orm_sql = session.query(Tables.user).join(Tables.user_department, Tables.user_department.user_id == Tables.user.id)
    if department_id:
        orm_sql = orm_sql.filter(Tables.user_department.department_id == department_id)
    if username:
        orm_sql = orm_sql.filter(
            or_(Tables.user.fullname.like('%' + username + '%'), Tables.user.username.like('%' + username + '%')))
    users = orm_sql.all()
    return users, len(users)
