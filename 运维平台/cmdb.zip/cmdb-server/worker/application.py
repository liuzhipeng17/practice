from db.tables import Tables


def get_application_by_id(session, _id):
    '''
    get application info by id
    :param session:
    :param _id:
    :return:
    '''

    application = Tables.application
    business_group = Tables.business_group
    department = Tables.department
    host_application = Tables.host_application

    application_res = session.query(application).filter(application.id == _id).first()
    business_group_id, department_id = session.query(application.business_group_id, application.department_id).filter(
        application.id == _id).first()
    department_name = session.query(department.name).filter(department.id == department_id).first()
    business_group_name = session.query(business_group.name).filter(business_group.id == business_group_id).first()
    host_application_res = session.query(host_application).filter(host_application.application_id == _id).all()

    department_name = department_name[0] if department_name else ''
    business_group_name = business_group_name[0] if business_group_name else ''

    host_app_list = []
    for info in host_application_res:
        host_app = {"host_id": info.host_id, "version": info.version, "deploy_path": info.deploy_path}
        host_app_list.append(host_app)

    application_res.__dict__.pop("_sa_instance_state")
    department_id = application_res.__dict__.pop("department_id")
    business_group_id = application_res.__dict__.pop("business_group_id")
    application_res.__dict__.update(
        {"department": {"id": department_id, "name": department_name},
         "business_group": {"id": business_group_id, "name": business_group_name}})

    application_res.__dict__.update({"host_application": host_app_list})

    return application_res.__dict__


def application_filter_by_department(session, application_query, department_name):
    """
    :param session:
    :param application_query:  a query object of host
    :param department_name: the department name  you want to find
    :return:  an query object
    """
    department = Tables.department
    application = Tables.application

    _id = session.query(department.id).filter(department.name == department_name)
    application_query = application_query.filter(application.department_id.in_(_id))
    return application_query


def application_filter_by_business_group(session, application_query, business_group_name):
    """
    :param session:
    :param application_query:  a query object of host
    :param business_group_name: the business group name  you want to find
    :return:  an query object
    """
    business_group = Tables.business_group
    application = Tables.application

    _id = session.query(business_group.id).filter(business_group.name == business_group_name)
    application_query = application_query.filter(application.business_group_id.in_(_id))
    return application_query


def application_filter_by_hostname(session, app_query, hostname):
    '''
    filter by hostname
    :param session:
    :param app_query:
    :param hostname:
    :return:
    '''
    host_application = Tables.host_application
    host = Tables.host
    application = Tables.application
    application_id = session.query(host_application.application_id).filter(host_application.host_id == host.id,
                                                                           host.hostname == hostname)
    app_query = app_query.filter(application.id.in_(application_id))
    return app_query


def application_filter_by_ip(session, app_query, _ip):
    ip = Tables.ip
    network_interface = Tables.host_network_interface
    host_application = Tables.host_application
    application = Tables.application

    host_id = session.query(network_interface.host_id).filter(
        ip.ip_addr == _ip, ip.host_network_interface_id == network_interface.id)
    application_id = session.query(host_application.application_id).filter(host_application.host_id.in_(host_id))

    app_query = app_query.filter(application.id.in_(application_id))
    return app_query


def get_application_users_id(session, application_id):
    users_id = session.query(Tables.user_application.user_id).filter(
        Tables.user_application.application_id == application_id).all()
    ret = []
    for _ in users_id:
        ret.append(_[0])
    return ret
