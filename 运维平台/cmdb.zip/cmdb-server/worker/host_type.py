from db.tables import Tables


def get_host_type_by_id(session, _id):
    '''
    get host_type info by id
    :param session:
    :param _id:
    :return:
    '''

    host_type = Tables.host_type
    host_type_res = session.query(host_type).filter(host_type.id == _id).first().to_dict()
    return host_type_res
