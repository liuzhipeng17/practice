from common.util import check_num
from db.tables import Tables


def get_host_by_id(session, _id):
    '''
    get host info by id
    :param session:
    :param _id:
    :return:
    '''

    host = Tables.host
    host_disk = Tables.host_disk
    ip = Tables.ip
    host_network_interface = Tables.host_network_interface
    zone_info = Tables.zone_info
    rack_info = Tables.rack_info
    application = Tables.application
    business_group = Tables.business_group
    host_application = Tables.host_application
    department = Tables.department

    host_res = session.query(host).filter(host.id == _id).first()
    disk_res = session.query(host_disk).filter(host_disk.host_id == _id).all()
    network_interface_res = session.query(host_network_interface).filter(host_network_interface.host_id == _id).all()
    rack_info_id = session.query(host.rack_info_id).filter(host.id == _id).first()[0]
    zone_info_res = session.query(zone_info, rack_info).filter(zone_info.id == rack_info.zone_info_id,
                                                               rack_info.id == rack_info_id).all()

    application_item_list = session.query(
        host_application.application_id, host_application.version, host_application.deploy_path,
        host_application.commit_id).filter(
        host_application.host_id == _id).all()
    application_dict = {}
    for item in application_item_list:
        application_dict.update({item[0]: {"version": item[1], "deploy_path": item[2], "commit_id": item[3]}})
    application_id = [i[0] for i in application_item_list] if application_item_list else []

    app_business_res = session.query(application.id, application.name,
                                     business_group.id, business_group.name).filter(
        application.business_group_id == business_group.id,
        application.id.in_(application_id)).all() if application_id else []

    host_res.__dict__.pop("_sa_instance_state")
    all_res = host_res.__dict__

    disk = []
    for i in range(0, len(disk_res)):
        disk_res[i].__dict__.pop("_sa_instance_state")
        disk.append(disk_res[i].__dict__)

    network_interface = []
    for i in range(0, len(network_interface_res)):
        network_interface_res[i].__dict__.pop("_sa_instance_state")
        ip_res = session.query(ip).filter(ip.host_network_interface_id == network_interface_res[i].__dict__['id']).all()
        _ip = []

        for ip_index in range(0, len(ip_res)):
            ip_res[ip_index].__dict__.pop("_sa_instance_state")
            _ip.append(ip_res[ip_index].__dict__)

        network_interface_res[i].__dict__.update({"ip": _ip})
        network_interface.append(network_interface_res[i].__dict__)

    zone = {}
    for i in range(0, len(zone_info_res)):
        zone_info_res[i].cmdb_rack_info.__dict__.pop("_sa_instance_state")
        zone_info_res[i].cmdb_zone_info.__dict__.pop("_sa_instance_state")
        zone.update({"zone_info": zone_info_res[i].cmdb_zone_info.__dict__,
                     "rack_info": zone_info_res[i].cmdb_rack_info.__dict__})

    _application = []
    for info in app_business_res:
        app_id, application_name, business_group_id, business_group_name = info
        application_version = application_dict[app_id]["version"]
        application_deploy_path = application_dict[app_id]["deploy_path"]
        application_commit_id = application_dict[app_id]["commit_id"]
        department_res = session.query(department.id, department.name).filter(
            department.id == application.department_id,
            application.id == app_id).first()
        department_id, department_name = department_res if department_res else ("", "")

        application_item = {"id": app_id, "name": application_name, "version": application_version,
                            "deploy_path": application_deploy_path, "commit_id": application_commit_id}
        business_group_item = {"id": business_group_id, "name": business_group_name}
        department_item = {"id": department_id, "name": department_name}

        application_item.update({"business_group": business_group_item, "department": department_item})

        _application.append(application_item)

    all_res.update({"disk": disk})
    all_res.update({"network_interface": network_interface})
    all_res.update({"zone": zone})
    all_res.update({"application_list": _application})

    return all_res


def host_filter_by_ip(session, host_query, _ip):
    """
    filter host by ip  ,get host_id by ip via network_interface
    :param session:
    :param host_query:  a query object of host
    :param _ip: the ip address you want to find,list
    :return:  an query object
    """
    ip = Tables.ip
    network_interface = Tables.host_network_interface

    _id = session.query(network_interface.host_id).filter(
        ip.ip_addr.in_(_ip), ip.host_network_interface_id == network_interface.id)
    host_query = host_query.filter(Tables.host.id.in_(_id))
    return host_query


def host_filter_by_application_name(session, host_query, application_name):
    """
    filter host by application_name
    :param session:
    :param host_query: a query object of host
    :param application_name:  the  application_name you want to find ,list
    :return: an query object
    """
    application = Tables.application
    host_application = Tables.host_application
    _id = session.query(host_application.host_id).filter(
        application.id == host_application.application_id, application.name.in_(application_name))
    host_query = host_query.filter(Tables.host.id.in_(_id))

    return host_query


def host_filter_by_zone_name(session, host_query, zone_name):
    """
    filter host by application_name
    :param session:
    :param host_query: a query object of host
    :param zone_name:  the  application_name you want to find
    :return: an query object
    """
    rack_info = Tables.rack_info
    zone_info = Tables.zone_info
    _id = session.query(rack_info.id).filter(
        rack_info.zone_info_id == zone_info.id, zone_info.name.in_(zone_name))
    host_query = host_query.filter(Tables.host.rack_info_id.in_(_id))

    return host_query


def host_filter_by_env_name(session, host_query, env_name):
    """
    filter host by application_name
    :param session:
    :param host_query: a query object of host
    :param  env_name:  the  application_name you want to find
    :return: an query object
    """
    env = Tables.env
    _id = session.query(env.id).filter(
        env.name.in_(env_name))
    host_query = host_query.filter(Tables.host.env_id.in_(_id))

    return host_query


def host_filter_by_business_group_name(session, host_query, business_group_name):
    """
     filter host by business_group_name
    :param session:
    :param host_query:
    :param business_group_name:
    :return:
    """
    application = Tables.application
    business_group = Tables.business_group
    host_application = Tables.host_application
    app_id = session.query(application.id).filter(application.business_group_id == business_group.id,
                                                  business_group.name.in_(business_group_name))
    host_id = session.query(host_application.host_id).filter(host_application.application_id.in_(app_id))
    host_query = host_query.filter(Tables.host.id.in_(host_id))
    return host_query


def host_filter_by_department_name(session, host_query, department_name):
    department = Tables.department
    application = Tables.application
    host_application = Tables.host_application
    # department_name = '%' + department_name + '%'
    app_id = session.query(application.id).filter(application.department_id == department.id,
                                                  department.name.in_(department_name))
    host_id = session.query(host_application.host_id).filter(
        host_application.application_id.in_(app_id)) if app_id else []
    host_query = host_query.filter(Tables.host.id.in_(host_id)) if host_id else host_query
    return host_query


def check_status_argus(status):
    """ check host agent status and status"""
    flag = None
    if status != -1:
        flag = check_num(status)
    return int(status) if flag else -1


def query_string_argus_to_list(query_argus):
    '''
    :param query_argus:
    :return:
    '''
    res_list = []

    if query_argus and query_argus[0] == '':
        return res_list
    if not isinstance(query_argus, list):
        return res_list
    for string in query_argus:
        res = [v for v in string.split(",")]
        res_list.extend(res)
    return res_list
