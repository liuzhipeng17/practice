from tornado.web import HTTPError


class CMDBError(HTTPError):
    pass


class ParamsError(HTTPError):
    pass


class DBError(HTTPError):
    pass


class ServerError(HTTPError):
    pass
