from common.authentication import validate_requests, validate_user_permission
from common.error import CMDBError
from db import sqlalchemy_util
from db.mysql import session_scope
from db.tables import Tables
from handler.base import BaseHandler
from worker import host


class HostHandler(BaseHandler):
    @validate_requests
    @validate_user_permission('get')
    def get(self):
        '''
        host 查找，支持hostname ,ip,status,agent_status,sn, application_name, zone_name
        组合查询(and)
        :return:  host info ,limit(1,15)   if no page argument
        '''

        page = int(self.get_argument("page", 1))
        page_size = int(self.get_argument("page_size", 15))
        '''status'''
        status = self.get_argument("status", -1)
        status = host.check_status_argus(status)
        '''agent_status'''
        agent_status = self.get_argument("agent_status", -1)
        agent_status = host.check_status_argus(agent_status)
        '''sn'''
        sn = self.get_arguments("sn")
        sn = host.query_string_argus_to_list(sn)
        """ zone_name"""
        zone_name = self.get_arguments("zone_name")
        zone_name = host.query_string_argus_to_list(zone_name)
        """env_name"""
        env_name = self.get_arguments("env_name")
        env_name = host.query_string_argus_to_list(env_name)
        """business_group_name"""
        business_group_name = self.get_arguments("business_group_name")
        business_group_name = host.query_string_argus_to_list(business_group_name)
        '''hostname'''
        hostname = self.get_arguments("hostname")
        hostname = host.query_string_argus_to_list(hostname)
        '''ip '''
        _ip = self.get_arguments("ip")
        _ip = host.query_string_argus_to_list(_ip)
        ''' application'''
        application_name = self.get_arguments("application_name")
        application_name = host.query_string_argus_to_list(application_name)
        '''department'''
        department = self.get_arguments("department_name")
        department = host.query_string_argus_to_list(department)

        ''''filter by host attribute'''
        host_query = sqlalchemy_util.find(self.session, Tables.host.id, return_query=True, **{})
        host_filters = {}
        if status > -1:
            host_filters.update({"status": status})
        if agent_status > -1:
            host_filters.update({"agent_status": agent_status})
        if sn:
            host_query = host_query.filter(Tables.host.sn.in_(sn))
        if hostname:
            host_query = host_query.filter(Tables.host.hostname.in_(hostname))
        if host_filters:
            host_query = sqlalchemy_util.find(self.session, Tables.host.id, return_query=True, **host_filters)

        """ filter by ip"""
        if _ip:
            host_query = host.host_filter_by_ip(self.session, host_query, _ip)
        """ filter by  application_name"""
        if application_name:
            host_query = host.host_filter_by_application_name(self.session, host_query, application_name)
        """filter by zone_name"""
        if zone_name:
            host_query = host.host_filter_by_zone_name(self.session, host_query, zone_name)
        """filter by env_name"""
        if env_name:
            host_query = host.host_filter_by_env_name(self.session, host_query, env_name)
        """filter by business_group_name"""
        if business_group_name:
            host_query = host.host_filter_by_business_group_name(self.session, host_query, business_group_name)
        '''filter by department'''
        if department:
            host_query = host.host_filter_by_department_name(self.session, host_query, department)

        total_count = host_query.count()

        '''limit return result'''
        offset = (page - 1) * page_size
        ids = [_id[0] for _id in host_query.offset(offset).limit(page_size)]

        res = []

        only_hostname = self.get_argument("only_hostname", None)
        if only_hostname and int(only_hostname) == 1:
            # 只返回hostname
            res = [h_instance.to_dict() for h_instance in
                   self.session.query(Tables.host).filter(Tables.host.id.in_(ids)).all()]
            self.render_json_response(code=200, msg='OK', res=res, total_count=total_count)
        else:
            # 返回所有属性
            for _id in ids:
                res.append(host.get_host_by_id(self.session, _id))

            self.render_json_response(code=200, msg="OK", res=res, total_count=total_count)

    @validate_requests
    @validate_user_permission('post')
    def post(self):

        '''post  arguments'''

        if not self.arguments:
            raise CMDBError(status_code=400, reason="json arguments is invalid")

        argus = self.arguments

        argus.pop("id")

        disk_argus = argus.pop('disk', [])
        network_interface_argus = argus.pop('network_interface', [])

        with session_scope(self.session) as session:
            host_instance = Tables.host(**argus)

            session.add(host_instance)
            session.flush()

            host_id = host_instance.id

            # disk
            for _argus in disk_argus:
                _argus.pop('id')
                _argus.update({'host_id': host_id})
                session.add(Tables.host_disk(**_argus))

            # network interface and ip
            for _argus in network_interface_argus:
                # 先pop无关属性
                ip_argus = _argus.pop('ip')

                _argus.pop('id')
                _argus.update({'host_id': host_id})

                network_interface_instance = Tables.host_network_interface(**_argus)

                session.add(network_interface_instance)
                session.flush()

                network_interface_id = network_interface_instance.id
                for _ip in ip_argus:
                    _ip.pop('id')

                    _ip.update({'host_network_interface_id': network_interface_id})

                    ip_instance = Tables.ip(**_ip)
                    session.add(ip_instance)

        res = self.session.query(Tables.host).filter(Tables.host.id == host_id).first().to_dict()
        self.render_json_response(msg="OK", code=200, id=host_id, res=res)

    @validate_requests
    @validate_user_permission('put')
    def put(self):
        """
        update host (including host_disk/host_network_interface/cmdb_ip)
        currently only support updating a host for once
        but can extend to a list of host
        :return:
        """

        argus = self.arguments
        if not argus:
            raise CMDBError(status_code=400, reason="json arguments is invalid")

        host_id = argus.pop("id")
        if not host_id:
            raise CMDBError(status_code=400, reason="Missing id for host")

        with session_scope(self.session) as session:
            # update disk
            disk_up_argus = argus.pop("disk", [])
            if disk_up_argus:
                # delete old disk
                session.query(Tables.host_disk).filter(Tables.host_disk.host_id == host_id).delete(
                    synchronize_session=False)

                for disk_argus in disk_up_argus:
                    disk_argus.pop('id')
                    disk_argus.update({'host_id': host_id})
                    session.add(Tables.host_disk(**disk_argus))

            # update network interface
            _network_interface_up_argus = argus.pop('network_interface', [])
            if _network_interface_up_argus:
                # delete old network interface
                old_network_interface = session.query(Tables.host_network_interface.id).filter(
                    Tables.host_network_interface.host_id == host_id).all()
                if old_network_interface:
                    # delete old ip
                    for _network_interface in old_network_interface:
                        session.query(Tables.ip).filter(
                            Tables.ip.host_network_interface_id == _network_interface[0]).delete(
                            synchronize_session=False)
                    # delete network interface
                    session.query(Tables.host_network_interface.id).filter(
                        Tables.host_network_interface.host_id == host_id).delete(synchronize_session=False)

                # add new network_interface
                for _argus in _network_interface_up_argus:
                    # 先pop无关属性
                    ip_argus = _argus.pop('ip')

                    _argus.pop('id')
                    _argus.update({'host_id': host_id})

                    network_interface_instance = Tables.host_network_interface(**_argus)

                    session.add(network_interface_instance)
                    session.flush()

                    network_interface_id = network_interface_instance.id

                    for _ip in ip_argus:
                        _ip.pop('id')
                        _ip.update({'host_network_interface_id': network_interface_id})
                        ip_instance = Tables.ip(**_ip)
                        session.add(ip_instance)

            # update application info
            session.query(Tables.host).filter_by(id=host_id).update(argus, synchronize_session=False)

        res = self.session.query(Tables.host).filter(Tables.host.id == host_id).first().to_dict()
        self.render_json_response(code=200, msg='OK', id=host_id, res=res)
