from common.authentication import validate_requests, validate_user_permission
from common.error import CMDBError
from db import sqlalchemy_util
from db.mysql import session_scope
from db.tables import Tables
from handler.base import BaseHandler


class HostNetWorkInterface(BaseHandler):
    @validate_requests
    @validate_user_permission('get')
    def get(self):
        name = self.get_argument("name", None)
        mac_addr = self.get_argument("mac_addr", None)
        host_id = int(self.get_argument("host_id", -1))
        hostname = self.get_argument("hostname", None)

        page = int(self.get_argument("page", 1))
        page_size = int(self.get_argument("page_size", 15))

        filters = {}
        if host_id == -1 and hostname:
            host_id = sqlalchemy_util.find(self.session, Tables.host.id, one=True, hostname=hostname)
            host_id = host_id[0] if host_id else None
        if host_id > -1:
            filters.update({"host_id": host_id})
        if name:
            filters.update({"name": name})
        if mac_addr:
            filters.update({"mac_addr": mac_addr})
        res, total_count = sqlalchemy_util.find(self.session, Tables.host_network_interface, page, page_size, **filters)
        res_list = [_.to_dict() for _ in res]
        self.render_json_response(code=200, msg="OK", res=res_list, total_count=total_count)

    @validate_requests
    @validate_user_permission('post')
    def post(self):
        """
        支持批量新增
        :return:
        """
        arguments = self.arguments
        if not arguments:
            raise CMDBError(status_code=400, reason="json arguments is invalid")
        q = sqlalchemy_util.find(self.session, Tables.host_network_interface, one=True, **arguments)
        if q:
            raise CMDBError(status_code=400, reason="record has existed")

        with session_scope(self.session) as session:
            host_network_interface = Tables.host_network_interface(**arguments)
            session.add(host_network_interface)
        res = self.session.query(Tables.host_network_interface).filter(
            Tables.host_network_interface.id == host_network_interface.id).first().to_dict()
        self.render_json_response(code=200, msg="OK", id=host_network_interface.id, res=res)

    @validate_requests
    @validate_user_permission('put')
    def put(self):
        """
        update  单个
        :return:
        """
        arguments = self.arguments
        if not arguments and "id" not in arguments.keys():
            raise CMDBError(status_code=400, reason="ID is required")
        _id = arguments.pop("id")
        filters = {"id": _id}
        up_argus = arguments
        row = sqlalchemy_util.update(self.session, Tables.host_network_interface, filters, up_argus)
        res = self.session.query(Tables.host_network_interface).filter(
            Tables.host_network_interface.id == _id).first().to_dict()
        self.render_json_response(code=200, msg="OK", effect_row=row, res=res)

    @validate_requests
    @validate_user_permission('delete')
    def delete(self):
        """
        单个删除
        :return:
        """
        arguments = self.arguments

        if not arguments:
            raise CMDBError(status_code=400, reason="json arguments is invalid")

        _id = arguments.get("id", None)
        if not _id:
            raise CMDBError(status_code=400, reason="id is required")

        filters = {'id': _id}
        sqlalchemy_util.delete(self.session, Tables.host_network_interface, **filters)
        self.render_json_response(code=200, msg="OK")
