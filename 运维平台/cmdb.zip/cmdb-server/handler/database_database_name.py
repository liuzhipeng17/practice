from sqlalchemy import and_

from common.authentication import validate_requests, validate_user_permission
from common.error import CMDBError
from db import sqlalchemy_util
from db.mysql import session_scope
from db.tables import Tables
from handler.base import BaseHandler


class Database_DatabaseNameHandler(BaseHandler):
    @validate_requests
    @validate_user_permission('get')
    def get(self, *argus):
        argus = self.arguments
        argus = argus if argus else {}
        page = int(self.get_argument("page", 1))
        page_size = int(self.get_argument("page_size", 15))

        res, total_count = sqlalchemy_util.find(self.session, Tables.database_database_name, page, page_size,
                                                **argus)
        real_res = []
        for ii in res:
            real_res.append(ii.to_dict())

        self.render_json_response(code=200, msg="OK", total_count=total_count, res=real_res)

    @validate_requests
    @validate_user_permission('post')
    def post(self, *args):
        """
        add database_database_name  object
        argument should be list
        :return:
        """
        arguments = self.arguments
        if not arguments:
            raise CMDBError(status_code=400, reason="json arguments is invalid")
        q = sqlalchemy_util.find(self.session, Tables.database_database_name, one=True, **arguments)
        if q:
            raise CMDBError(status_code=400, reason="record has existed")

        database_database_name = Tables.database_database_name(**arguments)
        with session_scope(self.session) as session:
            session.add(database_database_name)
        res = session.query(Tables.database_database_name).filter(
            Tables.database_database_name.id == database_database_name.id).first().to_dict()

        self.render_json_response(code=200, msg="OK", id=database_database_name.id, res=res)

    @validate_requests
    @validate_user_permission('put')
    def put(self, *argus):
        """update database_database_name"""

        arguments = self.arguments
        if "id" not in arguments.keys():
            raise CMDBError(status_code=400, reason="ID is required")
        q = self.session.query(Tables.database_database_name).filter(
            Tables.database_database_name.id == arguments['id']).first()
        if not q:
            raise CMDBError(status_code=400, reason="ID not exist")

        _id = arguments.pop("id")
        filters = {"id": _id}
        row = sqlalchemy_util.update(self.session, Tables.database_database_name, filters, arguments)

        res = self.session.query(Tables.database_database_name).filter(
            Tables.database_database_name.id == _id).first().to_dict()
        self.render_json_response(code=200, msg="OK", effect_row=row, res=res)

    @validate_requests
    @validate_user_permission('delete')
    def delete(self):
        """ delete database_database_name by id"""

        arguments = self.arguments
        if "id" not in arguments.keys():
            raise CMDBError(status_code=400, reason="ID is required")
        _id = arguments.pop("id")
        filters = {"id": _id}
        sqlalchemy_util.delete(self.session, Tables.database_database_name, filters)
        self.render_json_response(code=200, msg="OK")
