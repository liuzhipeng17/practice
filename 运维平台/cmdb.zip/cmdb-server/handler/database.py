from common.authentication import validate_requests, validate_user_permission
from common.error import CMDBError
from db import sqlalchemy_util
from db.mysql import session_scope
from db.tables import Tables
from handler.base import BaseHandler


class DatabaseHandler(BaseHandler):
    @validate_requests
    @validate_user_permission('get')
    def get(self, *argus):
        argus = self.arguments
        argus = argus if argus else {}
        page = int(self.get_argument("page", 1))
        page_size = int(self.get_argument("page_size", 15))

        res, total_count = sqlalchemy_util.find(self.session, Tables.database, page, page_size,
                                                **argus)
        real_res = []
        for ii in res:
            real_res.append(ii.to_dict())

        self.render_json_response(code=200, msg="OK", total_count=total_count, res=real_res)

    @validate_requests
    @validate_user_permission('post')
    def post(self):
        """
        add database  object
        argument should be list
        :return:
        """
        arguments = self.arguments

        if not arguments:
            raise CMDBError(status_code=400, reason="json arguments is invalid")
        q = sqlalchemy_util.find(self.session, Tables.database, one=True, **arguments)
        if q:
            raise CMDBError(status_code=400, reason="record has existed")

        database = Tables.database(**arguments)
        with session_scope(self.session) as session:
            session.add(database)
        res = session.query(Tables.database).filter(Tables.database.id == database.id).first().to_dict()
        self.render_json_response(code=200, msg="OK", id=database.id, res=res)

    @validate_requests
    @validate_user_permission('put')
    def put(self):
        """update database"""

        arguments = self.arguments
        if "id" not in arguments.keys():
            raise CMDBError(status_code=400, reason="ID is required")

        q = self.session.query(Tables.database).filter(
            Tables.database.id == arguments['id']).first()
        if not q:
            raise CMDBError(status_code=400, reason="ID not exist")

        _id = arguments.pop("id")
        filters = {"id": _id}
        row = sqlalchemy_util.update(self.session, Tables.database, filters, arguments)
        res = self.session.query(Tables.database).filter(Tables.database.id == _id).first().to_dict()
        self.render_json_response(code=200, msg="OK", effect_row=row, res=res)

    @validate_requests
    @validate_user_permission('delete')
    def delete(self):
        """ delete database by id"""

        arguments = self.arguments
        if "id" not in arguments.keys():
            raise CMDBError(status_code=400, reason="ID is required")
        _id = arguments.pop("id")
        filters = {"id": _id}
        sqlalchemy_util.delete(self.session, Tables.database, filters)
        self.render_json_response(code=200, msg="OK")
