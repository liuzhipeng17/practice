from common.authentication import validate_requests, validate_user_permission
from common.error import CMDBError
from db import sqlalchemy_util
from db.mysql import session_scope
from db.tables import Tables
from handler.base import BaseHandler
from worker import application
from worker.application import application_filter_by_business_group
from worker.application import application_filter_by_department
from worker.application import application_filter_by_hostname
from worker.application import get_application_by_id, get_application_users_id
from worker.user import get_user_by_id


class ApplicationHandler(BaseHandler):
    @validate_requests
    @validate_user_permission('get')
    def get(self):
        '''
        application 查找，支持id，name ,department_name ,business_group_name
        组合查询(and)
        :return:  application list ,limit(1,15)   if no page arguments
        '''
        page = int(self.get_argument("page", 1))
        page_size = int(self.get_argument("page_size", 15))

        '''application '''
        _id = int(self.get_argument("id", -1))
        name = self.get_argument("name", None)
        department_name = self.get_argument("department_name", None)
        business_group_name = self.get_argument("business_group_name", None)
        hostname = self.get_argument("hostname", None)
        ip = self.get_argument("ip", None)

        ''''filter by application attribute'''
        application_filter = {}
        if _id > -1:
            application_filter.update({"id": _id})
        if name:
            application_filter.update({"name": name})
        if application_filter:
            application_query = sqlalchemy_util.find(self.session, Tables.application.id, return_query=True,
                                                     **application_filter)
        else:  # no filters,just return a application query object
            application_query = sqlalchemy_util.find(self.session, Tables.application.id, return_query=True,
                                                     **{})

        '''filter by department_name'''
        if department_name:
            application_query = application_filter_by_department(self.session, application_query, department_name)
        '''filter by business_group_name'''
        if business_group_name:
            application_query = application_filter_by_business_group(self.session, application_query,
                                                                     business_group_name)
        if hostname:
            application_query = application_filter_by_hostname(self.session, application_query, hostname)

        if ip:
            application_query = application.application_filter_by_ip(self.session, application_query, ip)

        total_count = application_query.count()

        '''limit return result'''
        offset = (page - 1) * page_size
        ids = [_id[0] for _id in
               application_query.order_by(Tables.application.name).offset(offset).limit(page_size)]

        res = []

        for _id in ids:
            res.append(get_application_by_id(self.session, _id))
        for _res in res:
            users_id = get_application_users_id(self.session, _res['id'])
            user_list = []
            for user_id in users_id:
                user_list.append(get_user_by_id(self.session, user_id))
            _res.update({'user_list': user_list})
        self.render_json_response(code=200, msg="OK", res=res, total_count=total_count)

    @validate_requests
    @validate_user_permission('post')
    def post(self):
        '''post  arguments'''

        argus = self.arguments
        code = 200
        msg = 'OK'
        res = {}
        user_id_list = argus.pop('user_id_list', [])
        if not argus:
            raise CMDBError(status_code=400, reason="json arguments is invalid")

        name = argus.get('name', None)
        if not name:
            raise CMDBError(status_code=400, reason="name is required")

        q = sqlalchemy_util.find(self.session, Tables.application, one=True, **argus)
        if q:
            raise CMDBError(status_code=400, reason="name has existed")

        with session_scope(self.session) as session:
            app = Tables.application(**argus)
            session.add(app)
            session.flush()

            _id = app.id

            if user_id_list:
                for user_id in user_id_list:
                    session.add(Tables.user_application(application_id=app.id, user_id=user_id))
            qr = session.query(Tables.application).filter(Tables.application.id == app.id).first()
            qr.__dict__.pop("_sa_instance_state", [])
            res.update(qr.__dict__)

        self.render_json_response(code=code, msg=msg, id=_id, res=res)

    @validate_requests
    @validate_user_permission('put')
    def put(self):
        """
        update application name
        """

        code = 200
        msg = 'OK'
        arguments = self.arguments

        if not arguments:
            raise CMDBError(status_code=400, reason="json arguments is invalid")

        _id = arguments.get("id", None)
        if not _id:
            raise CMDBError(status_code=400, reason="id is required")

        with session_scope(self.session) as session:
            user_id_list = arguments.pop('user_id_list', None)

            # update user list
            if user_id_list:
                # delete old user firstly
                session.query(Tables.user_application).filter(
                    Tables.user_application.application_id == _id).delete(
                    synchronize_session=False)
                for user_id in user_id_list:
                    session.add(Tables.user_application(application_id=_id, user_id=user_id))

            # update application info
            session.query(Tables.application).filter_by(id=_id).update(arguments, synchronize_session=False)

            res = session.query(Tables.application).filter(Tables.application.id == _id).first().to_dict()

        self.render_json_response(code=code, msg=msg, res=res)
