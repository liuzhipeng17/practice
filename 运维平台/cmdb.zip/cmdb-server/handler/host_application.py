from common.authentication import validate_requests, validate_user_permission
from common.error import CMDBError
from db import sqlalchemy_util
from db.mysql import session_scope
from db.tables import Tables
from handler.base import BaseHandler
from worker import host
from worker.host_application import get_host_application_by_id


class HostApplicationHandler(BaseHandler):
    @validate_requests
    @validate_user_permission('get')
    def get(self):
        """
        host_application 查找，支持id, host_id , application_id
        组合查询(and)
        :return:  host_application list ,limit(1,15)   if no page arguments
        """
        page = int(self.get_argument("page", 1))
        page_size = int(self.get_argument("page_size", 15))
        '''host_application '''
        _id = int(self.get_argument("id", -1))
        application_id = int(self.get_argument("application_id", 0))
        host_id = int(self.get_argument("host_id", 0))
        ''''filter by host_application attribute'''
        host_application_filter = {}
        if _id > -1:
            host_application_filter.update({"id": _id})
        if application_id:
            host_application_filter.update({"application_id": application_id})
        if host_id:
            host_application_filter.update({"host_id": host_id})
        if host_application_filter:
            h_id = sqlalchemy_util.find(self.session, Tables.host_application.id, return_query=True,
                                        **host_application_filter)
        else:
            h_id = self.session.query(Tables.host_application.id)
        total_count = h_id.count()

        '''limit return result'''
        offset = (page - 1) * page_size
        ids = [_id[0] for _id in h_id.offset(offset).limit(page_size)]

        res = []

        for _id in ids:
            res.append(get_host_application_by_id(self.session, _id))

        for index, host_application in enumerate(res):
            host_id = host_application["host_id"]
            _host = host.get_host_by_id(self.session, host_id)
            res[index].update({"host": _host})

        self.render_json_response(code=200, msg="OK", res=res, total_count=total_count)

    @validate_requests
    @validate_user_permission('post')
    def post(self, *argus):

        """post  arguments"""

        argus = self.arguments
        if not argus:
            raise CMDBError(status_code=400, reason="json arguments is invalid")
        application_id = int(argus.get('application_id', 0))
        host_id = int(argus.get('host_id', 0))
        if not application_id:
            raise CMDBError(status_code=400, reason="application_id is required")
        if not host_id:
            raise CMDBError(status_code=400, reason="host_id is required")

        q = sqlalchemy_util.find(self.session, Tables.host_application, one=True, **argus)
        if q:
            raise CMDBError(status_code=400, reason="application_id and host_id  has existed")

        with session_scope(self.session) as session:
            host_application = Tables.host_application(**argus)
            session.add(host_application)

        res = self.session.query(Tables.host_application).filter(
            Tables.host_application.id == host_application.id).first().to_dict()
        self.render_json_response(code=200, msg="OK", id=host_application.id, res=res)

    @validate_requests
    @validate_user_permission('put')
    def put(self):
        """
        update host_application by host_id or application
        """

        argus = self.arguments

        if not argus:
            raise CMDBError(status_code=400, reason="json arguments is invalid")

        _id = argus.get("id", None)
        if not _id:
            raise CMDBError(status_code=400, reason="id is required")
        q = sqlalchemy_util.find(self.session, Tables.host_application, one=True, **{'id': _id})
        if not q:
            raise CMDBError(status_code=404, reason="id not found")

        row = sqlalchemy_util.update(self.session, Tables.host_application, filters={'id': _id}, up_argus=argus,
                                     flag=True)
        res = self.session.query(Tables.host_application).filter(Tables.host_application.id == _id).first().to_dict()
        self.render_json_response(code=200, msg="OK", effect_row=row, res=res)

    @validate_requests
    @validate_user_permission('delete')
    def delete(self, *args, **kwargs):

        """ delete by ids"""
        arguments = self.arguments

        if not arguments:
            raise CMDBError(status_code=400, reason="json arguments is invalid")

        _id = arguments.get("id", None)
        if not _id:
            raise CMDBError(status_code=400, reason="id is required")

        filters = {"id": _id}
        sqlalchemy_util.delete(self.session, Tables.host_application, filters)
        self.render_json_response(code=200, msg="OK")
