from common.authentication import validate_requests
from common.authentication import validate_user_permission
from common.error import CMDBError
from db import sqlalchemy_util
from db.mysql import session_scope
from db.tables import Tables
from handler.base import BaseHandler


class UserDepartmentHandler(BaseHandler):
    @validate_requests
    @validate_user_permission('get')
    def get(self, *argus):
        argus = self.arguments
        argus = argus if argus else {}
        page = int(self.get_argument("page", 1))
        page_size = int(self.get_argument("page_size", 15))

        res, total_count = sqlalchemy_util.find(self.session, Tables.user_department, page, page_size,
                                                **argus)
        real_res = [_.to_dict() for _ in res]

        self.render_json_response(code=200, msg="OK", total_count=total_count, res=real_res)

    @validate_requests
    @validate_user_permission('post')
    def post(self, *args):
        """
        add user_department  object
        argument should be list
        :return:
        """
        arguments = self.arguments
        if not arguments:
            raise CMDBError(status_code=400, reason="json arguments is invalid")
        arguments.pop('id')
        q = sqlalchemy_util.find(self.session, Tables.user_department, one=True, **arguments)
        if q:
            raise CMDBError(status_code=400, reason="record has existed")

        user_id = int(arguments.get('user_id', 0))
        department_id = int(arguments.get('department_id', 0))
        if not department_id:
            raise CMDBError(status_code=400, reason="department_id is required")
        if not user_id:
            raise CMDBError(status_code=400, reason="user_id is required")

        with session_scope(self.session) as session:
            user_department_instance = Tables.user_department(**arguments)

            session.add(user_department_instance)

        _id = user_department_instance.id

        res = self.session.query(Tables.user_department).filter(Tables.user_department.id == _id).first().to_dict()
        self.render_json_response(code=200, msg="OK", id=_id, res=res)

    @validate_requests
    @validate_user_permission('put')
    def put(self, *argus):
        """update user_department"""

        arguments = self.arguments
        _id = arguments.pop("id")
        if not _id:
            raise CMDBError(status_code=400, reason="ID is required")
        filters = {"id": _id}

        sqlalchemy_util.update(self.session, Tables.user_department, filters, arguments)

        res = self.session.query(Tables.user_department).filter(Tables.user_department.id == _id).first().to_dict()
        self.render_json_response(code=200, msg="OK", id=_id, res=res)

    @validate_requests
    @validate_user_permission('delete')
    def delete(self):
        """ delete user_department by id"""

        arguments = self.arguments
        if "id" not in arguments.keys():
            raise CMDBError(status_code=400, reason="ID is required")
        _id = arguments.pop("id")
        filters = {"id": _id}
        sqlalchemy_util.delete(self.session, Tables.user_department, filters)
        self.render_json_response(code=200, msg="OK")
