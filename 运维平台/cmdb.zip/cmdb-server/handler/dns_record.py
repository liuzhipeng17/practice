from common.authentication import validate_requests, validate_user_permission
from common.error import CMDBError
from db import sqlalchemy_util
from db.mysql import session_scope
from db.tables import Tables
from handler.base import BaseHandler


class DnsRecordHandler(BaseHandler):
    @validate_requests
    @validate_user_permission('get')
    def get(self, *argus):
        argus = self.arguments
        argus = argus if argus else {}
        page = int(self.get_argument("page", 1))
        page_size = int(self.get_argument("page_size", 15))

        res, total_count = sqlalchemy_util.find(self.session, Tables.dns_record, page, page_size,
                                                **argus)
        real_res = [_.to_dict() for _ in res]

        self.render_json_response(code=200, msg="OK", total_count=total_count, res=real_res)

    @validate_requests
    @validate_user_permission('post')
    def post(self, *args):
        """
        add dns_record  object
        argument should be list
        :return:
        """
        arguments = self.arguments
        if not arguments:
            raise CMDBError(status_code=400, reason="json arguments is invalid")
        q = sqlalchemy_util.find(self.session, Tables.dns_record, one=True, **arguments)
        if q:
            raise CMDBError(status_code=400, reason="record has existed")

        with session_scope(self.session) as session:
            dns_record_instance = Tables.dns_record(**arguments)
            session.add(dns_record_instance)
        res = self.session.query(Tables.dns_record).filter(
            Tables.dns_record.id == dns_record_instance.id).first().to_dict()
        self.render_json_response(code=200, msg="OK", id=dns_record_instance.id, res=res)

    @validate_requests
    @validate_user_permission('put')
    def put(self):
        """update dns_record"""
        arguments = self.arguments
        _id = arguments.pop("id")

        if not _id:
            raise CMDBError(status_code=400, reason="ID is required")
        q = self.session.query(Tables.dns_record).filter(Tables.dns_record.id == _id).first()
        if not q:
            raise CMDBError(status_code=400, reason="ID not exist")

        with session_scope(self.session) as session:

            # update dns_record info
            session.query(Tables.dns_record).filter_by(id=_id).update(arguments, synchronize_session=False)

            res = session.query(Tables.dns_record).filter(Tables.dns_record.id == _id).first().to_dict()

        self.render_json_response(code=200, msg="OK", id=_id, res=res)

    @validate_requests
    @validate_user_permission('delete')
    def delete(self):
        """ delete dns_record by id"""

        arguments = self.arguments
        if "id" not in arguments.keys():
            raise CMDBError(status_code=400, reason="ID is required")
        _id = arguments.pop("id")
        filters = {"id": _id}
        sqlalchemy_util.delete(self.session, Tables.dns_record, filters)
        self.render_json_response(code=200, msg="OK")
