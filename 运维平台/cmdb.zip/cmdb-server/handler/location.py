from common.authentication import validate_requests, validate_user_permission
from common.error import CMDBError
from db import sqlalchemy_util
from db.mysql import session_scope
from db.tables import Tables
from handler.base import BaseHandler
from worker.location import get_location_by_id


class LocationHandler(BaseHandler):
    @validate_requests
    @validate_user_permission('get')
    def get(self):
        '''
        location 查找，支持id，name
        组合查询(and)
        :return:  location list ,limit(1,15)   if no page arguments
        '''
        page = int(self.get_argument("page", 1))
        page_size = int(self.get_argument("page_size", 15))

        '''location '''
        _id = int(self.get_argument("id", -1))

        ''''filter by location attribute'''
        location_filter = {}
        if _id > -1:
            location_filter.update({"id": _id})
        if location_filter:
            h_id = sqlalchemy_util.find(self.session, Tables.location.id, return_query=True, **location_filter)
        else:
            h_id = self.session.query(Tables.location.id)

        total_count = h_id.count()

        '''limit return result'''
        offset = (page - 1) * page_size
        ids = [_id[0] for _id in h_id.offset(offset).limit(page_size)]

        res = []

        for _id in ids:
            res.append(get_location_by_id(self.session, _id))

        self.render_json_response(code=200, msg="OK", res=res, total_count=total_count)

    @validate_requests
    @validate_user_permission('post')
    def post(self):

        '''post  arguments'''

        arguments = self.arguments

        if not arguments:
            raise CMDBError(status_code=400, reason="json arguments is invalid")

        path = arguments.get('path', None)
        backend_group_id = arguments.get('backend_group_id', None)
        if not path:
            raise CMDBError(status_code=400, reason="path is required")
        if not backend_group_id:
            raise CMDBError(status_code=400, reason="backend_group_id is required")

        q = sqlalchemy_util.find(self.session, Tables.location, one=True, **arguments)
        if q:
            raise CMDBError(status_code=400, reason="path and backend_group_id  has existed")

        with session_scope(self.session) as session:
            location_instance = Tables.location(**arguments)
            session.add(location_instance)
        res = self.session.query(Tables.location).filter(
            Tables.env.id == location_instance.id).first().to_dict()
        self.render_json_response(code=200, msg="OK", id=location_instance.id, res=res)

    @validate_requests
    @validate_user_permission('put')
    def put(self):
        """
        update location name
        """

        arguments = self.arguments

        if not arguments:
            raise CMDBError(status_code=400, reason="json arguments is invalid")

        _id = arguments.get("id", None)
        if not _id:
            raise CMDBError(status_code=400, reason="id is required")
        q = sqlalchemy_util.find(self.session, Tables.location, one=True, **{'id': _id})
        if not q:
            raise CMDBError(status_code=404, reason="id not found")

        with session_scope(self.session) as session:

            # update location info
            session.query(Tables.location).filter_by(id=_id).update(arguments, synchronize_session=False)

            res = session.query(Tables.location).filter(Tables.location.id == _id).first().to_dict()

        self.render_json_response(code=200, msg="OK", id=_id, res=res)
