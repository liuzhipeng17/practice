from common.authentication import validate_requests, validate_user_permission
from common.error import CMDBError
from db import sqlalchemy_util
from db.mysql import session_scope
from db.tables import Tables
from handler.base import BaseHandler
from worker.host_type import get_host_type_by_id


class HostTypeHandler(BaseHandler):
    @validate_requests
    @validate_user_permission('get')
    def get(self):
        """
        host_type 查找，支持id，name
        组合查询(and)
        :return:  host_type list ,limit(1,15)   if no page arguments
        """
        page = int(self.get_argument("page", 1))
        page_size = int(self.get_argument("page_size", 15))

        # host_type
        _id = int(self.get_argument("id", -1))
        name = self.get_argument("name", None)

        # filter by host_type attribute
        host_type_filter = {}
        if _id > -1:
            host_type_filter.update({"id": _id})
        if name:
            host_type_filter.update({"name": name})
        if host_type_filter:
            h_id = sqlalchemy_util.find(self.session, Tables.host_type.id, return_query=True, **host_type_filter)
        else:
            h_id = self.session.query(Tables.host_type.id)

        total_count = h_id.count()

        # limit return result
        offset = (page - 1) * page_size
        ids = [_id[0] for _id in h_id.offset(offset).limit(page_size)]

        res = [get_host_type_by_id(self.session, _id) for _id in ids]
        self.render_json_response(code=200, msg="OK", res=res, total_count=total_count)

    @validate_requests
    @validate_user_permission('post')
    def post(self, *argus):

        """
        post  arguments
        """

        argus = self.arguments

        if not argus:
            raise CMDBError(status_code=400, reason="json arguments is invalid")

        name = argus.get('name', None)
        if not name:
            raise CMDBError(status_code=400, reason="name is required")

        q = sqlalchemy_util.find(self.session, Tables.host_type, one=True, **argus)
        if q:
            raise CMDBError(status_code=400, reason="name has existed")
        with session_scope(self.session) as session:
            host_type = Tables.host_type(**argus)
            session.add(host_type)

        res = self.session.query(Tables.host_type).filter(Tables.host_type.id == host_type.id).first().to_dict()
        self.render_json_response(code=200, msg="OK", id=host_type.id, res=res)

    @validate_requests
    @validate_user_permission('put')
    def put(self):
        """
        update host_type name
        """

        argus = self.arguments

        if not argus:
            raise CMDBError(status_code=400, reason="json arguments is invalid")

        _id = argus.get("id", None)
        if not _id:
            raise CMDBError(status_code=400, reason="id is required")
        q = sqlalchemy_util.find(self.session, Tables.host_type, one=True, **{'id': _id})
        if not q:
            raise CMDBError(status_code=404, reason="id not found")

        name = argus.get('name', None)
        if not name:
            raise CMDBError(status_code=400, reason="name is required")

        row = sqlalchemy_util.update(self.session, Tables.host_type, filters={'id': _id}, up_argus={'name': name},
                                     flag=True)
        res = self.session.query(Tables.host_type).filter(Tables.host_type.id == _id).first().to_dict()
        self.render_json_response(code=200, msg="OK", effect_row=row, res=res)
