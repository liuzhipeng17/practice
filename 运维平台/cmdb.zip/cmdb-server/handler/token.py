import jwt
from ldap3.core.exceptions import LDAPException
from tornado.log import app_log

from common import ldap
from common.error import CMDBError
from conf import settings
from .base import BaseHandler


class TokenHandler(BaseHandler):
    def post(self):
        """
        用户登录,获取token
        """

        username = self.arguments.get('username')
        password = self.arguments.get('password')

        if not username or not password:
            raise CMDBError(status_code=400, reason='Missing arguments,please check  your username & password')

        try:
            user = ldap.valid_user(username, password)
        except LDAPException as e:
            app_log.error(e)
            raise CMDBError(status_code=500, reason='ldap error')

        if not user:
            raise CMDBError(status_code=400, reason='valid failed')

        token = jwt.encode(payload=user, key=settings['token_secret'], algorithm='HS256').decode("utf-8")

        self.render_json_response(code=200, msg='OK', res={'token': token})
