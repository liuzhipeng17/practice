from common.authentication import validate_requests, validate_user_permission
from common.error import CMDBError
from db import sqlalchemy_util
from db.mysql import session_scope
from db.tables import Tables
from handler.base import BaseHandler
from worker.user import get_specified_users


class UserHandler(BaseHandler):
    @validate_requests
    @validate_user_permission('get')
    def get(self, *argus):
        argus = self.arguments
        argus = argus if argus else {}
        page = int(self.get_argument("page", 1))
        page_size = int(self.get_argument("page_size", 15))
        department_id = argus.get('department_id', None)
        username = argus.get('username', None)
        if department_id or username:
            res, total_count = get_specified_users(self.session,
                                                   **{'department_id': department_id, 'username': username})
        else:
            res, total_count = sqlalchemy_util.find(self.session, Tables.user, page, page_size, **argus)
        real_res = []
        for ii in res:
            ii.__dict__.pop("_sa_instance_state")
            ii.__dict__.pop('password')
            real_res.append(ii.__dict__)

        self.render_json_response(code=200, msg="OK", total_count=total_count, res=real_res)

    @validate_requests
    @validate_user_permission('post')
    def post(self, *args):
        """
        add user  object
        argument should be list
        :return:
        """
        arguments = self.arguments
        if not arguments:
            raise CMDBError(status_code=400, reason="json arguments is invalid")
        arguments.pop('id')
        q = sqlalchemy_util.find(self.session, Tables.user, one=True, **arguments)
        if q:
            raise CMDBError(status_code=400, reason="record has existed")
        with session_scope(self.session) as session:
            user_instance = Tables.user(**arguments)

            session.add(user_instance)

            session.flush()
            _id = user_instance.id

        res = self.session.query(Tables.user).filter(Tables.user.id == _id).first()
        res.__dict__.pop("_sa_instance_state")
        self.render_json_response(code=200, msg="OK", id=_id, res=res.__dict__)

    @validate_requests
    @validate_user_permission('put')
    def put(self):
        """update user"""

        arguments = self.arguments
        if not arguments:
            raise CMDBError(status_code=400, reason="json arguments is invalid")

        _id = arguments.pop("id")
        if not _id:
            raise CMDBError(status_code=400, reason="ID is required")

        filters = {"id": _id}
        sqlalchemy_util.update(self.session, Tables.user, filters, arguments)

        res = self.session.query(Tables.user).filter(Tables.user.id == _id).first()
        res.__dict__.pop("_sa_instance_state")
        self.render_json_response(code=200, msg="OK", id=_id, res=res.__dict__)

    @validate_requests
    @validate_user_permission('delete')
    def delete(self):
        """ delete user by id"""

        arguments = self.arguments
        if not arguments:
            raise CMDBError(status_code=400, reason="json arguments is invalid")

        _id = arguments.pop("id")
        if not _id:
            raise CMDBError(status_code=400, reason="ID is required")
        filters = {"id": _id}
        sqlalchemy_util.delete(self.session, Tables.user, filters)
        self.render_json_response(code=200, msg="OK")
