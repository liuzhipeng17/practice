from common.authentication import validate_requests, validate_user_permission
from common.error import CMDBError
from db import sqlalchemy_util
from db.mysql import session_scope
from db.tables import Tables
from handler.base import BaseHandler
from worker.backend_group import get_backend_group_by_id


class BackendGroupHandler(BaseHandler):
    @validate_requests
    @validate_user_permission('get')
    def get(self):
        '''
        backend_group 查找，支持id，name
        组合查询(and)
        :return:  backend_group list ,limit(1,15)   if no page arguments
        '''
        page = int(self.get_argument("page", 1))
        page_size = int(self.get_argument("page_size", 15))

        '''backend_group '''
        _id = int(self.get_argument("id", -1))
        name = self.get_argument("name", None)
        application_id = ''
        if name:
            application = Tables.application
            application_id = self.session.query(application.id).filter(application.name == name).first()[0]

        ''''filter by backend_group attribute'''
        backend_group_filter = {}
        if _id > -1:
            backend_group_filter.update({"id": _id})
        if application_id:
            backend_group_filter.update({"application_id": application_id})
        if backend_group_filter:
            h_id = sqlalchemy_util.find(self.session, Tables.backend_group.id, return_query=True,
                                        **backend_group_filter)
        else:
            h_id = self.session.query(Tables.backend_group.id)

        total_count = h_id.count()

        '''limit return result'''
        offset = (page - 1) * page_size
        ids = [_id[0] for _id in h_id.offset(offset).limit(page_size)]

        res = []

        for _id in ids:
            res.append(get_backend_group_by_id(self.session, _id))

        self.render_json_response(code=200, msg="OK", res=res, total_count=total_count)

    @validate_requests
    @validate_user_permission('post')
    def post(self, *argus):

        '''post  arguments'''

        argus = self.arguments

        if not argus:
            raise CMDBError(status_code=400, reason="json arguments is invalid")

        application_id = argus.get('application_id', None)
        if not application_id:
            raise CMDBError(status_code=400, reason="application_id as backend_group name is required, ")

        q = sqlalchemy_util.find(self.session, Tables.backend_group, one=True, **argus)
        if q:
            raise CMDBError(status_code=400, reason="name has existed")

        with session_scope(self.session) as session:
            backend_group = Tables.backend_group(**argus)
            session.add()
        res = self.session.query(Tables.backend_group).filter(
            Tables.backend_group.id == backend_group.id).first().to_dict()

        self.render_json_response(code=200, msg="OK", id=backend_group.id, res=res)

    @validate_requests
    @validate_user_permission('put')
    def put(self):
        """
        update backend_group name
        """

        argus = self.arguments

        if not argus:
            raise CMDBError(status_code=400, reason="json arguments is invalid")

        _id = argus.get("id", None)
        if not _id:
            raise CMDBError(status_code=400, reason="id is required")
        q = sqlalchemy_util.find(self.session, Tables.backend_group, one=True, **{'id': _id})
        if not q:
            raise CMDBError(status_code=404, reason="id not found")

        row = sqlalchemy_util.update(self.session, Tables.backend_group, filters={'id': _id}, up_argus=argus, flag=True)
        res = self.session.query(Tables.backend_group).filter(Tables.backend_group.id == _id).first().to_dict()

        self.render_json_response(code=200, msg="OK", effect_row=row, res=res)
