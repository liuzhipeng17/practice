import json

import tornado.auth
import tornado.escape
import tornado.gen
import tornado.httpclient
import tornado.httputil
import tornado.ioloop
import tornado.locale
import tornado.options
import tornado.web
from tornado.log import app_log

from common import error
from common import util
from db import mysql

HTTPError = tornado.web.HTTPError

json_encoder = util.json_encoder
json_decoder = util.json_decoder


class BaseHandler(tornado.web.RequestHandler):
    """
        BaseHandler
        override class method to adapt special demands
    """

    def set_default_headers(self):
        self.set_header("Access-Control-Allow-Origin", "*")
        self.set_header("Access-Control-Allow-Headers", "x-requested-with")
        self.set_header('Access-Control-Allow-Methods', 'POST, PUT, GET, DELETE, OPTIONS')
        self.set_header('Access-Control-Allow-Headers', 'x-requested-with,content-type,token')

    def options(self, *argus):
        # no body
        self.set_status(204)
        self.finish()

    def _get_argument(self, name, default, source, strip=True):
        args = self._get_arguments(name, source, strip=strip)
        if not args:
            if default is self._ARG_DEFAULT:
                raise tornado.web.MissingArgumentError(name)
            return default
        return args[0]

    def write_error(self, status_code, **kwargs):
        self.render_json_response(code=status_code, msg=self._reason)

    def log_exception(self, typ, value, tb):
        if isinstance(value, HTTPError):
            if value.log_message:
                warning_format = '%d %s: ' + value.log_message
                args = ([value.status_code, self._request_summary()] + list(value.args))
                app_log.warning(warning_format, *args)

        app_log.error('Exception: %s\n%r', self._request_summary(),
                      self.request, exc_info=(typ, value, tb))

    def render_json_response(self, **kwargs):
        """
            Encode dict and return response to client
        """
        callback = self.get_argument('callback', None)
        if callback:
            # return jsonp
            self.set_status(200, kwargs.get('msg', None))
            self.finish('{}({})'.format(callback, json_encoder(kwargs)))
        else:
            self.set_status(kwargs['code'], kwargs.get('msg', None))
            self.set_header('Content-Type', 'application/json;charset=utf-8')
            _format = self.get_argument('_format', None)
            if _format:
                # return with indent
                self.finish(json.dumps(json.loads(json_encoder(kwargs)), indent=4))
            else:
                self.finish(json_encoder(kwargs))

    def prepare(self):
        """
            prepare session and post arguments
        """

        sessionmaker = mysql.connect()
        if not sessionmaker:
            raise HTTPError(500, 'session is none')
        self.session = sessionmaker()

        self.arguments = {}

        if self.request.body:
            try:
                arguments = json_decoder(tornado.escape.native_str(self.request.body))
                self.arguments = arguments
            except json.decoder.JSONDecodeError:
                """invalid  json arguments"""
                raise error.CMDBError(status_code=400, reason="JSONDecodeError,invalid json arguments")

    def on_finish(self):
        if self.session:
            self.session.close()
        self.arguments = {}
