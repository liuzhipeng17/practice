from common.authentication import validate_requests, validate_user_permission
from common.error import CMDBError
from db import sqlalchemy_util
from db.mysql import session_scope
from db.tables import Tables
from handler.base import BaseHandler


class IPHandler(BaseHandler):
    @validate_requests
    @validate_user_permission('get')
    def get(self, *args, **kwargs):
        arguments = self.arguments
        arguments = arguments if arguments else {}
        page = int(self.get_argument("page", 1))
        page_size = int(self.get_argument("page_size", 15))
        ip_res, total_count = sqlalchemy_util.find(self.session, Tables.ip, page, page_size, **arguments)

        real_res = [_.to_dict() for _ in ip_res]

        self.render_json_response(code=200, msg="OK", total_count=total_count, res=real_res)

    @validate_requests
    @validate_user_permission('put')
    def put(self, *args, **kwargs):
        '''
        update
        :param args:
        :param kwargs:
        :return:
        '''
        arguments = self.arguments
        if not arguments:
            raise CMDBError(status_code=400, reason="json arguments is invalid")
        _id = arguments.pop("id")
        if not _id:
            raise CMDBError(status_code=400, reason="ID is required")
        q = sqlalchemy_util.find(self.session, Tables.ip, one=True, **arguments)
        if q:
            raise CMDBError(status_code=400, reason="record has existed")

        with session_scope(self.session) as session:

            # update ip info
            session.query(Tables.ip).filter_by(id=_id).update(arguments, synchronize_session=False)

            res = session.query(Tables.ip).filter(Tables.ip.id == _id).first().to_dict()

        self.render_json_response(code=200, msg="OK", id=_id, res=res)

    @validate_requests
    @validate_user_permission('post')
    def post(self):
        '''
        add
        :return:
        '''
        arguments = self.arguments
        arguments.pop('id')

        with session_scope(self.session) as session:
            ip_instance = Tables.ip(**arguments)
            session.add(ip_instance)

        res = self.session.query(Tables.ip).filter(Tables.ip.id == ip_instance.id).first().to_dict()
        self.render_json_response(code=200, msg="OK", id=ip_instance.id, res=res)

    @validate_requests
    @validate_user_permission('delete')
    def delete(self):
        _id = self.arguments['id']
        filters = {"id": _id}
        sqlalchemy_util.delete(self.session, Tables.ip, **filters)
        self.render_json_response(code=200, msg="OK")
