from common.authentication import validate_requests, validate_user_permission
from common.error import CMDBError
from db import sqlalchemy_util
from db.mysql import session_scope
from db.tables import Tables
from handler.base import BaseHandler


class EnvHandler(BaseHandler):
    @validate_requests
    @validate_user_permission('get')
    def get(self):
        '''
        env 查找，支持id，name
        组合查询(and)
        :return:  env list ,limit(1,15)   if no page arguments
        '''
        page = int(self.get_argument("page", 1))
        page_size = int(self.get_argument("page_size", 15))

        '''env '''
        _id = int(self.get_argument("id", -1))
        name = self.get_argument("name", None)

        ''''filter by env attribute'''
        env_filter = {}
        if _id > -1:
            env_filter.update({"id": _id})
        if name:
            env_filter.update({"name": name})

        h_id = sqlalchemy_util.find(self.session, Tables.env, return_query=True, **env_filter)

        total_count = h_id.count()

        '''limit return result'''
        offset = (page - 1) * page_size
        res = [_.to_dict() for _ in h_id.offset(offset).limit(page_size)]

        self.render_json_response(code=200, msg="OK", res=res, total_count=total_count)

    @validate_requests
    @validate_user_permission('post')
    def post(self):

        '''post  arguments'''

        arguments = self.arguments
        arguments.pop('id')
        if not arguments:
            raise CMDBError(status_code=400, reason="json arguments is invalid")

        name = arguments.get('name', None)
        if not name:
            raise CMDBError(status_code=400, reason="name is required")
        q = sqlalchemy_util.find(self.session, Tables.env, one=True, **arguments)
        if q:
            raise CMDBError(status_code=400, reason="name has existed")

        with session_scope(self.session) as session:
            env_instance = Tables.env(**arguments)
            session.add(env_instance)
        res = self.session.query(Tables.env).filter(
            Tables.env.id == env_instance.id).first().to_dict()
        self.render_json_response(code=200, msg="OK", id=env_instance.id, res=res)

    @validate_requests
    @validate_user_permission('put')
    def put(self):
        """
        update env name
        """

        arguments = self.arguments

        if not arguments:
            raise CMDBError(status_code=400, reason="json arguments is invalid")

        _id = arguments.pop("id", None)
        if not _id:
            raise CMDBError(status_code=400, reason="id is required")
        q = sqlalchemy_util.find(self.session, Tables.env, one=True, **{'id': _id})
        if not q:
            raise CMDBError(status_code=404, reason="id not found")

        name = arguments.get('name', None)
        if not name:
            raise CMDBError(status_code=400, reason="name is required")

        with session_scope(self.session) as session:

            # update env info
            session.query(Tables.env).filter_by(id=_id).update(arguments, synchronize_session=False)

            res = session.query(Tables.env).filter(Tables.env.id == _id).first().to_dict()

        self.render_json_response(code=200, msg="OK", id=_id, res=res)
