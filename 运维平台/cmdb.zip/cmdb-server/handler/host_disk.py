from common.authentication import validate_requests, validate_user_permission
from common.error import CMDBError
from db import sqlalchemy_util
from db.mysql import session_scope
from db.tables import Tables
from handler.base import BaseHandler


class HostDiskHandler(BaseHandler):
    @validate_requests
    @validate_user_permission('get')
    def get(self, *argus):
        argus = self.arguments
        argus = argus if argus else {}
        page = int(self.get_argument("page", 1))
        page_size = int(self.get_argument("page_size", 15))

        disk_res, total_count = sqlalchemy_util.find(self.session, Tables.host_disk, page, page_size,
                                                     **argus)

        real_res = [_.to_dict() for _ in disk_res]

        self.render_json_response(code=200, msg="OK", total_count=total_count, res=real_res)

    @validate_requests
    @validate_user_permission('post')
    def post(self, *args):
        """
        add host_disk  object
        argument should be list
        :return:
        """
        arguments = self.arguments
        if not arguments:
            raise CMDBError(status_code=400, reason="json arguments is invalid")
        q = sqlalchemy_util.find(self.session, Tables.host_disk, one=True, **arguments)
        if q:
            raise CMDBError(status_code=400, reason="record has existed")
        with session_scope(self.session) as session:
            host_disk = Tables.host_disk(**arguments)
            session.add(host_disk)

        res = self.session.query(Tables.host_disk).filter(Tables.host_disk.id == host_disk.id).first().to_dict()

        self.render_json_response(code=200, msg="OK", id=host_disk.id, res=res)

    @validate_requests
    @validate_user_permission('put')
    def put(self, *argus):
        """update host_disk"""

        arguments = self.arguments
        if "id" not in arguments.keys():
            raise CMDBError(status_code=400, reason="ID is required")
        _id = arguments.pop("id")
        filters = {"id": _id}
        row = sqlalchemy_util.update(self.session, Tables.host_disk, filters, arguments)

        res = self.session.query(Tables.host_disk).filter(Tables.host_disk.id == _id).first().to_dict()
        self.render_json_response(code=200, msg="OK", effect_row=row, res=res)

    @validate_requests
    @validate_user_permission('delete')
    def delete(self):
        """ delete disk by id"""

        arguments = self.arguments
        if not arguments:
            raise CMDBError(status_code=400, reason="json arguments is invalid")

        _id = arguments.get("id", None)
        if not _id:
            raise CMDBError(status_code=400, reason="id is required")

        filters = {"id": _id}
        sqlalchemy_util.delete(self.session, Tables.host_disk, **filters)
        self.render_json_response(code=200, msg="OK")
