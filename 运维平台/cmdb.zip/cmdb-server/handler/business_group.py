from common.authentication import validate_requests, validate_user_permission
from common.error import CMDBError
from db import sqlalchemy_util
from db.mysql import session_scope
from db.tables import Tables
from handler.base import BaseHandler


class BusinessGroupHandler(BaseHandler):
    @validate_requests
    @validate_user_permission('get')
    def get(self):
        '''
        business_group 查找，支持id，name
        组合查询(and)
        :return:  business_group list ,limit(1,15)   if no page arguments
        '''
        page = int(self.get_argument("page", 1))
        page_size = int(self.get_argument("page_size", 15))

        '''business_group '''
        _id = int(self.get_argument("id", -1))
        name = self.get_argument("name", None)

        ''''filter by business_group attribute'''
        business_group_filter = {}
        if _id > -1:
            business_group_filter.update({"id": _id})
        if name:
            business_group_filter.update({"name": name})
        if business_group_filter:
            h_id = sqlalchemy_util.find(self.session, Tables.business_group.id, return_query=True,
                                        **business_group_filter)
        else:
            h_id = self.session.query(Tables.business_group.id)

        total_count = h_id.count()

        '''limit return result'''
        offset = (page - 1) * page_size
        ids = [_id[0] for _id in h_id.offset(offset).limit(page_size)]

        res = [_.to_dict() for _ in
               self.session.query(Tables.business_group).filter(Tables.business_group.id.in_(ids)).all()]
        self.render_json_response(code=200, msg='OK', res=res, total_count=total_count)

    @validate_requests
    @validate_user_permission('post')
    def post(self, *argus):

        '''post  arguments'''

        argus = self.arguments

        if not argus:
            raise CMDBError(status_code=400, reason="json arguments is invalid")

        name = argus.get('name', None)
        if not name:
            raise CMDBError(status_code=400, reason="name is required")

        q = sqlalchemy_util.find(self.session, Tables.business_group, one=True, **argus)
        if q:
            raise CMDBError(status_code=400, reason="name has existed")

        with session_scope(self.session) as session:
            business_group = Tables.business_group(**argus)
            session.add(business_group)

        res = self.session.query(Tables.business_group).filter(
            Tables.business_group.id == business_group.id).first().to_dict()
        self.render_json_response(code=200, msg="OK", id=business_group.id, res=res)

    @validate_requests
    @validate_user_permission('put')
    def put(self):
        """
        update business_group name
        """

        argus = self.arguments

        if not argus:
            raise CMDBError(status_code=400, reason="json arguments is invalid")

        _id = argus.get("id", None)
        if not _id:
            raise CMDBError(status_code=400, reason="id is required")
        q = sqlalchemy_util.find(self.session, Tables.business_group, one=True, **{'id': _id})
        if not q:
            raise CMDBError(status_code=404, reason="id not found")

        row = sqlalchemy_util.update(self.session, Tables.business_group, filters={'id': _id}, up_argus=argus,
                                     flag=True)
        res = self.session.query(Tables.business_group).filter(Tables.business_group.id == _id).first().to_dict()
        self.render_json_response(code=200, msg="OK", effect_row=row, res=res)
