from common.authentication import validate_requests, validate_user_permission
from common.error import CMDBError
from db import sqlalchemy_util
from db.mysql import session_scope
from db.tables import Tables
from handler.base import BaseHandler


class UlbHandler(BaseHandler):
    @validate_requests
    @validate_user_permission('get')
    def get(self, *argus):
        argus = self.arguments
        argus = argus if argus else {}
        page = int(self.get_argument("page", 1))
        page_size = int(self.get_argument("page_size", 15))

        res, total_count = sqlalchemy_util.find(self.session, Tables.ulb, page, page_size,
                                                **argus)

        real_res = [_.to_dict() for _ in res]
        self.render_json_response(code=200, msg="OK", total_count=total_count, res=real_res)

    @validate_requests
    @validate_user_permission('post')
    def post(self, *args):
        """
        add ulb  object
        argument should be list
        :return:
        """
        arguments = self.arguments
        if not arguments:
            raise CMDBError(status_code=400, reason="json arguments is invalid")
        q = sqlalchemy_util.find(self.session, Tables.ulb, one=True, **arguments)
        if q:
            raise CMDBError(status_code=400, reason="record has existed")

        with session_scope(self.session) as session:
            ulb = Tables.ulb(**arguments)
            session.add(ulb)
        res = self.session.query(Tables.ulb).filter(Tables.ulb.id == ulb.id).first().to_dict()
        self.render_json_response(code=200, msg="OK", id=ulb.id, res=res)

    @validate_requests
    @validate_user_permission('put')
    def put(self):
        """update ulb"""

        arguments = self.arguments
        if not arguments:
            raise CMDBError(status_code=400, reason="json arguments is invalid")

        _id = arguments.get("id", None)
        if not _id:
            raise CMDBError(status_code=400, reason="id is required")
        q = sqlalchemy_util.find(self.session, Tables.ulb, one=True, **{'id': _id})
        if not q:
            raise CMDBError(status_code=404, reason="id not found")

        filters = {"id": _id}
        row = sqlalchemy_util.update(self.session, Tables.ulb, filters, arguments)
        res = self.session.query(Tables.ulb).filter(Tables.ulb.id == _id).first().to_dict()
        self.render_json_response(code=200, msg="OK", effect_row=row, res=res)

    @validate_requests
    @validate_user_permission('delete')
    def delete(self):
        """ delete ulb by id"""

        arguments = self.arguments

        if not arguments:
            raise CMDBError(status_code=400, reason="json arguments is invalid")

        _id = arguments.get("id", None)
        if not _id:
            raise CMDBError(status_code=400, reason="id is required")

        filters = {"id": _id}
        sqlalchemy_util.delete(self.session, Tables.ulb, filters)
        self.render_json_response(code=200, msg="OK")
