from common.authentication import validate_requests, validate_user_permission
from common.error import CMDBError
from db import sqlalchemy_util
from db.mysql import session_scope
from db.tables import Tables
from handler.base import BaseHandler


class DepartmentHandler(BaseHandler):
    @validate_requests
    @validate_user_permission('get')
    def get(self):
        '''
        department 查找，支持id，name
        组合查询(and)
        :return:  department list ,limit(1,15)   if no page arguments
        '''
        page = int(self.get_argument("page", 1))
        page_size = int(self.get_argument("page_size", 15))

        '''department '''
        _id = int(self.get_argument("id", -1))
        name = self.get_argument("name", None)

        ''''filter by department attribute'''
        department_filter = {}
        if _id > -1:
            department_filter.update({"id": _id})
        if name:
            department_filter.update({"name": name})
        if department_filter:
            h_id = sqlalchemy_util.find(self.session, Tables.department.id, return_query=True, **department_filter)
        else:
            h_id = self.session.query(Tables.department.id)

        total_count = h_id.count()

        '''limit return result'''
        offset = (page - 1) * page_size
        ids = [_id[0] for _id in h_id.offset(offset).limit(page_size)]

        res = [_.to_dict() for _ in
               self.session.query(Tables.department).filter(Tables.department.id.in_(ids)).all()]
        self.render_json_response(code=200, msg='OK', res=res, total_count=total_count)

    @validate_requests
    @validate_user_permission('post')
    def post(self):

        '''post  arguments'''

        arguments = self.arguments

        if not arguments:
            raise CMDBError(status_code=400, reason="json arguments is invalid")

        name = arguments.get('name', None)
        if not name:
            raise CMDBError(status_code=400, reason="name is required")

        q = sqlalchemy_util.find(self.session, Tables.department, one=True, **arguments)
        if q:
            raise CMDBError(status_code=400, reason="name has existed")
        with session_scope(self.session) as session:
            department_instance = Tables.application_database(**arguments)

            session.add(department_instance)

            session.flush()
            _id = department_instance.id

        res = self.session.query(Tables.department).filter(Tables.department.id == _id).first().to_dict()
        self.render_json_response(code=200, msg="OK", id=_id, res=res)

    @validate_requests
    @validate_user_permission('put')
    def put(self):
        """
        update department name
        """

        argus = self.arguments

        if not argus:
            raise CMDBError(status_code=400, reason="json arguments is invalid")

        _id = argus.get("id", None)
        if not _id:
            raise CMDBError(status_code=400, reason="id is required")
        q = sqlalchemy_util.find(self.session, Tables.department, one=True, **{'id': _id})
        if not q:
            raise CMDBError(status_code=404, reason="id not found")

        sqlalchemy_util.update(self.session, Tables.department, filters={'id': _id}, up_argus=argus, flag=True)
        res = self.session.query(Tables.department).filter(Tables.department.id == _id).first().to_dict()
        self.render_json_response(code=200, msg="OK", id=_id, res=res)
