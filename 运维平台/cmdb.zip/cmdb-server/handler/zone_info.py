from common.authentication import validate_requests, validate_user_permission
from common.error import CMDBError
from db import sqlalchemy_util
from db.mysql import session_scope
from db.tables import Tables
from handler.base import BaseHandler


class ZoneInfoHandler(BaseHandler):
    @validate_requests
    @validate_user_permission('get')
    def get(self):
        '''
        zone_info 查找，支持id，name
        组合查询(and)
        :return:  zone_info list ,limit(1,15)   if no page arguments
        '''
        page = int(self.get_argument("page", 1))
        page_size = int(self.get_argument("page_size", 15))

        '''zone_info '''
        _id = int(self.get_argument("id", -1))
        name = self.get_argument("name", None)

        ''''filter by zone_info attribute'''
        zone_info_filter = {}
        if _id > -1:
            zone_info_filter.update({"id": _id})
        if name:
            zone_info_filter.update({"name": name})
        h_id = sqlalchemy_util.find(self.session, Tables.zone_info.id, return_query=True, **zone_info_filter)

        total_count = h_id.count()

        '''limit return result'''
        offset = (page - 1) * page_size
        res = [_.to_dict() for _ in h_id.offset(offset).limit(page_size)]

        self.render_json_response(code=200, msg="OK", res=res, total_count=total_count)

    @validate_requests
    @validate_user_permission('post')
    def post(self, *argus):

        '''post  arguments'''

        arguments = self.arguments
        arguments.pop('id')
        if not arguments:
            raise CMDBError(status_code=400, reason="json arguments is invalid")
        q = sqlalchemy_util.find(self.session, Tables.zone_info, one=True, **arguments)
        if q:
            raise CMDBError(status_code=400, reason="record has existed")

        if not arguments:
            raise CMDBError(status_code=400, reason="json arguments is invalid")

        name = arguments.get('name', None)
        if not name:
            raise CMDBError(status_code=400, reason="name is required")

        q = sqlalchemy_util.find(self.session, Tables.zone_info, one=True, **arguments)
        if q:
            raise CMDBError(status_code=400, reason="name has existed")

        with session_scope(self.session) as session:
            zone_info_instance = Tables.zone_info(**arguments)
            session.add(zone_info_instance)
        res = self.session.query(Tables.zone_info).filter(
            Tables.zone_info.id == zone_info_instance.id).first().to_dict()
        self.render_json_response(code=200, msg="OK", id=zone_info_instance.id, res=res)

    @validate_requests
    @validate_user_permission('put')
    def put(self):
        """
        update zone_info name
        """

        arguments = self.arguments

        if not arguments:
            raise CMDBError(status_code=400, reason="json arguments is invalid")

        _id = arguments.pop("id", None)
        if not _id:
            raise CMDBError(status_code=400, reason="id is required")
        q = sqlalchemy_util.find(self.session, Tables.zone_info, one=True, **{'id': _id})
        if not q:
            raise CMDBError(status_code=404, reason="id not found")

        with session_scope(self.session) as session:

            # update zone_info info
            session.query(Tables.zone_info).filter_by(id=_id).update(arguments, synchronize_session=False)

            res = session.query(Tables.zone_info).filter(Tables.zone_info.id == _id).first().to_dict()

        self.render_json_response(code=200, msg="OK", id=_id, res=res)
