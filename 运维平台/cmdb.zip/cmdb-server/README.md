## 简介

* cmdb后台
* 提供RestfulAPI
* 接受http请求，返回json,
* 请求参数类型（Content-Type）支持:
   1. application/x-www-form-urlencoded （接口说明时）
   2. application/json (默认)

* 部署运行时，需按数据库设计文档（sql）把数据库表建立起来，代码内采用auotomap  直接映射，无需建model
* 程序入口是 cmdb_server.py ,采用命令 python cmdb_server.py --port=[指定的port],如 python cmdb_server.py --port=8010 & ,把程序跑起来
* 在conf.d/settings.yml 中指定了需要用到的文件目录，部署运行时需建立相应的文件夹或者修改配置文件

## wiki

* [接口文档](http://wiki.corp.yunnex.com/pages/viewpage.action?pageId=15761979)
* [网络架构](http://wiki.corp.yunnex.com/pages/viewpage.action?pageId=15761910)
* [编程规范](http://wiki.corp.yunnex.com/pages/viewpage.action?pageId=15761846)



