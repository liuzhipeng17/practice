from handler.test_handler import HelloWorldHandler
from handler.host import HostHandler
from handler.host_disk import HostDiskHandler
from handler.env import EnvHandler
from handler.host_type import HostTypeHandler
from handler.zone_info import ZoneInfoHandler
from handler.department import DepartmentHandler
from handler.business_group import BusinessGroupHandler
from handler.application import ApplicationHandler
from handler.host_application import HostApplicationHandler
from handler.backend_group import BackendGroupHandler
from handler.location import LocationHandler
from handler.host_network_interface import HostNetWorkInterface
from handler.ip import IPHandler
from handler.user import UserHandler
from handler.token import TokenHandler
from handler.domain import DomainHandler
from handler.dns_record import DnsRecordHandler
from handler.ulb import UlbHandler
from handler.ulb_upstream import UlbUpstreamHandler
from handler.ulb_upstream_domain import UlbUpstreamDomainHandler
from handler.user_deparment import UserDepartmentHandler
from handler.database import DatabaseHandler
from handler.database_database_name import Database_DatabaseNameHandler
from handler.database_name import DatabaseNameHandler
from handler.application_database import ApplicationDatabaseHandler
from handler.database_type import DatabaseTypeHandler
ROUTES = [
    (r'/api/test/?$', HelloWorldHandler),
    (r'/api/host_application/?', HostApplicationHandler),
    (r'/api/host_type$', HostTypeHandler),
    (r'/api/host_disk/?', HostDiskHandler),
    (r'/api/host_network_interface/?', HostNetWorkInterface),
    (r'/api/ip$', IPHandler),
    (r'/api/host/?', HostHandler),
    (r'/api/zone_info$', ZoneInfoHandler),
    (r'/api/env$', EnvHandler),
    (r'/api/department/?', DepartmentHandler),
    (r'/api/business_group', BusinessGroupHandler),
    (r'/api/application_database', ApplicationDatabaseHandler),
    (r'/api/application', ApplicationHandler),
    (r'/api/backend_group/?', BackendGroupHandler),
    (r'/api/location/?', LocationHandler),
    (r'/api/domain/?', DomainHandler),
    (r'/api/dns_record/?', DnsRecordHandler),
    (r'/api/ulb_upstream_domain/?', UlbUpstreamDomainHandler),
    (r'/api/ulb_upstream/?', UlbUpstreamHandler),
    (r'/api/ulb/?', UlbHandler),
    (r'/api/user_department/?', UserDepartmentHandler),
    (r'/api/database_database_name/?', Database_DatabaseNameHandler),
    (r'/api/database_type/?', DatabaseTypeHandler),
    (r'/api/database_name/?', DatabaseNameHandler),
    (r'/api/database/?', DatabaseHandler),
    (r'/api/user/?', UserHandler),
    (r'/api/token/?', TokenHandler),
    (r'/api/$', HelloWorldHandler),

]
