export default {
  logout: () => 'success'
}
