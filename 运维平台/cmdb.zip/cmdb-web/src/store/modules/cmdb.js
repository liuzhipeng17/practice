import {
  getBusinessGroupList,
  getApplicationList,
  getDepartmentList,
  getUserList
} from '@/api/api'

const cmdb = {
  namespaced: true,
  state: {
    business_group_list: [],
    department_list: [],
    application_list: [],
    department_user_list: []
  },

  mutations: {
    RECEIVE_BUSINESS_GROUP: (state, business_group_list) => {
      state.business_group_list = business_group_list
    },
    RECEIVE_DEPARTMENT: (state, department_list) => {
      state.department_list = department_list
    },
    RECEIVE_APPLICATION: (state, application_list) => {
      state.application_list = application_list
    },
    RECEIVE_DEPARTMENT_USER: (state, user_list) => {
      state.department_user_list = user_list
    }
  },

  actions: {
    // 获取所有的应用
    loadApplicationNameAll: function({ commit }) {
      const param = {
        page: 1,
        page_size: 100000
      }
      getApplicationList(param).then(results => {
        commit('RECEIVE_APPLICATION', results.data.res)
      })
    },
    // 获取所有的业务组信息
    loadBusinessGroupAll: function({ commit }) {
      const param = {
        page: 1,
        page_size: 100000
      }
      getBusinessGroupList(param).then(results => {
        commit('RECEIVE_BUSINESS_GROUP', results.data.res)
      })
    },
    // 获取所有的部门信息
    loadDepartmentNameAll: function({ commit }) {
      const param = {
        page: 1,
        page_size: 100000
      }
      getDepartmentList(param).then(results => {
        commit('RECEIVE_DEPARTMENT', results.data.res)
      })
    },
    // 获取部门的人员信息
    loadDepartmentUserAll: function({ commit }, query) {
      const param = {
        page: 1,
        page_size: 100000
      }
      getUserList(Object.assign(param, query)).then(results => {
        commit('RECEIVE_DEPARTMENT_USER', results.data.res)
      })
    }
  }
}

export default cmdb
