import { logout } from '@/api/login'
import { requestToken } from '@/api/api'
import { getToken, setToken, removeToken } from '@/utils/auth'

function parseToken(token) {
  return new Promise((resolve, reject) => {
    try {
      var base64Url = token.split('.')[1]
      var base64 = base64Url.replace('-', '+').replace('_', '/')
      const payload = JSON.parse(window.atob(base64))
      payload.roles = ['admin']
      payload.avatar =
        'https://wpimg.wallstcn.com/f778738c-e4f8-4870-b634-56703b4acafe.gif'
      console.log(payload)
      resolve(payload)
    } catch (e) {
      console.log(e)
      reject(e)
    }
  })
}

const user = {
  state: {
    user: '',
    status: '',
    code: '',
    token: getToken(),
    payload: {},
    name: '',
    avatar: '',
    introduction: '',
    is_admin: false,
    roles: [],
    setting: {
      articlePlatform: []
    }
  },

  mutations: {
    SET_CODE: (state, code) => {
      state.code = code
    },
    SET_TOKEN: (state, token) => {
      state.token = token
    },
    SET_INTRODUCTION: (state, introduction) => {
      state.introduction = introduction
    },
    SET_SETTING: (state, setting) => {
      state.setting = setting
    },
    SET_STATUS: (state, status) => {
      state.status = status
    },
    SET_NAME: (state, name) => {
      state.name = name
    },
    SET_AVATAR: (state, avatar) => {
      state.avatar = avatar
    },
    SET_ROLES: (state, roles) => {
      state.roles = roles
    },
    SET_PAYLOAD: (state, payload) => {
      state.payload = payload
      state.is_admin = payload.roles.indexOf('admin') >= 0
    }
  },

  actions: {
    // 用户名登录
    LoginByUsername({ commit }, userInfo) {
      const username = userInfo.username.trim()
      return new Promise((resolve, reject) => {
        const param = {
          username: username,
          password: userInfo.password
        }
        requestToken(param)
          .then(response => {
            const data = response.data.res
            setToken(data.token)
            commit('SET_TOKEN', data.token)
            resolve(parseToken(data.token))
          })
          .catch(error => {
            reject(error)
          })
      })
    },

    // 获取用户信息
    GetUserInfo({ commit, state }, token) {
      return new Promise((resolve, reject) => {
        parseToken(token)
          .then(payload => {
            commit('SET_PAYLOAD', payload)
            commit('SET_NAME', payload.username)
            commit('SET_ROLES', payload.roles)
            commit('SET_AVATAR', payload.avatar)
            commit('SET_INTRODUCTION', payload.introduction)
            resolve(payload)
          })
          .catch(error => {
            reject(error)
          })
      })
    },

    // 第三方验证登录
    // LoginByThirdparty({ commit, state }, code) {
    //   return new Promise((resolve, reject) => {
    //     commit('SET_CODE', code)
    //     loginByThirdparty(state.status, state.email, state.code).then(response => {
    //       commit('SET_TOKEN', response.data.token)
    //       setToken(response.data.token)
    //       resolve()
    //     }).catch(error => {
    //       reject(error)
    //     })
    //   })
    // },

    // 登出
    LogOut({ commit, state }) {
      return new Promise((resolve, reject) => {
        logout(state.token)
          .then(() => {
            commit('SET_TOKEN', '')
            commit('SET_ROLES', [])
            removeToken()
            resolve()
          })
          .catch(error => {
            reject(error)
          })
      })
    },

    // 前端 登出
    FedLogOut({ commit }) {
      return new Promise(resolve => {
        commit('SET_TOKEN', '')
        removeToken()
        resolve()
      })
    },

    // 动态修改权限
    ChangeRole({ commit }, role) {
      return new Promise(resolve => {
        commit('SET_TOKEN', role)
        setToken(role)
        parseToken(role).then(response => {
          const data = response.data
          commit('SET_ROLES', data.role)
          commit('SET_NAME', data.name)
          commit('SET_AVATAR', data.avatar)
          commit('SET_INTRODUCTION', data.introduction)
          resolve()
        })
      })
    }
  }
}

export default user
