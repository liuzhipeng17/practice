import { getHostList } from '@/api/api'

const application = {
  state: {
    application: '',
    name: '',
    business_group: '',
    department: '',
    host_list: []
  },

  mutations: {
    RECEIVE_HOST: (state, host_list) => {
      state.host_list = host_list
    },

    SET_APPLICATION: (state, application) => {
      state.application = application
      state.name = application.name
      state.business_group = application.business_group
    }
  },

  actions: {
    // 获取主机列表
    getHostsByApplicationName({ commit }, application_name) {
      const para = {
        page: 1,
        page_size: 10000,
        application_name: application_name
      }
      getHostList(para).then(res => {
        for (var i = 0; i < res.data.res.length; i++) {
          var row = res.data.res[i]
          if (row.network_interface[0]) {
            var ip = row.network_interface[0].ip[0] // IP 只取第一个
            var ip_addr = ip.ip_addr
            res.data.res[i].ip = ip_addr
          }
        }
        commit('RECEIVE_HOST', res.data.res)
      })
    }
  }
}

export default application
