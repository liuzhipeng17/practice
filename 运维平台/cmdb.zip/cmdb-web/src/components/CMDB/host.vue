<template>
  <div>
    <el-row>
      <el-col :span="12">
        <div class="grid-content bg-purple">名称</div>
      </el-col>
      <el-col :span="12">
        <div class="grid-content bg-purple-light">{{hostDetail.hostname}}</div>
      </el-col>
    </el-row>
    <el-row>
      <el-col :span="12">
        <div class="grid-content bg-purple">网卡</div>
      </el-col>
      <el-col :span="12">
        <div class="grid-content bg-purple-light">{{hostDetail.ne}}</div>
      </el-col>
    </el-row>
    <el-row>
      <el-col :span="12">
        <div class="grid-content bg-purple">名称</div>
      </el-col>
      <el-col :span="12">
        <div class="grid-content bg-purple-light">{{hostDetail.hostname}}</div>
      </el-col>
    </el-row>
    <el-row>
      <el-col :span="12">
        <div class="grid-content bg-purple">名称</div>
      </el-col>
      <el-col :span="12">
        <div class="grid-content bg-purple-light">{{hostDetail.hostname}}</div>
      </el-col>
    </el-row>
    <el-row>
      <el-col :span="12">
        <div class="grid-content bg-purple">名称</div>
      </el-col>
      <el-col :span="12">
        <div class="grid-content bg-purple-light">{{hostDetail.hostname}}</div>
      </el-col>
    </el-row>
  </div>
</template>
<script>
export default {
  name: 'HostDetail',
  props: ['hostDetail']
}
</script>
<style scoped>

</style>
