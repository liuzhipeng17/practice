<template>
  <section>
    <el-row>
      <el-button type="primary" icon="el-icon-plus">增加</el-button>
    </el-row>
    <el-table :data="host_list" border style="width: 100%">
      <el-table-column prop="ip" label="IP" min-width="180">
      </el-table-column>
      <el-table-column prop="hostname" label="主机名称" min-width="200">
      </el-table-column>
      <el-table-column prop="status" label="状态">
      </el-table-column>
      <el-table-column label="操作">
        <template slot-scope="scope">
          <el-button size="small" type="danger">移除</el-button>
        </template>
      </el-table-column>
    </el-table>
  </section>
</template>

<script>
export default {
  name: 'ApplicationDetail',
  props: ['applicationDetail'],
  computed: {
    host_list() {
      return this.$store.state.application.host_list
    }
  }
}
</script>

<style scoped>

</style>