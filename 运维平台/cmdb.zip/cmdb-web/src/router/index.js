import Vue from 'vue'
import Router from 'vue-router'
const _import = require('./_import_' + process.env.NODE_ENV)
// in development env not use Lazy Loading,because Lazy Loading too many pages will cause webpack hot update too slow.so only in production use Lazy Loading

Vue.use(Router)

/* layout */
import Layout from '@/views/layout/Layout'

/**
* icon : the icon show in the sidebar
* hidden : if `hidden:true` will not show in the sidebar
* redirect : if `redirect:noredirect` will no redirct in the levelbar
* noDropdown : if `noDropdown:true` will has no submenu
* meta : { role: ['admin'] }  will control the page role
**/
export const constantRouterMap = [
  { path: '/login', component: _import('login/index'), hidden: true },
  {
    path: '/authredirect',
    component: _import('login/authredirect'),
    hidden: true
  },
  { path: '/404', component: _import('errorPage/404'), hidden: true },
  { path: '/401', component: _import('errorPage/401'), hidden: true },
  {
    path: '/',
    component: Layout,
    redirect: '/resource/host',
    name: '首页',
    hidden: true
  },
  {
    path: '/resource',
    component: Layout,
    redirect: '/resource/host',
    name: '资源',
    icon: 'people',
    children: [
      { path: 'host', component: _import('resource/host'), name: '主机' },
      {
        path: 'application',
        component: _import('resource/application'),
        name: '应用'
      },
      {
        path: 'database',
        component: _import('resource/database'),
        name: '数据库'
      },
      {
        path: 'department',
        component: _import('resource/department'),
        name: '部门'
      },
      {
        path: 'business_group',
        component: _import('resource/business_group'),
        name: '业务组'
      }
    ]
  }
]

export default new Router({
  // mode: 'history', //后端支持可开
  scrollBehavior: () => ({ y: 0 }),
  routes: constantRouterMap
})

export const asyncRouterMap = [
  { path: '*', redirect: '/404', hidden: true }
]
