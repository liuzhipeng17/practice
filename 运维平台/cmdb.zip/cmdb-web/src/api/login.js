import fetch from '@/utils/fetch'

export function logout() {
  return fetch({
    url: '/login/logout',
    method: 'post'
  })
}
