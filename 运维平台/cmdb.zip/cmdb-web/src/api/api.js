import axios from 'axios'

import { MessageBox } from 'element-ui'
import store from '@/store'
import { getToken } from '@/utils/auth'

// const base = 'http://10.10.50.30/api' // 测试服务器
const base = 'http://localhost:8000/api' // 本机
// const base = 'http://cmdb.ops.yunnex.com/api' // 正式服务器

const HTTP = axios.create({
  baseURL: base
})

// Add a request interceptor
HTTP.interceptors.request.use(
  function(config) {
    // Do something before request is sent
    config.headers['token'] = getToken()
    return config
  },
  function(error) {
    // Do something with request error
    console.log(error)
    return Promise.reject(error)
  }
)

// Add a response interceptor
HTTP.interceptors.response.use(
  function(response) {
    // Do something with response data
    console.log(response)
    return response
  },
  function(error) {
    // Do something with response error
    console.log(error)
    if (error.response.status === 401) {
      MessageBox.alert(error.response.data.reason, 'token失效', {
        confirmButtonText: '重新登录',
        type: 'error',
        center: true
      }).then(() => {
        store.dispatch('FedLogOut').then(() => {
          location.reload() // 为了重新实例化vue-router对象 避免bug
        })
      })
    }
    return Promise.reject(error)
  }
)
export const requestToken = data => {
  return HTTP.post('/token', data)
}
export const getHostList = params => {
  return HTTP.get('/host', { params: params })
}

export const getBusinessGroupList = params => {
  return HTTP.get('/business_group', { params: params })
}

export const getDepartmentList = params => {
  return HTTP.get('/department', { params: params })
}

export const getApplicationList = params => {
  return HTTP.get('/application', { params: params })
}

export const addApplication = data => {
  return HTTP.post('/application', data)
}

export const editApplication = data => {
  return HTTP.put('/application', data)
}

export const getDatabaseList = params => {
  return HTTP.get('/database', { params: params })
}

export const addDatabase = data => {
  return HTTP.post('/database', data)
}

export const editDatabase = data => {
  return HTTP.put('/database', data)
}

export const addHost = data => {
  return HTTP.post('/host', data)
}

export const editHost = data => {
  return HTTP.put('/host', data)
}

export const getUserList = params => {
  return HTTP.get('/user', { params: params })
}
