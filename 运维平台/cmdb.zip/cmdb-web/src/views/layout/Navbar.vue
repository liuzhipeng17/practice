<template>
  <el-row type="flex" class="navbar" justify="space-between">
    <el-col>
      <hamburger class="hamburger-container" :toggleClick="toggleSideBar" :isActive="sidebar.opened"></hamburger>
      <levelbar></levelbar>
      <tabs-view></tabs-view>
    </el-col>
    <el-col>
      <el-row class="right-control" type="flex" justify="end">
        <el-tooltip effect="dark" content="刷新缓存" placement="top-start">
          <el-button class='control-item refresh-button' type="primary" size="small" @click="refreshCache" icon="el-icon-refresh"></el-button>
        </el-tooltip>
        <el-tooltip effect="dark" content="全屏" placement="top-start">
          <screenfull class='control-item'></screenfull>
        </el-tooltip>
        <img class=" control-item user-avatar" :src="avatar+'?imageView2/1/w/80/h/80'">
        <el-dropdown trigger="click">
          <span class="el-dropdown-link control-item control-text">{{name}}
            <i class="el-icon-arrow-down el-icon--right"></i>
          </span>
          <el-dropdown-menu slot="dropdown">
            <el-dropdown-item>
              <span @click="logout" style="display:block;">退出登录</span>
            </el-dropdown-item>
          </el-dropdown-menu>
        </el-dropdown>
        </span>
        <a class="control-item  control-text el-icon-document" target='_blank' href="http://cmdb.ops.yunnex.com/api/docs/cmdb-api-doc/">
          文档
        </a>
      </el-row>
    </el-col>
  </el-row>
</template>

<script>
import { mapGetters } from 'vuex'
import Levelbar from './Levelbar'
import TabsView from './TabsView'
import Hamburger from 'components/Hamburger'
import Screenfull from 'components/Screenfull'

export default {
  components: {
    Levelbar,
    TabsView,
    Hamburger,
    Screenfull
  },
  computed: {
    ...mapGetters(['sidebar', 'name', 'avatar'])
  },
  methods: {
    toggleSideBar() {
      this.$store.dispatch('ToggleSideBar')
    },
    logout() {
      this.$store.dispatch('LogOut').then(() => {
        location.reload() // 为了重新实例化vue-router对象 避免bug
      })
    },
    refreshCache() {
      this.$store.dispatch('cmdb/loadDepartmentNameAll')
      this.$store.dispatch('cmdb/loadBusinessGroupAll')
      this.$store.dispatch('cmdb/loadApplicationNameAll')
    }
  }
}
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
.navbar {
  height: 50px;
  line-height: 50px;
  border-radius: 0px !important;
  .hamburger-container {
    line-height: 58px;
    height: 50px;
    float: left;
    padding: 0 10px;
  }
  .right-control {
    padding: 5px 20px;
    .control-item {
      margin: 0 10px;
      height: 40px;
    }
    .control-text {
      line-height: 40px;
    }
    .user-avatar {
      width: 40px;
      height: 40px;
      border-radius: 10px;
    }
  }
}
</style>
