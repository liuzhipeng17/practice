<template>
  <section class="app-container">

    <!--搜索框-->
    <el-form :inline="true" :model="filters" ref="filterForm">
      <el-row type="flex" justify="space-between">
        <el-form-item prop="app_name">
          <el-input v-model="filters.app_name" placeholder="应用名称" @change="enterSearch"></el-input>
        </el-form-item>
        <el-form-item prop="hostname">
          <el-input v-model="filters.hostname" placeholder="主机名称" @change="enterSearch"></el-input>
        </el-form-item>
        <el-form-item prop="department_name">
          <el-select v-model="filters.department_name" filterable placeholder="部门名称" clearable @change="handleSelect">
            <el-option v-for="item in department_list" :key="item.id" :label="item.name" :value="item.name">
            </el-option>
          </el-select>
        </el-form-item>
        <el-form-item prop="business_group_name">
          <el-select v-model="filters.business_group_name" filterable placeholder="业务组名称" clearable @change="handleSelect">
            <el-option v-for="item in business_group_list" :key="item.id" :label="item.name" :value="item.name">
            </el-option>
          </el-select>
        </el-form-item>
        <el-form-item>
          <el-button type="primary" @click="getDatabases">查询</el-button>
          <el-button @click="resetForm('filterForm')">重置</el-button>
          <el-button type="primary" @click="handleAdd" v-if="is_admin">新增</el-button>
        </el-form-item>
      </el-row>
    </el-form>

    <!--工具条-->
    <el-row type="flex" class="toolbar" justify="space-between">
      <el-button :span="6" @click="showHiddenDialogVisible = true">显示隐藏列</el-button>
      <el-pagination :span="8" layout="total, sizes, prev, pager, next, jumper" @current-change="handleCurrentChange" :page-size="20" :total="total" @size-change="handleSizeChange">
      </el-pagination>
    </el-row>

    <!--列表-->
    <el-table :data="databases" highlight-current-row v-loading="listLoading" @selection-change="selsChange" border style="width: 100%;">
      <el-table-column prop="hostname" label="主机名称" min-width="150" sortable v-if="show_column_list.indexOf('主机名称') >= 0">
      </el-table-column>
      <el-table-column prop="ip_addr" label="IP地址" min-width="300" sortable v-if="show_column_list.indexOf('IP地址') >= 0">
      </el-table-column>
      <el-table-column prop="note" label="描述" min-width="300" sortable v-if="show_column_list.indexOf('描述') >= 0">
      </el-table-column>
      <el-table-column prop="user_list" label="负责人" min-width="100" sortable v-if="show_column_list.indexOf('负责人') >= 0">
        <template slot-scope="scope">
          <el-popover placement="top" v-for="user in scope.row.user_list" :key="user.id">
            <p>{{ user.username }}</p>
            <p>{{ user.phone }}</p>
            <p>{{ user.department.join() }}</p>
            <div slot="reference" class="name-wrapper">
              <el-tag size="medium">{{ user.fullname }}</el-tag>
            </div>
          </el-popover>
        </template>
      </el-table-column>
      <el-table-column prop="port" label="端口" v-if="show_column_list.indexOf('端口') >= 0">
      </el-table-column>
      <el-table-column prop="create_time" label="创建时间" min-width="120" v-if="show_column_list.indexOf('创建时间') >= 0">
      </el-table-column>
      <el-table-column prop="update_time" label="更新时间" min-width="120" v-if="show_column_list.indexOf('更新时间') >= 0">
      </el-table-column>
      <el-table-column prop="database_type" label="应用类型" min-width="100" :filters="database_type_list" :filter-method="filterTag" filter-placement="bottom-end" v-if="show_column_list.indexOf('应用类型') >= 0">
        <template slot-scope="scope">
          <el-tag :type="database_type_to_tag(scope.row.database_type).tag" close-transition>
            {{database_type_to_tag(scope.row.database_type).type}}
          </el-tag>
        </template>
      </el-table-column>

      <el-table-column label="操作" min-width="120" v-if="show_column_list.indexOf('操作') >= 0 && is_admin">
        <template slot-scope="scope">
          <el-button size="small" @click="handleEdit(scope.$index, scope.row)">编辑</el-button>
          <el-button size="small" @click="handleDetail(scope.$index, scope.row)">关联主机</el-button>
        </template>
      </el-table-column>
    </el-table>

    <!--编辑界面-->
    <el-dialog title="编辑" :visible.sync="editFormVisible" :close-on-click-modal="false">
      <el-form :model="editForm" label-width="80px" :rules="editFormRules" ref="editForm">
        <el-form-item label="应用名称">
          <el-col :span="8">
            <el-input v-model="editForm.name"></el-input>
          </el-col>
        </el-form-item>
        <el-form-item label="应用描述">
          <el-input type="textarea" autosize v-model="editForm.note"></el-input>
        </el-form-item>
        <el-form-item label="应用类型">
          <el-select v-model="editForm.database_type" filterable clearable>
            <el-option v-for="item in database_type_list" :key="item.value" :label="item.text" :value="item.value">
            </el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="业务组">
          <el-select v-model="editForm.business_group.id" filterable clearable>
            <el-option v-for="item in business_group_list" :key="item.id" :label="item.name" :value="item.id">
            </el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="部门">
          <el-select v-model="editForm.department.id" filterable clearable @change="handleDepartmentChange">
            <el-option v-for="item in department_list" :key="item.id" :label="item.name" :value="item.id">
            </el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="负责人">
          <el-select v-model="editForm.user_id_list" multiple filterable remote reserve-keyword placeholder="请输入关键词" :remote-method="handleUserNameChange" clearable multiple>
            <el-option v-for="item in department_user_list" :key="item.id" :label="item.fullname" :value="item.id">
            </el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="创建时间">
          <el-col :span="8">
            <el-input v-model="editForm.create_time" :disabled="true"></el-input>
          </el-col>
        </el-form-item>
        <el-form-item label="修改时间">
          <el-col :span="8">
            <el-input v-model="editForm.update_time" :disabled="true"></el-input>
          </el-col>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click.native="editFormVisible = false">取消</el-button>
        <el-button type="primary" @click.native="editSubmit" :loading="editLoading">提交</el-button>
      </div>
    </el-dialog>

    <!--新增界面-->
    <el-dialog title="新增" :visible.sync="addFormVisible" :close-on-click-modal="false">
      <el-form :model="addForm" label-width="80px" :rules="addFormRules" ref="addForm">
        <el-form-item label="应用名称">
          <el-col :span="8">
            <el-input v-model="addForm.name"></el-input>
          </el-col>
        </el-form-item>
        <el-form-item label="应用描述">
          <el-input type="textarea" autosize v-model="addForm.note"></el-input>
        </el-form-item>
        <el-form-item label="应用类型">
          <el-select v-model="addForm.database_type" filterable clearable>
            <el-option v-for="item in database_type_list" :key="item.value" :label="item.text" :value="item.value">
            </el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="业务组">
          <el-select v-model="addForm.business_group.id" filterable clearable>
            <el-option v-for="item in business_group_list" :key="item.id" :label="item.name" :value="item.id">
            </el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="部门">
          <el-select v-model="addForm.department.id" filterable clearable @change="handleDepartmentChange">
            <el-option v-for="item in department_list" :key="item.id" :label="item.name" :value="item.id">
            </el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="负责人">
          <el-select v-model="addForm.user_id_list" multiple filterable remote reserve-keyword placeholder="请输入关键词" :remote-method="handleUserNameChange" clearable multiple>
            <el-option v-for="item in department_user_list" :key="item.id" :label="item.fullname" :value="item.id">
            </el-option>
          </el-select>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click.native="addFormVisible = false">取消</el-button>
        <el-button type="primary" @click.native="addSubmit" :loading="addLoading">提交</el-button>
      </div>
    </el-dialog>

    <!-- 详情界面 -->
    <el-dialog :title="database_detail.name" :visible.sync="detailDialogVisible">
      <database-detail :database-detail='database_detail'></database-detail>
      <span slot="footer" class="dialog-footer">
        <el-button @click="detailDialogVisible = false">关 闭</el-button>
      </span>
    </el-dialog>

    <!--显示隐藏界面-->
    <el-dialog title="显示的列" :visible.sync="showHiddenDialogVisible">
      <el-checkbox :indeterminate="isIndeterminate" v-model="checkAll" @change="handleCheckAllChange">全选</el-checkbox>
      <div style="margin: 15px 0;"></div>
      <el-checkbox-group v-model="show_column_list" @change="handleCheckedColumnChange">
        <el-checkbox v-for="column in column_list" :label="column" :key="column">{{column}}</el-checkbox>
      </el-checkbox-group>
      <span slot="footer" class="dialog-footer">
        <el-button @click="resetColumnOption">恢复默认</el-button>
        <el-button @click="showHiddenDialogVisible = false">关 闭</el-button>
      </span>
    </el-dialog>

  </section>
</template>

<script>
import { mapGetters } from 'vuex'
import { addDatabase, editDatabase, getDatabaseList } from '@/api/api'
import DatabaseDetail from '@/components/CMDB/database'

const column_options = [
  '主机名称',
  'IP地址',
  '描述',
  '部门',
  '业务组',
  '负责人',
  '端口',
  '创建时间',
  '更新时间',
  '应用类型',
  '操作'
]

const default_edit_form = {
  id: '',
  name: '',
  department: { id: '', name: '' },
  business_group: { id: '', name: '' },
  user_id_list: []
}

const default_column_options = [
  '主机名称',
  'IP地址',
  '描述',
  '部门',
  '业务组',
  '负责人',
  '应用类型',
  '操作',
  '创建时间',
  '更新时间'
]

export default {
  data: function() {
    return {
      filters: {
        app_name: '',
        hostname: '',
        business_group_name: '',
        status: '',
        department_name: ''
      },

      checkAll: false,
      showHiddenDialogVisible: false,
      show_column_list: default_column_options,
      isIndeterminate: true,
      column_list: column_options,

      databases: [],
      total: 0,
      page: 1,
      page_size: 20,
      listLoading: false,
      sels: [], // 列表选中列

      editFormVisible: false, // 编辑界面是否显示
      editLoading: false,
      editFormRules: {
        name: [{ required: true, message: '请输入姓名', trigger: 'blur' }]
      },
      // 编辑界面数据
      editForm: default_edit_form,

      addFormVisible: false, // 新增界面是否显示
      addLoading: false,
      addFormRules: {
        name: [{ required: true, message: '请输入姓名', trigger: 'blur' }]
      },
      // 新增界面数据
      addForm: {
        name: null,
        note: null,
        database_type: null,
        business_group: { id: '', name: '' },
        department: { id: '', name: '' },
        user_id_list: []
      },

      // 查看详情界面
      database_detail: {},
      detailDialogVisible: false,

      database_type_list: [
        { text: 'web', value: 1 },
        { text: 'mod', value: 2 },
        { text: 'api', value: 3 },
        { text: 'nginx', value: 4 },
        { text: 'db', value: 5 },
        { text: 'middle', value: 6 }
      ]
    }
  },
  computed: {
    ...mapGetters(['is_admin']),
    department_list() {
      return this.$store.state.cmdb.department_list
    },
    business_group_list() {
      return this.$store.state.cmdb.business_group_list
    },
    department_user_list() {
      return this.$store.state.cmdb.department_user_list
    }
  },
  methods: {
    enterSearch: function() {
      this.getDatabases()
    },
    handleCurrentChange: function(val) {
      this.page = val
      this.getDatabases()
    },
    handleSizeChange: function(val) {
      this.page_size = val
      this.getDatabases()
    },
    handleDepartmentChange: function(val) {
      const param = {
        department_id: val
      }
      this.$store.dispatch('cmdb/loadDepartmentUserAll', param)
    },
    handleUserNameChange: function(val) {
      const param = {
        username: val
      }
      this.$store.dispatch('cmdb/loadDepartmentUserAll', param)
    },

    // 把database的type转换为tag的type
    database_type_to_tag: function(database_type) {
      const res = {
        type: '',
        tag: ''
      }
      switch (database_type) {
        case 1:
          res.type = 'web'
          res.tag = 'primary'
          break
        case 2:
          res.type = 'mod'
          res.tag = 'success'
          break
        case 3:
          res.type = 'api'
          res.tag = 'warning'
          break
        case 4:
          res.type = 'nginx'
          res.tag = 'danger'
          break
        case 5:
          res.type = 'db'
          res.tag = 'grey'
          break
        case 6:
          res.type = 'middle'
          res.tag = 'danger'
          break
        default:
          res.type = 'web'
          res.tag = 'grey'
      }
      return res
    },

    // 获取应用列表
    getDatabases: function() {
      const para = {
        page: this.page,
        page_size: this.page_size
      }
      this.listLoading = true
      getDatabaseList(para).then(res => {
        this.total = res.data.total_count
        this.databases = res.data.res
        this.listLoading = false
      })
    },
    // filter agent_status tag
    filterTag: function(value, row) {
      return row.database_type === value
    },
    // 显示编辑界面
    handleEdit: function(index, row) {
      this.editFormVisible = true
      this.editForm = Object.assign({}, default_edit_form, row)
      this.editForm.user_id_list = row.user_list.map(x => x.id)
      console.log(this.editForm)
      this.$store.dispatch('cmdb/loadDepartmentUserAll')
    },

    // 显示详情界面
    handleDetail: function(index, row) {
      this.detailDialogVisible = true
      this.database_detail = Object.assign({}, row)
      this.$store.dispatch('getHostsByDatabaseName', row.name)
    },

    // 显示新增界面
    handleAdd: function() {
      this.addFormVisible = true
    },
    // 编辑
    editSubmit: function() {
      this.$refs.editForm.validate(valid => {
        if (valid) {
          this.$confirm('确认提交吗？', '提示', {}).then(() => {
            this.editLoading = true
            // NProgress.start();
            const para = {
              id: this.editForm.id,
              name: this.editForm.name,
              note: this.editForm.note,
              user_id_list: this.editForm.user_id_list,
              database_type: this.editForm.database_type,
              department_id: this.editForm.department.id,
              business_group_id: this.editForm.business_group.id
            }
            editDatabase(para).then(res => {
              this.editLoading = false
              // NProgress.done();
              this.$message({
                message: '提交成功',
                type: 'success'
              })
              this.$refs['editForm'].resetFields()
              this.editFormVisible = false
              this.getDatabases()
            })
          })
        }
      })
    },
    // 新增
    addSubmit: function() {
      this.$refs.addForm.validate(valid => {
        if (valid) {
          this.$confirm('确认提交吗？', '提示', {}).then(() => {
            this.addLoading = true
            // NProgress.start();
            const para = {
              name: this.addForm.name,
              note: this.addForm.note,
              user_id_list: this.addForm.user_id_list,
              database_type: this.addForm.database_type,
              department_id: this.addForm.department.id,
              business_group_id: this.addForm.business_group.id
            }
            addDatabase(para).then(res => {
              this.addLoading = false
              // NProgress.done();
              this.$message({
                message: '提交成功',
                type: 'success'
              })
              this.$refs['addForm'].resetFields()
              this.addFormVisible = false
              this.getDatabases()
            })
          })
        }
      })
    },
    selsChange: function(sels) {
      this.sels = sels
    },

    handleSelect: function(item) {
      console.log(item)
      this.getDatabases()
    },

    resetColumnOption: function() {
      this.show_column_list = default_column_options
    },

    resetForm: function(formName) {
      this.$refs[formName].resetFields()
    },

    handleCheckAllChange: function(value) {
      this.show_column_list = value ? column_options : []
      this.isIndeterminate = false
    },
    handleCheckedColumnChange: function(value) {
      const checkedCount = value.length
      this.checkAll = checkedCount === column_options.length
      this.isIndeterminate =
        checkedCount > 0 && checkedCount < column_options.length
    }
  },
  created: function() {
    this.getDatabases()
  },
  mounted: function() {},

  components: {
    DatabaseDetail
  }
}
</script>

<style scoped>
.toolbar {
  padding: 0 0 10px 0;
}
</style>