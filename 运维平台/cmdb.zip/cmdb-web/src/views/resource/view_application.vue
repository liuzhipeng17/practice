<template>
  <div class="tab-container">
    <!--<el-tag type="primary">mounted times ：{{createdTimes}}</el-tag>-->
    <el-tabs style='margin-top:15px;' v-model="activeName" type="border-card">
      <el-tab-pane v-for="item in tabMapOptions" :label="item.label" :key='item.key' :name="item.key">
        <keep-alive>
            <component :is='activeName' ></component>
          <!--<tab-pane v-if='activeName==item.key' :type='item.key' @create='showCreatedTimes'></tab-pane>-->
        </keep-alive>
      </el-tab-pane>
    </el-tabs>
  </div>
</template>

<script>
  import tabPane from './tabPane'
  import host from './host'

  export default {
    name: 'tabDemo',

    data() {
      return {
        tabMapOptions: [
          { label: '应用列表', key: 'App' },
          { label: '服务器列表', key: 'Host' }

        ],
        activeName: 'App',
        createdTimes: 0
      }
    },
    components: {
      'App': tabPane,
      'Host': host
    },
    methods: {
      showCreatedTimes() {
        this.createdTimes = this.createdTimes + 1
      }
    }
  }
</script>

<style scoped>
  .tab-container{
    margin: 30px;
  }
</style>
