<template>
  <section class="app-container">

    <!--列表-->
    <el-table :data="business_group_list" highlight-current-row @selection-change="selsChange" border style="width: 100%;">
      <el-table-column prop="id" label="ID" min-width="150" sortable>
      </el-table-column>
      <el-table-column prop="name" label="业务组名称" min-width="150">
      </el-table-column>
      <el-table-column prop="note" label="备注" min-width="150">
      </el-table-column>
      <el-table-column label="关联应用" min-width="150">

        <template slot-scope="scope">
          <p v-for="item in findApplication(scope.row.id)" :key="item.id">
            {{ item.name }}
          </p>
        </template>
      </el-table-column>
    </el-table>

  </section>
</template>

<script>

export default {
  data: function() {
    return {
      sels: [] // 列表选中列
    }
  },
  computed: {
    business_group_list() {
      return this.$store.state.cmdb.business_group_list
    },
    application_list() {
      return this.$store.state.cmdb.application_list
    }
  },
  methods: {
    selsChange: function(sels) {
      this.sels = sels
    },

    handleSelect: function(item) {
      console.log(item)
      this.getBusinessGroups()
    },
    findApplication: function(business_group_id) {
      return this.application_list.filter(
        application => application.business_group.id === business_group_id
      )
    }
  },
  mounted: function() {}
}
</script>

<style scoped>
.toolbar {
  padding: 0 0 10px 0;
}
</style>