<template>
  <section class="app-container">

    <!--列表-->
    <el-table :data="department_list" highlight-current-row @selection-change="selsChange" border style="width: 100%;">
      <el-table-column prop="id" label="ID" min-width="150" sortable>
      </el-table-column>
      <el-table-column prop="name" label="部门名称" min-width="150" sortable>
      </el-table-column>
      <el-table-column label="关联应用" min-width="150">

        <template slot-scope="scope">
          <p v-for="item in findApplication(scope.row.id)" :key="item.id">
            {{ item.name }}
          </p>
        </template>
      </el-table-column>
    </el-table>

  </section>
</template>

<script>
export default {
  data: function() {
    return {
      sels: [] // 列表选中列
    }
  },
  computed: {
    department_list() {
      return this.$store.state.cmdb.department_list
    },
    application_list() {
      return this.$store.state.cmdb.application_list
    }
  },
  methods: {
    // filter agent_status tag
    filterTag: function(value, row) {
      return row.department_type === value
    },
    selsChange: function(sels) {
      this.sels = sels
    },
    findApplication: function(department_id) {
      return this.application_list.filter(
        application => application.department.id === department_id
      )
    }
  },
  mounted: function() {}
}
</script>

<style scoped>
.toolbar {
  padding: 0 0 10px 0;
}
</style>