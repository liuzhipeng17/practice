<template>
  <section class="app-container">

    <!--搜索框-->
    <el-form :inline="true" :model="filters" ref="filterForm">
      <el-row type="flex" justify="space-between">
        <el-form-item prop="ip">
          <el-input type="textarea" v-model="filters.ip" autosize @input="enterChange" placeholder="主机ip（可输入多个，用逗号隔开）"></el-input>
        </el-form-item>
        <el-form-item prop="hostname">
          <el-input type="textarea" v-model="filters.hostname" @input="enterChange" autosize placeholder="主机名称（可输入多个，用逗号隔开）"></el-input>
        </el-form-item>
        <el-form-item prop="department_name">
          <el-select v-model="filters.department_name" filterable placeholder="部门" clearable @change="handleSelect">
            <el-option v-for="item in department_list" :key="item.id" :label="item.name" :value="item.name">
            </el-option>
          </el-select>
        </el-form-item>
        <el-form-item prop="application_name">
          <el-select v-model="filters.application_name" filterable multiple placeholder="应用名称" clearable @change="handleSelect">
            <el-option v-for="item in application_list" :key="item.value" :label="item.name" :value="item.name">
            </el-option>
          </el-select>
        </el-form-item>
        <el-form-item prop="business_group_name">
          <el-select v-model="filters.business_group_name" filterable multiple placeholder="业务组名称" clearable @change="handleSelect">
            <el-option v-for="item in business_group_list" :key="item.value" :label="item.name" :value="item.name">
            </el-option>
          </el-select>
        </el-form-item>
        <el-form-item prop="status">
          <el-select v-model="filters.status" placeholder="主机状态" @change="handleSelect" clearable>
            <el-option v-for="item in host_optioins" :key="item.value" :label="item.label" :value="item.value">
            </el-option>
          </el-select>
        </el-form-item>
        <el-form-item prop="agent_status">
          <el-select v-model="filters.agent_status" placeholder="agent状态" @change="handleSelect" clearable>
            <el-option v-for="item in agent_options" :key="item.value" :label="item.label" :value="item.value">
            </el-option>
          </el-select>
        </el-form-item>
        <el-form-item>
          <el-button type="primary" v-on:click="getHosts">查询</el-button>
          <el-button @click="resetForm('filterForm')">重置</el-button>
        </el-form-item>
      </el-row>
    </el-form>

    <!--工具条-->
    <el-row type="flex" class="toolbar" justify="space-between">
      <el-button :span="6" @click="showHiddenDialogVisible = true">显示隐藏列</el-button>
      <el-pagination :span="8" layout="total, sizes, prev, pager, next, jumper" @current-change="handleCurrentChange" :page-size="20" :total="total" @size-change="handleSizeChange">
      </el-pagination>
    </el-row>

    <!--列表-->
    <el-table :data="hosts" highlight-current-row v-loading="listLoading" @selection-change="selsChange" border style="width: 100%;" max-height="1000">
      <el-table-column prop="ip" label="IP" min-width="150" sortable v-if="show_column_list.indexOf('IP') >= 0">
        <template slot-scope="scope">
          <p v-for="item in scope.row.network_interface" :key="item.id">
            {{ item.ip.map(x => x.ip_addr).join() }}
          </p>
        </template>
      </el-table-column>
      <el-table-column prop="hostname" label="主机名称" min-width="200" sortable v-if="show_column_list.indexOf('主机名称') >= 0">
      </el-table-column>
      <el-table-column prop="department" label="部门" min-width="180" sortable v-if="show_column_list.indexOf('部门') >= 0">
        <template slot-scope="scope">
          <p v-for="item in scope.row.application_list" :key="item.id">
            {{ item.department.name }}
          </p>
        </template>
      </el-table-column>
      <el-table-column prop="application" label="应用名称" min-width="180" sortable v-if="show_column_list.indexOf('应用名称') >= 0">
        <template slot-scope="scope">
          <p v-for="item in scope.row.application_list" :key="item.id">
            {{ item.name }}
          </p>
        </template>
      </el-table-column>
      <el-table-column prop="application" label="应用版本" min-width="180" sortable v-if="show_column_list.indexOf('应用版本') >= 0">
        <template slot-scope="scope">
          <p v-for="item in scope.row.application_list" :key="item.id">
            {{ item.version }}
          </p>
        </template>
      </el-table-column>
      <el-table-column prop="application" label="应用commit" min-width="180" sortable v-if="show_column_list.indexOf('应用commit') >= 0">
        <template slot-scope="scope">
          <p v-for="item in scope.row.application_list" :key="item.id">
            {{ item.commit_id }}
          </p>
        </template>
      </el-table-column>
      <el-table-column prop="application" label="应用路径" min-width="180" sortable v-if="show_column_list.indexOf('应用路径') >= 0">
        <template slot-scope="scope">
          <p v-for="item in scope.row.application_list" :key="item.id">
            {{ item.deploy_path }}
          </p>
        </template>
      </el-table-column>
      <el-table-column prop="business_group_name" label="业务组" min-width="180" sortable v-if="show_column_list.indexOf('业务组') >= 0">
        <template slot-scope="scope">
          <p v-for="item in scope.row.application_list" :key="item.id">
            {{ item.business_group.name }}
          </p>
        </template>
      </el-table-column>
      <el-table-column prop="disk_total" label="硬盘(G)" min-width="100" v-if="show_column_list.indexOf('硬盘') >= 0">
      </el-table-column>
      <el-table-column prop="cpu_core_num" label="CPU 核数" min-width="100" v-if="show_column_list.indexOf('CPU 核数') >= 0">
      </el-table-column>
      <el-table-column prop="memory_total" label="内存(M)" min-width="100" v-if="show_column_list.indexOf('内存') >= 0">
      </el-table-column>
      <el-table-column prop="create_time" label="创建时间" min-width="120" v-if="show_column_list.indexOf('创建时间') >= 0">
      </el-table-column>
      <el-table-column prop="update_time" label="更新时间" min-width="120" v-if="show_column_list.indexOf('更新时间') >= 0">
      </el-table-column>
      <el-table-column prop="agent_status" label="agent" v-if="show_column_list.indexOf('agent') >= 0">
        <template slot-scope="scope">
          <el-tag :type="agent_status_to_tag(scope.row.agent_status)[1]" :disable-transitions="true">
            {{agent_status_to_tag(scope.row.agent_status)[0]}}
          </el-tag>
        </template>
      </el-table-column>
      <el-table-column prop="status" label="状态" min-width="100" v-if="show_column_list.indexOf('状态') >= 0">
        <template slot-scope="scope">
          <span class="el-tag" :class="status_to_tag(scope.row.status)[1]" v-show="!scope.row.edit">
            {{status_to_tag(scope.row.status)[0]}}
          </span>
          <el-select v-show="scope.row.edit" size="small" v-model="scope.row.status">
            <el-option v-for="item in host_optioins" :key="item.value" :label="item.label" :value="item.value">
            </el-option>
          </el-select>
        </template>
      </el-table-column>
      <el-table-column align="center" label="编辑" width="120" v-if="is_admin">
        <template slot-scope="scope">
          <el-button :type="scope.row.edit?'success':'primary'" @click='changeHostStatus(scope.$index, scope.row)' size="small" icon="edit">{{scope.row.edit?'完成':'编辑'}}</el-button>
        </template>
      </el-table-column>
    </el-table>

    <!-- 详情界面 -->
    <el-dialog title="详情" :visible.sync="detailDialogVisible">
      <host-detail :host-detail='host_detail'></host-detail>
      <span slot="footer" class="dialog-footer">
        <el-button @click="detailDialogVisible = false">关 闭</el-button>
      </span>
    </el-dialog>

    <!--显示隐藏界面-->
    <el-dialog title="显示的列" :visible.sync="showHiddenDialogVisible">
      <el-checkbox :indeterminate="isIndeterminate" v-model="checkAll" @change="handleCheckAllChange">全选</el-checkbox>
      <div style="margin: 15px 0;"></div>
      <el-checkbox-group v-model="show_column_list" @change="handleCheckedColumnChange">
        <el-checkbox v-for="column in column_list" :label="column" :key="column">{{column}}</el-checkbox>
      </el-checkbox-group>
      <span slot="footer" class="dialog-footer">
        <el-button @click="resetColumnOption">恢复默认</el-button>
        <el-button @click="showHiddenDialogVisible = false">关 闭</el-button>
      </span>
    </el-dialog>
  </section>
</template>

<script>
import { mapGetters } from 'vuex'
import { getHostList, editHost } from '../../api/api'

import HostDetail from '@/components/CMDB/host'
const column_options = [
  'IP',
  '主机名称',
  '业务组',
  '应用名称',
  '应用版本',
  '应用commit',
  '应用路径',
  '部门',
  '硬盘',
  'CPU 核数',
  '内存',
  '创建时间',
  '更新时间',
  'agent',
  '状态'
]

const default_column_options = [
  'IP',
  '主机名称',
  '业务组',
  '应用名称',
  '应用版本',
  '部门',
  'agent',
  '状态'
]

export default {
  data: function() {
    return {
      filters: {
        ip: '',
        hostname: '',
        business_group_name: [],
        department_name: null,
        status: '',
        agent_status: '',
        application_name: []
      },

      checkAll: false,
      showHiddenDialogVisible: false,
      show_column_list: default_column_options,
      isIndeterminate: true,
      column_list: column_options,

      hosts: [],
      total: 0,
      page: 1,
      page_size: 20,
      listLoading: false,
      sels: [], // 列表选中列

      // 查看详情界面
      host_detail: null,
      detailDialogVisible: false,

      // 状态
      host_optioins: [
        {
          value: 0,
          label: '库存'
        },
        {
          value: 1,
          label: '上架'
        },
        {
          value: 2,
          label: '初始化'
        },
        {
          value: 3,
          label: '上线'
        },
        {
          value: 4,
          label: '故障'
        },
        {
          value: 5,
          label: '下线'
        }
      ],

      // agent_status
      agent_options: [
        {
          value: '1',
          label: '正常'
        },
        {
          value: '2',
          label: '异常'
        },
        {
          value: '3',
          label: '下架'
        },
        {
          value: '4',
          label: '未安装'
        }
      ]
    }
  },
  computed: {
    ...mapGetters(['is_admin']),
    department_list() {
      return this.$store.state.cmdb.department_list
    },
    application_list() {
      return this.$store.state.cmdb.application_list
    },
    business_group_list() {
      return this.$store.state.cmdb.business_group_list
    }
  },
  methods: {
    enterChange: function() {
      this.getHosts()
    },
    handleCurrentChange: function(val) {
      this.page = val
      this.getHosts()
    },
    handleSizeChange: function(val) {
      this.page_size = val
      console.log(this.page_size)
      this.getHosts()
    },
    // agent_status to  tag
    agent_status_to_tag: function(agent_status) {
      var tag_agent_status = ''
      var tag_agent_status_type = ''
      switch (agent_status) {
        case 1:
          tag_agent_status = '正常'
          tag_agent_status_type = 'success'
          break
        case 2:
          tag_agent_status = '异常'
          tag_agent_status_type = 'danger'
          break
        case 3:
          tag_agent_status = '下架'
          tag_agent_status_type = 'warning'
          break
        case 4:
          tag_agent_status = '未安装'
          tag_agent_status_type = 'danger'
          break
        default:
          tag_agent_status = '未安装'
          tag_agent_status_type = 'danger'
      }
      return [tag_agent_status, tag_agent_status_type]
    },
    // status to tag
    status_to_tag: function(status) {
      var tag_status = ''
      var tag_status_type = ''
      switch (status) {
        case 0:
          tag_status = '库存'
          tag_status_type = 'el-tag--grey'
          break
        case 1:
          tag_status = '上架'
          tag_status_type = 'el-tag--grey'
          break
        case 2:
          tag_status = '初始化'
          tag_status_type = 'el-tag--primary'
          break
        case 3:
          tag_status = '上线'
          tag_status_type = 'el-tag--success'
          break
        case 4:
          tag_status = '故障'
          tag_status_type = 'el-tag--danger'
          break
        case 5:
          tag_status = '下线'
          tag_status_type = 'el-tag--warning'
          break
        default:
          tag_status = '库存'
          tag_status_type = 'el-tag--grey'
      }
      return [tag_status, tag_status_type]
    },

    changeHostStatus: function(index, row) {
      if (row.edit) {
        const data = {
          id: row.id,
          status: row.status
        }
        editHost(data)
          .then(res => {
            this.$message.success('更新状态成功')

            row.edit = !row.edit
          })
          .catch(() => {
            this.$message.error('更新状态失败')
          })
      } else {
        row.edit = !row.edit
      }
    },
    // 获取主机列表
    getHosts: function() {
      const para = {
        page: this.page,
        page_size: this.page_size,
        hostname: this.filters.hostname.replace(/\s\s+| |;|\n/g, ','),
        ip: this.filters.ip.replace(/\s\s+| |;|\n/g, ','),
        business_group_name: this.filters.business_group_name.join(','),
        application_name: this.filters.application_name.join(','),
        department_name: this.filters.department_name,
        status: this.filters.status,
        agent_status: this.filters.agent_status
      }
      this.listLoading = true
      getHostList(para).then(res => {
        this.total = res.data.total_count
        this.hosts = res.data.res.filter(host => host != null)
        this.hosts = this.hosts.map(v => {
          this.$set(v, 'edit', false)
          return v
        })
        this.listLoading = false
      })
    },
    // filter agent_status tag
    filterTag: function(value, row) {
      return row.agent_status === value
    },
    // filter status tag
    filterStatusTag: function(value, row) {
      return row.status === value
    },
    resetColumnOption: function() {
      this.show_column_list = default_column_options
    },
    resetForm: function(formName) {
      this.$refs[formName].resetFields()
      this.getHosts()
    },
    // 显示详情界面
    handleDetail: function(index, row) {
      this.detailDialogVisible = true
      this.host_detail = Object.assign({}, row)
    },
    // 显示新增界面
    handleAdd: function() {
      this.addFormVisible = true
      this.addForm = {
        name: '',
        sex: -1,
        age: 0,
        birth: '',
        addr: ''
      }
    },
    selsChange: function(sels) {
      this.sels = sels
    },
    createStateFilter: function(queryString) {
      return state => {
        return state.value.indexOf(queryString.toLowerCase()) === 0
      }
    },
    handleSelect: function(item) {
      console.log(item)
      this.getHosts()
    },

    handleCheckAllChange: function(value) {
      this.show_column_list = value ? column_options : []
      this.isIndeterminate = false
    },
    handleCheckedColumnChange: function(value) {
      const checkedCount = value.length
      this.checkAll = checkedCount === column_options.length
      this.isIndeterminate =
        checkedCount > 0 && checkedCount < column_options.length
    }
  },
  created: function() {
    this.getHosts()
  },
  components: {
    HostDetail
  }
}
</script>

<style scoped>
.toolbar {
  padding: 0 0 10px 0;
}
</style>