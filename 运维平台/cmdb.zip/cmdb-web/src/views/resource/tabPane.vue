<template>
  <section class="app-container">
    <!--工具条-->
    <el-col :span="24" class="toolbar" style="padding-bottom: 0px;">
      <el-form :inline="true" :model="filters" ref="filterForm">
        <el-form-item prop="app_name">
          <el-input v-model="filters.app_name" placeholder="应用名称"></el-input>
        </el-form-item>
        <el-form-item prop="hostname">
          <el-input v-model="filters.hostname" placeholder="主机名称"></el-input>
        </el-form-item>
        <el-form-item prop="department_name">
          <el-select v-model="filters.department_name" filterable placeholder="部门名称" clearable @change="handleSelect">
            <el-option v-for="item in department" :key="item.value" :label="item.label" :value="item.label">
            </el-option>
          </el-select>
        </el-form-item>
        <el-form-item prop="business_group_name">
          <el-select v-model="filters.business_group_name" filterable placeholder="业务组名称" clearable @change="handleSelect">
            <el-option v-for="item in business_group" :key="item.value" :label="item.label" :value="item.label">
            </el-option>
          </el-select>
        </el-form-item>
        <el-form-item>
          <el-button type="primary" @click="getApplications">查询</el-button>
          <el-button @click="resetForm('filterForm')">重置</el-button>
          <el-button type="primary" @click="handleAdd">新增</el-button>
        </el-form-item>

      </el-form>
    </el-col>

    <!--列表-->
    <el-table :data="applications" highlight-current-row v-loading="listLoading" @selection-change="selsChange" border style="width: 100%;">
      <el-table-column prop="name"  label="应用名称" min-width="150" sortable>
        <template slot-scope="scope">
          <span class="link-type" @click="cell_click_test">{{scope.row.name}}</span>
        </template>
      </el-table-column>
      <el-table-column prop="note" label="描述" min-width="300" sortable>
      </el-table-column>
      <el-table-column prop="department_name" label="部门" min-width="100" sortable>
      </el-table-column>
      <el-table-column prop="business_group_name" label="业务" min-width="100" sortable>
      </el-table-column>
      <el-table-column prop="version" label="版本">
      </el-table-column>
      <el-table-column prop="port_number" label="端口">
      </el-table-column>
      <el-table-column prop="start_up" label="启动类型">
      </el-table-column>
      <el-table-column prop="deploy_path" label="部署路径">
      </el-table-column>
      <el-table-column prop="create_time" label="创建时间">
      </el-table-column>
      <el-table-column prop="update_time" label="更新时间">
      </el-table-column>
      <el-table-column prop="application_type" label="应用类型" min-width="100" :filters="application_type_list" :filter-method="filterTag" filter-placement="bottom-end">
        <template slot-scope="scope">
          <el-tag :type="application_type_to_tag(scope.row.application_type)[0]" close-transition>
            {{scope.row.application_type}}
          </el-tag>
        </template>
      </el-table-column>

      <el-table-column label="操作" min-width="120">
        <template slot-scope="scope">
          <el-button size="small" @click="handleEdit(scope.$index, scope.row)">编辑</el-button>

          <el-button size="small" @click="handleDetail(scope.$index, scope.row)">查看</el-button>

        </template>
      </el-table-column>
    </el-table>

    <!--工具条-->
    <el-col :span="24" class="toolbar">
      <el-pagination layout="total,sizes,prev, pager, next" @current-change="handleCurrentChange" :page-size="20" :total="total" @size-change="handleSizeChange" style="float:right;">
      </el-pagination>
    </el-col>

    <!--编辑界面-->
    <el-dialog title="编辑" v-model="editFormVisible" :close-on-click-modal="false">
      <el-form :model="editForm" :inline="true" label-width="80px" :rules="editFormRules" ref="editForm">
        <el-form-item label="应用名称">
          <el-input v-model="editForm.name"></el-input>
        </el-form-item>
        <el-form-item label="应用描述">
          <el-input v-model="editForm.note"></el-input>
        </el-form-item>
        <el-form-item label="应用类型">
          <el-input v-model="editForm.application_type"></el-input>
        </el-form-item>
        <el-form-item label="业务组">
          <el-select v-model="editForm.business_group_name" filterable clearable>
            <el-option v-for="item in business_group" :key="item.value" :label="item.label" :value="item.label">
            </el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="创建时间">
          <el-input v-model="editForm.create_time" :readonly="true"></el-input>
        </el-form-item>
        <el-form-item label="修改时间">
          <el-input v-model="editForm.update_time" :readonly="true"></el-input>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click.native="editFormVisible = false">取消</el-button>
        <el-button type="primary" @click.native="editSubmit" :loading="editLoading">提交</el-button>
      </div>
    </el-dialog>

    <!--新增界面-->
    <el-dialog title="新增" v-model="addFormVisible" :close-on-click-modal="false">
      <el-form :model="addForm" label-width="80px" :rules="addFormRules" ref="addForm">
        <el-form-item label="应用名称">
          <el-input v-model="addForm.name"></el-input>
        </el-form-item>
        <el-form-item label="应用描述">
          <el-input v-model="addForm.note"></el-input>
        </el-form-item>
        <el-form-item label="应用类型">
          <el-input v-model="addForm.application_type"></el-input>
        </el-form-item>
        <el-form-item label="业务组">
          <el-select v-model="addForm.business_group_id" filterable clearable>
            <el-option v-for="item in business_group" :key="item.value" :label="item.label" :value="item.value">
            </el-option>
          </el-select>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click.native="addFormVisible = false">取消</el-button>
        <el-button type="primary" @click.native="addSubmit" :loading="addLoading">提交</el-button>
      </div>
    </el-dialog>
  </section>
</template>

<script>
  // import NProgress from 'nprogress'
  import {
    addApplication,
    editApplication,
    getDepartmentList,
    getApplicationList,
    getBusinessGroupList
  } from '@/api/api'

  export default {
    data: function() {
      return {
        filters: {
          app_name: '',
          hostname: '',
          business_group_name: '',
          status: '',
          department_name: ''
        },
        applications: [],
        total: 0,
        page: 1,
        page_size: 20,
        listLoading: false,
        sels: [], // 列表选中列

        editFormVisible: false, // 编辑界面是否显示
        editLoading: false,
        editFormRules: {
          name: [{ required: true, message: '请输入姓名', trigger: 'blur' }]
        },
        // 编辑界面数据
        editForm: {
          id: 0,
          hostname: '',
          ip: ''
        },

        addFormVisible: false, // 新增界面是否显示
        addLoading: false,
        addFormRules: {
          name: [{ required: true, message: '请输入姓名', trigger: 'blur' }]
        },
        // 新增界面数据
        addForm: {
          name: null,
          note: null,
          application_type: null,
          business_group_id: null
        },

        // 业务组搜索
        business_group: [],

        // 部门搜索
        department: [],

        application_type_list: [
          { text: 'mod', value: 'mod' },
          { text: 'web', value: 'web' },
          { text: 'api', value: 'api' }
        ]
      }
    },
    methods: {
      handleCurrentChange: function(val) {
        this.page = val
        this.getApplications()
      },
      handleSizeChange: function(val) {
        this.page_size = val
        this.getApplications()
      },
      cell_click_test: function() {
        console.log('cell_clcik_test')
      },
      //
      application_type_to_tag: function(application_type) {
        let app_tag_type = ''
        switch (application_type) {
          case 'web':
            app_tag_type = 'primary'
            break
          case 'mod':
            app_tag_type = 'success'
            break
          case 'api':
            app_tag_type = 'warning'
            break
          case 'nginx':
            app_tag_type = 'danger'
            break
          case 'db':
            app_tag_type = 'grey'
            break
          case 'middle':
            app_tag_type = 'danger'
            break
          default:
            app_tag_type = 'grey'
        }
        return [app_tag_type]
      },
      // 获取应用列表
      getApplications: function() {
        const para = {
          page: this.page,
          page_size: this.page_size,
          name: this.filters.app_name,
          hostname: this.filters.hostname,
          ip: this.filters.ip,
          business_group_name: this.filters.business_group_name,
          department_name: this.filters.department_name
        }
        this.listLoading = true
        getApplicationList(para).then(res => {
          this.total = res.data.total_count
          this.applications = res.data.res
          this.listLoading = false
        })
      },
      // filter agent_status tag
      filterTag: function(value, row) {
        return row.application_type === value
      },
      // 显示编辑界面
      handleEdit: function(index, row) {
        this.editFormVisible = true
        this.editForm = Object.assign({}, row)
      },
      handleDetail: function(index, row) {
        this.$router.push({ path: '/resource/application_detail/' + row.id })
      },
      // 显示新增界面
      handleAdd: function() {
        this.addFormVisible = true
      },
      // 编辑
      editSubmit: function() {
        this.$refs.editForm.validate(valid => {
          if (valid) {
            this.$confirm('确认提交吗？', '提示', {}).then(() => {
              this.editLoading = true
              // NProgress.start();
              const para = {
                id: this.editForm.id,
                name: this.editForm.name,
                note: this.editForm.note
              }
              editApplication(para).then(res => {
                this.editLoading = false
                // NProgress.done();
                this.$message({
                  message: '提交成功',
                  type: 'success'
                })
                this.$refs['editForm'].resetFields()
                this.editFormVisible = false
                this.getApplications()
              })
            })
          }
        })
      },
      // 新增
      addSubmit: function() {
        this.$refs.addForm.validate(valid => {
          if (valid) {
            this.$confirm('确认提交吗？', '提示', {}).then(() => {
              this.addLoading = true
              // NProgress.start();
              const para = Object.assign({}, this.addForm)
              addApplication(para).then(res => {
                this.addLoading = false
                // NProgress.done();
                this.$message({
                  message: '提交成功',
                  type: 'success'
                })
                this.$refs['addForm'].resetFields()
                this.addFormVisible = false
                this.getApplications()
              })
            })
          }
        })
      },
      selsChange: function(sels) {
        this.sels = sels
      },

      handleSelect: function(item) {
        console.log(item)
        this.getApplications()
      },

      resetForm: function(formName) {
        this.$refs[formName].resetFields()
      },

      // 业务组搜索
      loadBusinessGroupAll: function() {
        const param = {
          page: 1,
          page_size: 100000
        }
        var app_name = []
        getBusinessGroupList(param).then(results => {
          var app = results.data.res
          for (var i = 0; i < app.length; i++) {
            app_name.push({
              label: app[i].name,
              value: app[i].id
            })
          }
        })
        this.business_group = app_name
      },

      // 部门搜索
      loadDepartmentAll: function() {
        const param = {
          page: 1,
          page_size: 100000
        }
        var app_name = []
        getDepartmentList(param).then(results => {
          var app = results.data.res
          for (var i = 0; i < app.length; i++) {
            app_name.push({
              label: app[i].name,
              value: app[i].id
            })
          }
        })
        this.department = app_name
      }
    },
    created: function() {
      this.getApplications()
      this.loadBusinessGroupAll()
      this.loadDepartmentAll()
    },
    mounted: function() {}
  }
</script>

<style scoped>
  .demo-table-expand {
    font-size: 0;
  }

  .demo-table-expand label {
    width: 90px;
    color: #99a9bf;
  }

  .demo-table-expand .el-form-item {
    margin-right: 0;
    margin-bottom: 0;
    width: 50%;
  }
</style>